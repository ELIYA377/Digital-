import React, { useEffect } from 'react';
import { FileText, X } from 'lucide-react';

interface TermsModalProps {
  open: boolean;
  onClose: () => void;
  onAccept?: () => void;
}

const TERMS_SECTIONS = [
  {
    number: '01',
    title: 'Kukubali Sheria na Masharti',
    body: 'Kwa kujisajili, kufungua akaunti, au kutumia huduma yoyote ndani ya mfumo wa Tanzania Document Portal (Digital sales), unakubali kufuata na kufungwa na sheria na masharti haya kikamilifu. Ikiwa hukubaliani na kipengele chochote, tafadhali usiendelee kutumia mfumo huu.',
  },
  {
    number: '02',
    title: 'Usajili, Akaunti na Usalama wa PIN',
    body: 'Mtumiaji anatakiwa kujisajili kwa majina matatu halisi, namba ya simu inayotumika, na kuweka neno la siri (PIN) la tarakimu 4. Unawajibika kulinda kifaa chako, akaunti yako ya Google, na PIN yako. Akaunti moja ni kwa ajili ya mtumiaji mmoja pekee.',
  },
  {
    number: '03',
    title: 'Matumizi Sahihi na Wajibu wa Mtumiaji',
    body: 'Zana za kuandaa Business License na TIN Certificate zimekusudiwa kwa ajili ya maandalizi halali ya nyaraka, kumbukumbu za ofisi, na matumizi halali ya kibiashara. Mtumiaji anawajibika moja kwa moja kwa usahihi wa taarifa anazoingiza na matumizi ya nyaraka anazozalisha. Matumizi ya udanganyifu au kinyume cha sheria ni marufuku kabisa.',
  },
  {
    number: '04',
    title: 'Mfumo wa Coin na Malipo (DSN Collect / Mobile Money)',
    body: 'Baadhi ya zana za mfumo (Export PNG, Print / PDF, Live QR, na Hifadhi Kumbukumbu) hutumia Coin kulingana na viwango vinavyowekwa na Admin. Malipo yanafanyika kwa TZS kupitia mitandao ya simu (M-Pesa, Airtel Money, Mixx by Yas, Halopesa, au USSD Push ya DSN Collect). Coin huongezwa baada ya malipo kuthibitishwa, na Coin zilizotumika hazirejeshwi.',
  },
  {
    number: '05',
    title: 'Usimamizi wa Huduma na Haki za Admin',
    body: 'Admin ana mamlaka ya kuwasha au kuzima huduma kwa kila mtumiaji, kuhakiki miamala ya malipo, kurekebisha vifurushi vya Coin, na kusimamisha akaunti yoyote inayokiuka masharti haya. Matendo yote ya kiutawala yanarekodiwa kwenye mfumo wa ukaguzi (Audit Log) kwa ajili ya uwazi na usalama.',
  },
  {
    number: '06',
    title: 'Faragha na Uhifadhi wa Data',
    body: 'Taarifa zako za usajili, historia ya malipo, na nyaraka unazohifadhi zinatunzwa kwa usalama katika wingu ili ziweze kupatikana unapoingia kupitia vifaa vyako. Hatuuzi wala kusambaza taarifa zako binafsi kwa wahusika wasioidhinishwa.',
  },
  {
    number: '07',
    title: 'Haki Miliki na Mawasiliano',
    body: 'Mfumo huu na miundo yake yote ni mali ya Digital sales (All rights reserved). Kwa maswali, msaada wa malipo, au maelezo zaidi kuhusu masharti haya, wasiliana na msimamizi wa mfumo kupitia namba 0784615052.',
  },
];

export const TermsModal: React.FC<TermsModalProps> = ({
  open,
  onClose,
  onAccept,
}) => {
  useEffect(() => {
    if (!open) return;
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [open, onClose]);

  if (!open) return null;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 p-4"
      role="dialog"
      aria-modal="true"
      aria-labelledby="terms-modal-title"
      onClick={(e) => {
        if (e.target === e.currentTarget) {
          onClose();
        }
      }}
    >
      <div className="w-full max-w-2xl max-h-[85vh] bg-white border border-slate-200 rounded-xl shadow-[0_20px_50px_rgba(15,23,42,0.18)] flex flex-col overflow-hidden">
        <div className="px-6 py-4 border-b border-slate-200 bg-slate-50/70 flex items-center justify-between gap-4 shrink-0">
          <div className="flex items-center gap-2.5 min-w-0">
            <FileText className="w-4 h-4 text-[#0f4c75] shrink-0" aria-hidden="true" />
            <div className="min-w-0">
              <h2
                id="terms-modal-title"
                className="font-display text-base font-semibold text-slate-900 truncate"
              >
                Terms &amp; Conditions (Sheria na Masharti)
              </h2>
              <p className="text-xs text-slate-500">
                Digital sales · Tanzania Document Portal
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Funga Sheria na Masharti"
            className="p-1.5 text-slate-500 hover:text-slate-900 hover:bg-slate-200/60 rounded-lg transition-colors shrink-0"
          >
            <X className="w-4 h-4" aria-hidden="true" />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto px-6 py-5 space-y-5">
          <p className="text-xs text-slate-600 leading-relaxed">
            Tafadhali soma kwa makini masharti yafuatayo yanayosimamia matumizi ya
            mfumo wa kutengeneza nyaraka, ununuzi wa Coin, na uhifadhi wa kumbukumbu.
          </p>

          <div className="divide-y divide-slate-100 border-t border-b border-slate-100">
            {TERMS_SECTIONS.map((sec) => (
              <section key={sec.number} className="py-4 space-y-1.5">
                <h3 className="text-sm font-semibold text-slate-900">
                  {sec.number}. {sec.title}
                </h3>
                <p className="text-xs text-slate-600 leading-relaxed">
                  {sec.body}
                </p>
              </section>
            ))}
          </div>
        </div>

        <div className="px-6 py-3.5 border-t border-slate-200 bg-slate-50/70 flex flex-wrap items-center justify-between gap-3 shrink-0">
          <span className="text-xs text-slate-500">
            &copy; Digital sales. All rights reserved.
          </span>
          <div className="flex items-center gap-2.5">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-medium text-slate-700 bg-white border border-slate-200 hover:bg-slate-50 rounded-lg transition-colors whitespace-nowrap"
            >
              Funga
            </button>
            {onAccept && (
              <button
                type="button"
                onClick={() => {
                  onAccept();
                  onClose();
                }}
                className="px-4 py-2 text-xs font-medium text-white bg-[#0f4c75] hover:bg-[#0b3a5b] rounded-lg transition-colors whitespace-nowrap"
              >
                Nakubali Sheria &amp; Masharti
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
