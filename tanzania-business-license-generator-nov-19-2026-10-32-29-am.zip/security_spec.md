# Security Specification & Dirty Dozen Payloads

## Data Invariants
1. A `UserProfile` at `/users/{userId}` can only be created by the authenticated, email-verified owner (`request.auth.uid == userId`), and MUST initialize with `role: 'user'`, `coins: 0`, `accountStatus: 'active'`, and all service flags set to `false` (unless created by a verified Admin).
2. A regular user can NEVER read or list another user's `UserProfile` (protecting PII such as `phone`, `email`, `pinHash`, and `pinSalt`). Only `isOwner(userId)` or `isAdmin()` may read `/users/{userId}`, and only `isAdmin()` may `list` `/users`.
3. A regular user can NEVER increase their own `coins`, toggle their own `services`, change `role`, or reactivate a `suspended` account. User updates are strictly split into Profile Update (`fullName`, `phone`, `pinHash`, `pinSalt`, `updatedAt`) and Coin Spend (`coins < existing().coins` and `coins >= 0`).
4. Every write to `/users/{userId}/licenses/{licenseId}` and `/users/{userId}/tinCertificates/{certId}` enforces the Master Gate on `/users/{userId}`: the parent user must be `active` and have `services.saveRecords == true` (plus `services.tinCertificate == true` for TIN certificates), unless `isAdmin()`.
5. Every `spend` entry in `/users/{userId}/coinTransactions/{txId}` enforces `getAfter()` atomicity against `/users/{userId}` so the logged `amount` equals the exact coin balance reduction.
6. Every `PaymentRequest` at `/paymentRequests/{paymentId}` can only be created by the active verified owner with `userId == request.auth.uid`, `status == 'pending'`, `reviewedBy == ''`, and `adminNote == ''`. Only `isAdmin()` can transition a `pending` payment to `'approved'` or `'rejected'`, and terminal states (`'approved'` / `'rejected'`) cannot be updated again.
7. Non-admin users can only `get` or `list` `/paymentRequests` where `userId == request.auth.uid`.
8. `createdAt` and `updatedAt` timestamps must match `request.time`.
9. Every `AdminActivityLog` at `/adminActivityLogs/{logId}` can only be read, listed, or created by a verified Admin (`isAdmin()`), with `actorUid == request.auth.uid` and `createdAt == request.time`, and can NEVER be updated or deleted (immutable audit trail).

## The "Dirty Dozen" Payloads (Expected: PERMISSION_DENIED)
1. **Self-Assigned Admin Role on Registration**: Create `/users/userA` with `role: 'admin'`.
2. **Free Coin Minting on Registration**: Create `/users/userA` with `coins: 5000`.
3. **Self-Enabling Services on Registration**: Create `/users/userA` with `services.exportPng: true`.
4. **Coin Balance Inflation via Update**: Update `/users/userA` setting `coins: existing.coins + 100` as `userA`.
5. **Service Flag Escalation via Update**: Update `/users/userA` setting `services.printPdf: true` as `userA`.
6. **Shadow Ghost Field Injection**: Create or update `/users/userA` or `/paymentRequests/pay1` with extra key `isSuperUser: true`.
7. **Cross-User PII Read / List Scraping**: `get` `/users/userB`, `list` `/users`, or `list` `/paymentRequests` without `userId == request.auth.uid` as non-admin `userA`.
8. **Unverified Email Spoof**: Attempt write with `token.email = 'salesdigital181@gmail.com'` and `token.email_verified = false`.
9. **Path ID Poisoning**: Create `/users/userA/licenses/bad$id` or `/paymentRequests/bad$id` or 200-char ID string.
10. **Self-Approved Payment Request Forgery**: Create `/paymentRequests/pay1` as `userA` with `status: 'approved'` or `userId: 'userB'`, or update `/paymentRequests/pay1` as `userA` to `status: 'approved'`.
11. **Payment Double-Approval Replay**: Update `/paymentRequests/pay1` as Admin when `existing().status == 'approved'`.
12. **Client Timestamp Forgery**: Create `/paymentRequests/pay1` or `/users/userA/licenses/lic1` with `createdAt` set to a past timestamp instead of `request.time`.
