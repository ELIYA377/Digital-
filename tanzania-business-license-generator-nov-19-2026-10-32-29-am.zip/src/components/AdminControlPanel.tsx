import React, { useEffect, useMemo, useState } from 'react';
import {
  collection,
  limit,
  onSnapshot,
  orderBy,
  query,
} from 'firebase/firestore';
import {
  Activity,
  CheckCircle2,
  Clock,
  Coins,
  CreditCard,
  Plus,
  RefreshCw,
  Search,
  ShieldAlert,
  ShieldCheck,
  Sliders,
  Trash2,
  Wallet,
  XCircle,
} from 'lucide-react';
import { auth, db, handleFirestoreError, OperationType } from '../firebase';
import {
  ADMIN_ACTIVITY_CATEGORY_LABELS,
  ALL_ENABLED_SERVICES,
  AdminActivityCategory,
  AdminActivityLogRecord,
  CoinCosts,
  CoinTransactionRecord,
  DEFAULT_PAYMENT_CONFIG,
  EMPTY_SERVICES,
  PAYMENT_NETWORK_LABELS,
  PaymentConfig,
  PaymentRequestRecord,
  SERVICE_DEFINITIONS,
  ServiceKey,
  UserProfile,
} from '../types/account';
import {
  adminAdjustUserCoins,
  adminApprovePaymentRequest,
  adminRejectPaymentRequest,
  adminSaveCoinCosts,
  adminSetAccountStatus,
  adminToggleUserService,
  logAdminActivity,
} from '../services/firestoreService';

interface DsnBalanceSummary {
  currency: string;
  availableBalance: number;
  pendingFunds: number;
  reservedForWithdrawals: number;
  totalCollected: number;
  totalCollectionFees: number;
  totalNetEarnings: number;
}

interface DsnGatewayTransaction {
  id: number;
  orderId: string;
  gatewayReference: string;
  amount: number;
  currency: string;
  customerName: string;
  customerPhone: string;
  status: string;
  paymentChannel: string;
  createdAt: string;
  updatedAt: string;
}

interface DsnOverviewData {
  merchantId: string;
  webhookUrl: string;
  balance: DsnBalanceSummary;
  transactions: DsnGatewayTransaction[];
}

interface AdminControlPanelProps {
  currentAdminUid: string;
  currentAdminName: string;
  coinCosts: CoinCosts;
  paymentConfig: PaymentConfig;
  paymentRequests: PaymentRequestRecord[];
  adminLogs: AdminActivityLogRecord[];
}

export const AdminControlPanel: React.FC<AdminControlPanelProps> = ({
  currentAdminUid,
  currentAdminName,
  coinCosts,
  paymentConfig,
  paymentRequests,
  adminLogs,
}) => {
  const [adminSubTab, setAdminSubTab] = useState<'users' | 'payments' | 'pricing' | 'activity'>('users');
  const [users, setUsers] = useState<UserProfile[]>([]);
  const [loadingUsers, setLoadingUsers] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'active' | 'suspended'>('all');
  const [selectedUserId, setSelectedUserId] = useState<string | null>(null);
  const [userTransactions, setUserTransactions] = useState<CoinTransactionRecord[]>([]);
  const [busyMap, setBusyMap] = useState<Record<string, boolean>>({});
  const [feedback, setFeedback] = useState<{ type: 'ok' | 'err'; text: string } | null>(null);

  // Coin adjustment input state per user
  const [coinAmountInput, setCoinAmountInput] = useState<Record<string, string>>({});
  const [coinNoteInput, setCoinNoteInput] = useState<Record<string, string>>({});

  // Payment queue filter, search & admin notes
  const [paymentFilter, setPaymentFilter] = useState<'all' | 'pending' | 'approved' | 'rejected'>('pending');
  const [paymentSearch, setPaymentSearch] = useState('');
  const [paymentAdminNotes, setPaymentAdminNotes] = useState<Record<string, string>>({});

  // Admin activity log filters
  const [activitySearch, setActivitySearch] = useState('');
  const [activityCategoryFilter, setActivityCategoryFilter] = useState<'all' | AdminActivityCategory>('all');

  // Live DSN Collect balance & transactions overview
  const [dsnOverview, setDsnOverview] = useState<DsnOverviewData | null>(null);
  const [loadingDsnOverview, setLoadingDsnOverview] = useState(false);
  const [dsnOverviewError, setDsnOverviewError] = useState<string | null>(null);
  const [syncingDsnPending, setSyncingDsnPending] = useState(false);

  // Global coin pricing & payment config state
  const [draftCosts, setDraftCosts] = useState<CoinCosts>(coinCosts);
  const [draftPaymentConfig, setDraftPaymentConfig] = useState<PaymentConfig>(paymentConfig);
  const [savingCosts, setSavingCosts] = useState(false);

  useEffect(() => {
    setDraftCosts(coinCosts);
  }, [coinCosts]);

  useEffect(() => {
    setDraftPaymentConfig(paymentConfig);
  }, [paymentConfig]);

  useEffect(() => {
    const usersQuery = query(
      collection(db, 'users'),
      orderBy('createdAt', 'desc')
    );
    const unsub = onSnapshot(
      usersQuery,
      (snap) => {
        const list: UserProfile[] = snap.docs.map((d) => d.data() as UserProfile);
        setUsers(list);
        setLoadingUsers(false);
      },
      (err) => {
        setLoadingUsers(false);
        handleFirestoreError(err, OperationType.LIST, 'users');
      }
    );
    return () => unsub();
  }, []);

  useEffect(() => {
    if (!selectedUserId) {
      setUserTransactions([]);
      return;
    }
    const txQuery = query(
      collection(db, 'users', selectedUserId, 'coinTransactions'),
      orderBy('createdAt', 'desc'),
      limit(15)
    );
    const unsub = onSnapshot(
      txQuery,
      (snap) => {
        setUserTransactions(
          snap.docs.map((d) => ({
            id: d.id,
            ...(d.data() as Omit<CoinTransactionRecord, 'id'>),
          }))
        );
      },
      (err) => {
        handleFirestoreError(
          err,
          OperationType.LIST,
          `users/${selectedUserId}/coinTransactions`
        );
      }
    );
    return () => unsub();
  }, [selectedUserId]);

  const filteredUsers = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    return users.filter((u) => {
      if (statusFilter !== 'all' && u.accountStatus !== statusFilter) {
        return false;
      }
      if (!q) return true;
      return (
        u.fullName.toLowerCase().includes(q) ||
        u.phone.toLowerCase().includes(q) ||
        u.email.toLowerCase().includes(q)
      );
    });
  }, [users, searchQuery, statusFilter]);

  const metrics = useMemo(() => {
    const totalUsers = users.length;
    const activeUsers = users.filter((u) => u.accountStatus === 'active').length;
    const totalCoins = users.reduce((sum, u) => sum + (u.coins || 0), 0);
    const totalEnabledServices = users.reduce(
      (sum, u) =>
        sum +
        Object.values(u.services || {}).filter(Boolean).length,
      0
    );
    return { totalUsers, activeUsers, totalCoins, totalEnabledServices };
  }, [users]);

  const handleToggleSingleService = async (
    user: UserProfile,
    serviceKey: ServiceKey
  ) => {
    const busyKey = `${user.uid}:${serviceKey}`;
    setBusyMap((prev) => ({ ...prev, [busyKey]: true }));
    setFeedback(null);
    try {
      const nextVal = !Boolean(user.services?.[serviceKey]);
      const nextServices = {
        ...EMPTY_SERVICES,
        ...user.services,
        [serviceKey]: nextVal,
      };
      const svcLabel =
        SERVICE_DEFINITIONS.find((s) => s.key === serviceKey)?.label || serviceKey;
      await adminToggleUserService({
        targetUid: user.uid,
        services: nextServices,
        actorUid: currentAdminUid,
        actorName: currentAdminName,
        targetLabel: `${user.fullName} (${user.phone})`,
        actionTitle: nextVal
          ? `Amewasha huduma: ${svcLabel}`
          : `Amezima huduma: ${svcLabel}`,
        auditDetails: `Huduma "${svcLabel}" (${serviceKey}) imewekwa kuwa ${nextVal ? 'IMEWASHWA (ON)' : 'IMEZIMWA (OFF)'}.`,
      });
    } catch (err) {
      setFeedback({
        type: 'err',
        text: err instanceof Error ? err.message : 'Imeshindikana kubadili huduma.',
      });
    } finally {
      setBusyMap((prev) => ({ ...prev, [busyKey]: false }));
    }
  };

  const handleToggleAllServices = async (user: UserProfile, enable: boolean) => {
    const busyKey = `${user.uid}:all`;
    setBusyMap((prev) => ({ ...prev, [busyKey]: true }));
    setFeedback(null);
    try {
      await adminToggleUserService({
        targetUid: user.uid,
        services: enable ? ALL_ENABLED_SERVICES : EMPTY_SERVICES,
        actorUid: currentAdminUid,
        actorName: currentAdminName,
        targetLabel: `${user.fullName} (${user.phone})`,
        actionTitle: enable
          ? 'Amewasha huduma zote kwa mtumiaji'
          : 'Amezima huduma zote kwa mtumiaji',
        auditDetails: enable
          ? 'Huduma zote 6 (Editor, TIN, PNG, PDF, Live QR, Hifadhi) zimewashwa.'
          : 'Huduma zote 6 zimezimwa.',
      });
    } catch (err) {
      setFeedback({
        type: 'err',
        text: err instanceof Error ? err.message : 'Imeshindikana kubadili huduma.',
      });
    } finally {
      setBusyMap((prev) => ({ ...prev, [busyKey]: false }));
    }
  };

  const handleToggleStatus = async (user: UserProfile) => {
    const busyKey = `${user.uid}:status`;
    setBusyMap((prev) => ({ ...prev, [busyKey]: true }));
    setFeedback(null);
    try {
      await adminSetAccountStatus({
        targetUid: user.uid,
        accountStatus: user.accountStatus === 'active' ? 'suspended' : 'active',
        actorUid: currentAdminUid,
        actorName: currentAdminName,
        targetLabel: `${user.fullName} (${user.phone})`,
      });
    } catch (err) {
      setFeedback({
        type: 'err',
        text: err instanceof Error ? err.message : 'Imeshindikana kubadili hali ya akaunti.',
      });
    } finally {
      setBusyMap((prev) => ({ ...prev, [busyKey]: false }));
    }
  };

  const handleCoinAction = async (
    user: UserProfile,
    mode: 'topup' | 'deduct',
    presetAmount?: number
  ) => {
    const rawAmt = presetAmount ?? Number(coinAmountInput[user.uid] || 0);
    if (!Number.isInteger(rawAmt) || rawAmt <= 0) {
      setFeedback({
        type: 'err',
        text: 'Ingiza idadi halali ya coin (namba kamili zaidi ya 0).',
      });
      return;
    }
    const busyKey = `${user.uid}:coins`;
    setBusyMap((prev) => ({ ...prev, [busyKey]: true }));
    setFeedback(null);
    try {
      await adminAdjustUserCoins({
        targetUid: user.uid,
        adminUid: currentAdminUid,
        actorName: currentAdminName,
        targetLabel: `${user.fullName} (${user.phone})`,
        currentCoins: user.coins,
        mode,
        amount: rawAmt,
        note:
          coinNoteInput[user.uid] ||
          (mode === 'topup' ? 'Admin ameongeza coin' : 'Admin amepunguza coin'),
      });
      setCoinAmountInput((prev) => ({ ...prev, [user.uid]: '' }));
      setCoinNoteInput((prev) => ({ ...prev, [user.uid]: '' }));
      setFeedback({
        type: 'ok',
        text: `${mode === 'topup' ? 'Zimeongezwa' : 'Zimepunguzwa'} coin ${rawAmt} kwa ${user.fullName}.`,
      });
    } catch (err) {
      setFeedback({
        type: 'err',
        text: err instanceof Error ? err.message : 'Imeshindikana kurekebisha coin.',
      });
    } finally {
      setBusyMap((prev) => ({ ...prev, [busyKey]: false }));
    }
  };

  const fetchDsnOverview = async () => {
    const user = auth.currentUser;
    if (!user) return;
    setLoadingDsnOverview(true);
    setDsnOverviewError(null);
    try {
      const idToken = await user.getIdToken();
      const res = await fetch('/api/payments/dsn/overview', {
        headers: {
          Authorization: `Bearer ${idToken}`,
        },
      });
      const json = (await res.json()) as Partial<DsnOverviewData> & {
        ok?: boolean;
        message?: string;
      };
      if (!res.ok || !json.ok || !json.balance) {
        throw new Error(
          json.message || 'Imeshindikana kuvuta salio la DSN Collect.'
        );
      }
      setDsnOverview({
        merchantId: json.merchantId || 'DSN-0036',
        webhookUrl: json.webhookUrl || '/api/payments/dsn/webhook',
        balance: json.balance,
        transactions: json.transactions || [],
      });
    } catch (err) {
      setDsnOverviewError(
        err instanceof Error
          ? err.message
          : 'Hitilafu ya mtandao wa DSN Collect.'
      );
    } finally {
      setLoadingDsnOverview(false);
    }
  };

  useEffect(() => {
    void fetchDsnOverview();
  }, []);

  const userByUid = useMemo(() => {
    const map = new Map<string, UserProfile>();
    for (const u of users) {
      map.set(u.uid, u);
    }
    return map;
  }, [users]);

  const paymentSummary = useMemo(() => {
    let approvedTzs = 0;
    let approvedCoins = 0;
    let approvedCount = 0;
    let pendingTzs = 0;
    let pendingCount = 0;
    let rejectedCount = 0;

    for (const p of paymentRequests) {
      if (p.status === 'approved') {
        approvedTzs += p.amountTzs || 0;
        approvedCoins += p.coins || 0;
        approvedCount += 1;
      } else if (p.status === 'pending') {
        pendingTzs += p.amountTzs || 0;
        pendingCount += 1;
      } else if (p.status === 'rejected') {
        rejectedCount += 1;
      }
    }
    return {
      approvedTzs,
      approvedCoins,
      approvedCount,
      pendingTzs,
      pendingCount,
      rejectedCount,
    };
  }, [paymentRequests]);

  const pendingPaymentsCount = paymentSummary.pendingCount;

  const filteredPayments = useMemo(() => {
    const q = paymentSearch.trim().toLowerCase();
    return paymentRequests.filter((p) => {
      if (paymentFilter !== 'all' && p.status !== paymentFilter) {
        return false;
      }
      if (!q) return true;
      return (
        p.transactionRef.toLowerCase().includes(q) ||
        p.userFullName.toLowerCase().includes(q) ||
        p.userPhone.toLowerCase().includes(q) ||
        p.payerPhone.toLowerCase().includes(q) ||
        p.payerName.toLowerCase().includes(q)
      );
    });
  }, [paymentRequests, paymentFilter, paymentSearch]);

  const activityStats = useMemo(() => {
    let servicesAndAccounts = 0;
    let coinsAndPayments = 0;
    let settingsAndDocs = 0;
    for (const log of adminLogs) {
      if (log.category === 'service_toggle' || log.category === 'account_status') {
        servicesAndAccounts += 1;
      } else if (
        log.category === 'coin_adjustment' ||
        log.category === 'payment_approve' ||
        log.category === 'payment_reject' ||
        log.category === 'dsn_sync'
      ) {
        coinsAndPayments += 1;
      } else {
        settingsAndDocs += 1;
      }
    }
    return {
      total: adminLogs.length,
      servicesAndAccounts,
      coinsAndPayments,
      settingsAndDocs,
    };
  }, [adminLogs]);

  const filteredAdminLogs = useMemo(() => {
    const q = activitySearch.trim().toLowerCase();
    return adminLogs.filter((log) => {
      if (activityCategoryFilter !== 'all' && log.category !== activityCategoryFilter) {
        return false;
      }
      if (!q) return true;
      return (
        log.actionTitle.toLowerCase().includes(q) ||
        log.actorName.toLowerCase().includes(q) ||
        log.actorEmail.toLowerCase().includes(q) ||
        log.targetLabel.toLowerCase().includes(q) ||
        log.details.toLowerCase().includes(q)
      );
    });
  }, [adminLogs, activitySearch, activityCategoryFilter]);

  const handleSaveGlobalCosts = async (e: React.FormEvent) => {
    e.preventDefault();
    setSavingCosts(true);
    setFeedback(null);
    try {
      await adminSaveCoinCosts({
        adminUid: currentAdminUid,
        actorName: currentAdminName,
        coinCosts: draftCosts,
        paymentConfig: draftPaymentConfig,
      });
      setFeedback({
        type: 'ok',
        text: 'Bei za coin, namba za malipo, na vifurushi vimehifadhiwa.',
      });
    } catch (err) {
      setFeedback({
        type: 'err',
        text: err instanceof Error ? err.message : 'Imeshindikana kuhifadhi mipangilio.',
      });
    } finally {
      setSavingCosts(false);
    }
  };

  const handleApprovePayment = async (payment: PaymentRequestRecord) => {
    const busyKey = `pay:${payment.id}`;
    setBusyMap((prev) => ({ ...prev, [busyKey]: true }));
    setFeedback(null);
    try {
      const nextBalance = await adminApprovePaymentRequest({
        payment,
        adminUid: currentAdminUid,
        actorName: currentAdminName,
        adminNote: paymentAdminNotes[payment.id] || '',
      });
      setFeedback({
        type: 'ok',
        text: `Malipo ${payment.transactionRef} yamekubaliwa. ${payment.userFullName} ameongezewa coin ${payment.coins} (Salio jipya: ${nextBalance}).`,
      });
    } catch (err) {
      setFeedback({
        type: 'err',
        text: err instanceof Error ? err.message : 'Imeshindikana kukubali malipo.',
      });
    } finally {
      setBusyMap((prev) => ({ ...prev, [busyKey]: false }));
    }
  };

  const handleRejectPayment = async (payment: PaymentRequestRecord) => {
    const busyKey = `pay:${payment.id}`;
    setBusyMap((prev) => ({ ...prev, [busyKey]: true }));
    setFeedback(null);
    try {
      await adminRejectPaymentRequest({
        paymentId: payment.id,
        adminUid: currentAdminUid,
        actorName: currentAdminName,
        transactionRef: payment.transactionRef,
        targetUid: payment.userId,
        targetLabel: `${payment.userFullName} (${payment.userPhone})`,
        adminNote: paymentAdminNotes[payment.id] || '',
      });
      setFeedback({
        type: 'ok',
        text: `Ombi ${payment.transactionRef} limekataliwa.`,
      });
    } catch (err) {
      setFeedback({
        type: 'err',
        text: err instanceof Error ? err.message : 'Imeshindikana kukataa malipo.',
      });
    } finally {
      setBusyMap((prev) => ({ ...prev, [busyKey]: false }));
    }
  };

  const handleVerifyDsnPayment = async (payment: PaymentRequestRecord) => {
    const busyKey = `paycheck:${payment.id}`;
    setBusyMap((prev) => ({ ...prev, [busyKey]: true }));
    setFeedback(null);
    try {
      const res = await fetch(
        `/api/payments/dsn/status/${encodeURIComponent(payment.transactionRef)}`
      );
      const json = (await res.json()) as {
        ok?: boolean;
        paid?: boolean;
        failed?: boolean;
        status?: string;
        channel?: string;
        message?: string;
      };
      if (!res.ok || !json.ok) {
        throw new Error(json.message || 'Imeshindikana kukagua muamala kwenye DSN.');
      }
      void logAdminActivity({
        actorUid: currentAdminUid,
        actorName: currentAdminName,
        category: 'dsn_sync',
        actionTitle: `Amekagua muamala ${payment.transactionRef} kwenye DSN`,
        targetUid: payment.userId,
        targetLabel: `${payment.userFullName} (${payment.userPhone})`,
        details: `Hali ya DSN: ${json.status || 'pending'}${json.channel ? ` · Mtandao: ${json.channel}` : ''}`,
      }).catch(() => {});
      setFeedback({
        type: json.failed ? 'err' : 'ok',
        text: json.paid
          ? `DSN Collect imethibitisha malipo ya ${payment.transactionRef}${json.channel ? ` (${json.channel})` : ''}. Unaweza kukubali sasa.`
          : `Hali kwenye DSN Collect kwa ${payment.transactionRef}: ${json.status || 'pending'}.`,
      });
    } catch (err) {
      setFeedback({
        type: 'err',
        text: err instanceof Error ? err.message : 'Hitilafu ya kukagua DSN.',
      });
    } finally {
      setBusyMap((prev) => ({ ...prev, [busyKey]: false }));
    }
  };

  const handleSyncAllPendingDsn = async () => {
    setSyncingDsnPending(true);
    setFeedback(null);
    let creditedCount = 0;
    let creditedCoins = 0;
    try {
      await fetchDsnOverview();
      const pendingDsn = paymentRequests.filter(
        (p) =>
          p.status === 'pending' &&
          (p.transactionRef.startsWith('DSN_') ||
            p.transactionRef.startsWith('ORD-') ||
            p.userNote.includes('DSN Collect'))
      );
      for (const pay of pendingDsn) {
        const res = await fetch(
          `/api/payments/dsn/status/${encodeURIComponent(pay.transactionRef)}`
        );
        if (!res.ok) continue;
        const json = (await res.json()) as {
          ok?: boolean;
          paid?: boolean;
          channel?: string;
        };
        if (json.ok && json.paid) {
          await adminApprovePaymentRequest({
            payment: pay,
            adminUid: currentAdminUid,
            actorName: currentAdminName,
            adminNote: `Imethibitishwa na DSN Collect${json.channel ? ` (${json.channel})` : ''}.`,
          });
          creditedCount += 1;
          creditedCoins += pay.coins;
        }
      }
      void logAdminActivity({
        actorUid: currentAdminUid,
        actorName: currentAdminName,
        category: 'dsn_sync',
        actionTitle: 'Amesawazisha salio na miamala ya DSN Collect',
        targetUid: '',
        targetLabel: 'DSN Collect Gateway',
        details:
          creditedCount > 0
            ? `Amethibitisha miamala ${creditedCount} na kuongeza Coin ${creditedCoins}.`
            : `Amesawazisha salio la DSN (${pendingDsn.length} yanayosubiri yalikaguliwa).`,
      }).catch(() => {});
      setFeedback({
        type: 'ok',
        text:
          creditedCount > 0
            ? `Imethibitisha miamala ${creditedCount} ya DSN Collect na kuongeza Coin ${creditedCoins} kiotomatiki.`
            : 'Salio na miamala ya DSN Collect imesawazishwa. Hakuna malipo mapya yaliyokuwa yamebakia.',
      });
    } catch (err) {
      setFeedback({
        type: 'err',
        text:
          err instanceof Error
            ? err.message
            : 'Imeshindikana kusawazisha malipo ya DSN Collect.',
      });
    } finally {
      setSyncingDsnPending(false);
    }
  };

  return (
    <div className="flex-1 overflow-y-auto bg-[#f4f6f8] p-6 lg:p-8">
      <div className="max-w-6xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <h2 className="font-display text-xl font-semibold text-slate-900">
              Admin Control Panel
            </h2>
            <p className="text-sm text-slate-600 mt-0.5">
              Washa au zima huduma moja moja kwa kila mtumiaji na dhibiti salio lao la coin.
            </p>
          </div>
        </div>

        {feedback && (
          <div
            role="status"
            className={`rounded-lg border px-4 py-2.5 text-xs font-medium ${
              feedback.type === 'ok'
                ? 'border-emerald-200 bg-emerald-50 text-emerald-800'
                : 'border-red-200 bg-red-50 text-red-700'
            }`}
          >
            {feedback.text}
          </div>
        )}

        {/* 4-column Summary Metrics */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          <div className="bg-white border border-slate-200 rounded-lg p-4">
            <p className="text-xs text-slate-500">Watumiaji Wote</p>
            <p className="text-2xl font-semibold text-slate-900 tabular-nums mt-1">
              {metrics.totalUsers}
            </p>
          </div>
          <div className="bg-white border border-slate-200 rounded-lg p-4">
            <p className="text-xs text-slate-500">Akaunti Hai</p>
            <p className="text-2xl font-semibold text-emerald-700 tabular-nums mt-1">
              {metrics.activeUsers}
            </p>
          </div>
          <div className="bg-white border border-slate-200 rounded-lg p-4">
            <p className="text-xs text-slate-500">Jumla ya Coin</p>
            <p className="text-2xl font-semibold text-[#0f4c75] tabular-nums mt-1">
              {metrics.totalCoins.toLocaleString()}
            </p>
          </div>
          <div className="bg-white border border-slate-200 rounded-lg p-4">
            <p className="text-xs text-slate-500">Malipo Yanayosubiri</p>
            <p className="text-2xl font-semibold text-amber-700 tabular-nums mt-1">
              {pendingPaymentsCount}
            </p>
          </div>
        </div>

        {/* Admin Control Panel Internal Navigation */}
        <div className="border-b border-slate-200 flex items-center gap-6 text-sm font-medium overflow-x-auto">
          <button
            type="button"
            onClick={() => setAdminSubTab('users')}
            className={`py-2.5 border-b-2 transition-colors whitespace-nowrap shrink-0 ${
              adminSubTab === 'users'
                ? 'border-[#0f4c75] text-slate-900'
                : 'border-transparent text-slate-500 hover:text-slate-900'
            }`}
          >
            Watumiaji &amp; Huduma ({metrics.totalUsers})
          </button>
          <button
            type="button"
            onClick={() => setAdminSubTab('payments')}
            className={`py-2.5 border-b-2 transition-colors whitespace-nowrap shrink-0 ${
              adminSubTab === 'payments'
                ? 'border-[#0f4c75] text-slate-900'
                : 'border-transparent text-slate-500 hover:text-slate-900'
            }`}
          >
            Maombi ya Malipo ({pendingPaymentsCount})
          </button>
          <button
            type="button"
            onClick={() => setAdminSubTab('pricing')}
            className={`py-2.5 border-b-2 transition-colors whitespace-nowrap shrink-0 ${
              adminSubTab === 'pricing'
                ? 'border-[#0f4c75] text-slate-900'
                : 'border-transparent text-slate-500 hover:text-slate-900'
            }`}
          >
            Bei &amp; Namba za Malipo
          </button>
          <button
            type="button"
            onClick={() => setAdminSubTab('activity')}
            className={`py-2.5 border-b-2 transition-colors whitespace-nowrap shrink-0 ${
              adminSubTab === 'activity'
                ? 'border-[#0f4c75] text-slate-900'
                : 'border-transparent text-slate-500 hover:text-slate-900'
            }`}
          >
            Matendo ya Admin ({adminLogs.length})
          </button>
        </div>

        {/* Sub-tab 0: Real-Time Admin Activity Audit Log */}
        {adminSubTab === 'activity' && (
          <div className="space-y-5">
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-3.5">
              <div className="bg-white border border-slate-200 rounded-lg p-4">
                <p className="text-xs text-slate-500">Jumla ya Matendo</p>
                <p className="text-2xl font-semibold font-mono-tabular text-slate-900 mt-1">
                  {activityStats.total}
                </p>
              </div>
              <div className="bg-white border border-slate-200 rounded-lg p-4">
                <p className="text-xs text-slate-500">Huduma &amp; Akaunti</p>
                <p className="text-2xl font-semibold font-mono-tabular text-[#0f4c75] mt-1">
                  {activityStats.servicesAndAccounts}
                </p>
              </div>
              <div className="bg-white border border-slate-200 rounded-lg p-4">
                <p className="text-xs text-slate-500">Coin &amp; Malipo</p>
                <p className="text-2xl font-semibold font-mono-tabular text-emerald-700 mt-1">
                  {activityStats.coinsAndPayments}
                </p>
              </div>
              <div className="bg-white border border-slate-200 rounded-lg p-4">
                <p className="text-xs text-slate-500">Mipangilio &amp; Nyaraka</p>
                <p className="text-2xl font-semibold font-mono-tabular text-slate-700 mt-1">
                  {activityStats.settingsAndDocs}
                </p>
              </div>
            </div>

            <div className="bg-white border border-slate-200 rounded-xl p-5 space-y-4">
              <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-3">
                <div className="flex items-center gap-2">
                  <Activity className="w-4 h-4 text-[#0f4c75]" aria-hidden="true" />
                  <div>
                    <h3 className="text-sm font-semibold text-slate-900">
                      Kumbukumbu ya Kila Kitu Anachofanya Admin
                    </h3>
                    <p className="text-xs text-slate-500">
                      Kila hatua ya Admin inarekodiwa moja kwa moja na haiwezi kufutwa wala kubadilishwa.
                    </p>
                  </div>
                </div>

                <div className="relative w-full lg:w-72">
                  <Search
                    className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2"
                    aria-hidden="true"
                  />
                  <input
                    type="text"
                    value={activitySearch}
                    onChange={(e) => setActivitySearch(e.target.value)}
                    placeholder="Tafuta hatua, mtumiaji, au maelezo..."
                    className="w-full rounded-lg border border-slate-200 bg-white pl-8 pr-3 py-1.5 text-xs text-slate-900 focus:border-[#0f4c75] focus:outline-none"
                  />
                </div>
              </div>

              <div className="flex flex-wrap items-center gap-1.5">
                <button
                  type="button"
                  onClick={() => setActivityCategoryFilter('all')}
                  className={`px-3 py-1.5 text-xs font-medium rounded-md border transition-colors ${
                    activityCategoryFilter === 'all'
                      ? 'bg-[#0f4c75] text-white border-[#0f4c75]'
                      : 'bg-slate-50 text-slate-600 border-slate-200 hover:text-slate-900'
                  }`}
                >
                  Yote ({adminLogs.length})
                </button>
                {(Object.keys(ADMIN_ACTIVITY_CATEGORY_LABELS) as AdminActivityCategory[]).map(
                  (cat) => (
                    <button
                      key={cat}
                      type="button"
                      onClick={() => setActivityCategoryFilter(cat)}
                      className={`px-3 py-1.5 text-xs font-medium rounded-md border transition-colors ${
                        activityCategoryFilter === cat
                          ? 'bg-[#0f4c75] text-white border-[#0f4c75]'
                          : 'bg-slate-50 text-slate-600 border-slate-200 hover:text-slate-900'
                      }`}
                    >
                      {ADMIN_ACTIVITY_CATEGORY_LABELS[cat]}
                    </button>
                  )
                )}
              </div>

              {filteredAdminLogs.length === 0 ? (
                <div className="py-10 text-center text-sm text-slate-500 border border-dashed border-slate-200 rounded-lg">
                  Hakuna matendo ya Admin yaliyorekodiwa bado kwa kichujio hiki.
                </div>
              ) : (
                <div className="overflow-x-auto border border-slate-200 rounded-lg">
                  <table className="w-full text-xs text-left">
                    <thead className="bg-slate-50 border-b border-slate-200 text-slate-600">
                      <tr>
                        <th className="py-2.5 px-4 font-medium">Muda</th>
                        <th className="py-2.5 px-4 font-medium">Sehemu</th>
                        <th className="py-2.5 px-4 font-medium">Hatua Iliyofanywa</th>
                        <th className="py-2.5 px-4 font-medium">Mlengwa</th>
                        <th className="py-2.5 px-4 font-medium">Maelezo Kamili</th>
                        <th className="py-2.5 px-4 font-medium">Aliyefanya (Admin)</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {filteredAdminLogs.map((log) => {
                        const timeLabel = log.createdAt
                          ? new Date(log.createdAt.toMillis()).toLocaleString('en-GB', {
                              dateStyle: 'short',
                              timeStyle: 'medium',
                            })
                          : 'Hivi punde';
                        return (
                          <tr key={log.id} className="hover:bg-slate-50/70 align-top">
                            <td className="py-3 px-4 font-mono-tabular text-slate-500 whitespace-nowrap">
                              {timeLabel}
                            </td>
                            <td className="py-3 px-4 whitespace-nowrap font-medium text-[#0f4c75]">
                              {ADMIN_ACTIVITY_CATEGORY_LABELS[log.category] || log.category}
                            </td>
                            <td className="py-3 px-4 font-semibold text-slate-900">
                              {log.actionTitle}
                            </td>
                            <td className="py-3 px-4 text-slate-700 whitespace-nowrap">
                              {log.targetLabel || '—'}
                            </td>
                            <td className="py-3 px-4 text-slate-600 max-w-md">
                              {log.details}
                            </td>
                            <td className="py-3 px-4 text-slate-600 whitespace-nowrap">
                              <p className="font-medium text-slate-900">{log.actorName}</p>
                              <p className="text-[11px] text-slate-400">{log.actorEmail}</p>
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          </div>
        )}

        {/* Sub-tab 1: Payment System Overview, Live DSN Balance & Approvals Queue */}
        {adminSubTab === 'payments' && (
          <div className="space-y-6">
            {/* Live DSN Collect Gateway Balance & Controls */}
            <section className="bg-white border border-slate-200 rounded-xl p-5 space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div className="flex items-center gap-2.5">
                  <Wallet className="w-5 h-5 text-[#0f4c75]" aria-hidden="true" />
                  <div>
                    <h3 className="text-sm font-semibold text-slate-900">
                      Salio la Akaunti ya DSN Collect ({dsnOverview?.merchantId || 'DSN-0036'})
                    </h3>
                    <p className="text-xs text-slate-500">
                      Malipo yaliyolipwa kupitia USSD Push yanathibitishwa na kuongeza Coin kwa mteja kiotomatiki.
                    </p>
                  </div>
                </div>

                <div className="flex flex-wrap items-center gap-2">
                  <button
                    type="button"
                    disabled={loadingDsnOverview}
                    onClick={() => void fetchDsnOverview()}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-700 border border-slate-200 hover:bg-slate-50 disabled:opacity-60 rounded-lg transition-colors"
                  >
                    <RefreshCw
                      className={`w-3.5 h-3.5 ${loadingDsnOverview ? 'animate-spin' : ''}`}
                      aria-hidden="true"
                    />
                    Onyesha Upya Salio
                  </button>
                  <button
                    type="button"
                    disabled={syncingDsnPending}
                    onClick={() => void handleSyncAllPendingDsn()}
                    className="inline-flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-medium text-white bg-[#0f4c75] hover:bg-[#0b3a5b] disabled:opacity-60 rounded-lg transition-colors"
                  >
                    <CheckCircle2 className="w-3.5 h-3.5" aria-hidden="true" />
                    {syncingDsnPending
                      ? 'Inasawazisha...'
                      : 'Sawazisha & Ongeza Coin'}
                  </button>
                </div>
              </div>

              {dsnOverviewError && (
                <div className="rounded-lg border border-red-200 bg-red-50 px-3.5 py-2.5 text-xs text-red-700">
                  {dsnOverviewError}
                </div>
              )}

              <div className="grid grid-cols-2 lg:grid-cols-4 gap-3.5">
                <div className="rounded-lg border border-emerald-200 bg-emerald-50/50 p-3.5">
                  <p className="text-[11px] font-medium text-emerald-800">
                    Salio Linaloweza Kutolewa
                  </p>
                  <p className="text-xl font-semibold font-mono-tabular text-emerald-900 mt-1">
                    {dsnOverview
                      ? `${dsnOverview.balance.availableBalance.toLocaleString()} ${dsnOverview.balance.currency}`
                      : loadingDsnOverview
                        ? 'Inapakia...'
                        : '—'}
                  </p>
                </div>

                <div className="rounded-lg border border-amber-200 bg-amber-50/50 p-3.5">
                  <p className="text-[11px] font-medium text-amber-800">
                    Fedha Zinazosubiri (Pending)
                  </p>
                  <p className="text-xl font-semibold font-mono-tabular text-amber-900 mt-1">
                    {dsnOverview
                      ? `${dsnOverview.balance.pendingFunds.toLocaleString()} ${dsnOverview.balance.currency}`
                      : loadingDsnOverview
                        ? 'Inapakia...'
                        : '—'}
                  </p>
                </div>

                <div className="rounded-lg border border-slate-200 bg-slate-50 p-3.5">
                  <p className="text-[11px] font-medium text-slate-600">
                    Jumla Iliyokusanywa (DSN)
                  </p>
                  <p className="text-xl font-semibold font-mono-tabular text-slate-900 mt-1">
                    {dsnOverview
                      ? `${dsnOverview.balance.totalCollected.toLocaleString()} ${dsnOverview.balance.currency}`
                      : loadingDsnOverview
                        ? 'Inapakia...'
                        : '—'}
                  </p>
                  {dsnOverview && (
                    <p className="text-[11px] text-slate-500 font-mono-tabular mt-0.5">
                      Makato: {dsnOverview.balance.totalCollectionFees.toLocaleString()} TZS
                    </p>
                  )}
                </div>

                <div className="rounded-lg border border-slate-200 bg-slate-50 p-3.5">
                  <p className="text-[11px] font-medium text-slate-600">
                    Mapato Halisi (Net Earnings)
                  </p>
                  <p className="text-xl font-semibold font-mono-tabular text-[#0f4c75] mt-1">
                    {dsnOverview
                      ? `${dsnOverview.balance.totalNetEarnings.toLocaleString()} ${dsnOverview.balance.currency}`
                      : loadingDsnOverview
                        ? 'Inapakia...'
                        : '—'}
                  </p>
                  {dsnOverview && (
                    <p className="text-[11px] text-slate-500 font-mono-tabular mt-0.5">
                      Zilizotengwa: {dsnOverview.balance.reservedForWithdrawals.toLocaleString()} TZS
                    </p>
                  )}
                </div>
              </div>

              {/* Internal System Totals */}
              <div className="grid grid-cols-2 lg:grid-cols-4 gap-3.5 pt-1 border-t border-slate-100">
                <div className="p-2">
                  <p className="text-[11px] text-slate-500">
                    Malipo Yaliyoidhinishwa (Mfumo)
                  </p>
                  <p className="text-base font-semibold font-mono-tabular text-slate-900 mt-0.5">
                    {paymentSummary.approvedTzs.toLocaleString()} TZS ({paymentSummary.approvedCount})
                  </p>
                </div>
                <div className="p-2">
                  <p className="text-[11px] text-slate-500">
                    Coin Zilizoongezwa (Top-ups)
                  </p>
                  <p className="text-base font-semibold font-mono-tabular text-emerald-700 mt-0.5">
                    +{paymentSummary.approvedCoins.toLocaleString()} Coins
                  </p>
                </div>
                <div className="p-2">
                  <p className="text-[11px] text-slate-500">
                    Salio la Coin za Watumiaji Wote
                  </p>
                  <p className="text-base font-semibold font-mono-tabular text-[#0f4c75] mt-0.5">
                    {metrics.totalCoins.toLocaleString()} Coins
                  </p>
                </div>
                <div className="p-2">
                  <p className="text-[11px] text-slate-500">
                    Maombi Yanayosubiri
                  </p>
                  <p className="text-base font-semibold font-mono-tabular text-amber-700 mt-0.5">
                    {paymentSummary.pendingCount} ({paymentSummary.pendingTzs.toLocaleString()} TZS)
                  </p>
                </div>
              </div>
            </section>

            {/* User Payment Requests Queue */}
            <div className="space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div className="flex items-center gap-2">
                  <CreditCard className="w-4 h-4 text-[#0f4c75]" aria-hidden="true" />
                  <h3 className="text-sm font-semibold text-slate-900">
                    Maombi ya Malipo ya Watumiaji ({filteredPayments.length})
                  </h3>
                </div>

                <div className="flex flex-wrap items-center gap-2.5">
                  <div className="relative">
                    <Search
                      className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2"
                      aria-hidden="true"
                    />
                    <input
                      type="text"
                      value={paymentSearch}
                      onChange={(e) => setPaymentSearch(e.target.value)}
                      placeholder="Tafuta jina, simu, au Order ID..."
                      className="rounded-lg border border-slate-200 bg-white pl-8 pr-3 py-1.5 text-xs text-slate-900 focus:border-[#0f4c75] focus:outline-none w-56"
                    />
                  </div>

                  <div
                    className="flex items-center gap-1 p-1 bg-slate-200/70 rounded-lg"
                    role="group"
                    aria-label="Chuja maombi ya malipo"
                  >
                    {(
                      [
                        { id: 'pending', label: 'Inasubiri' },
                        { id: 'approved', label: 'Yamekubaliwa' },
                        { id: 'rejected', label: 'Yamekataliwa' },
                        { id: 'all', label: 'Yote' },
                      ] as const
                    ).map((tab) => (
                      <button
                        key={tab.id}
                        type="button"
                        onClick={() => setPaymentFilter(tab.id)}
                        className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 ${
                          paymentFilter === tab.id
                            ? 'bg-white text-slate-900 shadow-xs'
                            : 'text-slate-600 hover:text-slate-900'
                        }`}
                      >
                        {tab.label}
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              {filteredPayments.length === 0 ? (
                <div className="bg-white border border-slate-200 rounded-lg p-8 text-center text-sm text-slate-500">
                  Hakuna maombi ya malipo kwa kichujio hiki.
                </div>
              ) : (
                <div className="space-y-3">
                  {filteredPayments.map((pay) => {
                    const busy = Boolean(busyMap[`pay:${pay.id}`]);
                    const payerUser = userByUid.get(pay.userId);
                    const createdLabel = pay.createdAt
                      ? new Date(pay.createdAt.toMillis()).toLocaleString('en-GB', {
                          dateStyle: 'short',
                          timeStyle: 'short',
                        })
                      : 'Hivi punde';
                    return (
                      <div
                        key={pay.id}
                        className="bg-white border border-slate-200 rounded-lg p-5 flex flex-col lg:flex-row lg:items-center justify-between gap-4"
                      >
                        <div className="space-y-1.5 min-w-0">
                          <div className="flex flex-wrap items-center gap-2">
                            <span className="text-sm font-semibold font-mono-tabular text-slate-900">
                              {pay.transactionRef}
                            </span>
                            <span className="text-slate-300" aria-hidden="true">
                              ·
                            </span>
                            <span className="text-sm font-semibold text-slate-800">
                              {pay.userFullName}
                            </span>
                            {payerUser && (
                              <span className="text-xs font-mono-tabular text-slate-500">
                                (Salio: {payerUser.coins.toLocaleString()} Coins)
                              </span>
                            )}
                            <span className="text-slate-300" aria-hidden="true">
                              ·
                            </span>
                            {pay.status === 'approved' ? (
                              <span className="inline-flex items-center gap-1 text-xs font-medium text-emerald-700">
                                <CheckCircle2 className="w-3.5 h-3.5" aria-hidden="true" />
                                Imekubaliwa
                              </span>
                            ) : pay.status === 'rejected' ? (
                              <span className="inline-flex items-center gap-1 text-xs font-medium text-red-600">
                                <XCircle className="w-3.5 h-3.5" aria-hidden="true" />
                                Imekataliwa
                              </span>
                            ) : (
                              <span className="inline-flex items-center gap-1 text-xs font-medium text-amber-700">
                                <Clock className="w-3.5 h-3.5" aria-hidden="true" />
                                Inasubiri Uhakiki
                              </span>
                            )}
                          </div>

                          <div className="flex flex-wrap items-center gap-2 text-xs text-slate-600">
                            <span className="font-mono-tabular font-semibold text-[#0f4c75]">
                              +{pay.coins.toLocaleString()} Coins ({pay.amountTzs.toLocaleString()} TZS)
                            </span>
                            <span aria-hidden="true">·</span>
                            <span>{PAYMENT_NETWORK_LABELS[pay.network]}</span>
                            <span aria-hidden="true">·</span>
                            <span className="font-mono-tabular">
                              Mlipaji: {pay.payerName} ({pay.payerPhone})
                            </span>
                            <span aria-hidden="true">·</span>
                            <span className="text-slate-400">{createdLabel}</span>
                          </div>

                          {pay.userNote && (
                            <p className="text-xs text-slate-500">
                              Ujumbe wa mtumiaji: {pay.userNote}
                            </p>
                          )}
                          {pay.adminNote && pay.status !== 'pending' && (
                            <p className="text-xs text-slate-600">
                              Maelezo ya Admin: {pay.adminNote}
                            </p>
                          )}
                        </div>

                        {pay.status === 'pending' && (
                          <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2 shrink-0">
                            <input
                              type="text"
                              placeholder="Maelezo ya Admin (hiari)"
                              value={paymentAdminNotes[pay.id] || ''}
                              onChange={(e) =>
                                setPaymentAdminNotes((prev) => ({
                                  ...prev,
                                  [pay.id]: e.target.value,
                                }))
                              }
                              className="rounded-md border border-slate-200 px-3 py-2 text-xs text-slate-900 focus:border-[#0f4c75] focus:outline-none sm:w-48"
                            />
                            {(pay.transactionRef.startsWith('DSN_') ||
                              pay.transactionRef.startsWith('ORD-') ||
                              pay.userNote.includes('DSN Collect')) && (
                              <button
                                type="button"
                                disabled={Boolean(busyMap[`paycheck:${pay.id}`])}
                                onClick={() => handleVerifyDsnPayment(pay)}
                                className="px-3 py-2 text-xs font-medium text-[#0f4c75] border border-[#0f4c75]/30 hover:bg-[#0f4c75]/5 disabled:opacity-60 rounded-md transition-colors whitespace-nowrap"
                              >
                                Kagua DSN
                              </button>
                            )}
                            <button
                              type="button"
                              disabled={busy}
                              onClick={() => handleApprovePayment(pay)}
                              className="px-3.5 py-2 text-xs font-medium text-white bg-emerald-700 hover:bg-emerald-800 disabled:opacity-60 rounded-md transition-colors whitespace-nowrap"
                            >
                              Kubali &amp; Ongeza Coin
                            </button>
                            <button
                              type="button"
                              disabled={busy}
                              onClick={() => handleRejectPayment(pay)}
                              className="px-3.5 py-2 text-xs font-medium text-red-700 border border-red-200 hover:bg-red-50 disabled:opacity-60 rounded-md transition-colors whitespace-nowrap"
                            >
                              Kataa
                            </button>
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              )}
            </div>

            {/* Live DSN Collect Gateway Transactions Log */}
            <section className="bg-white border border-slate-200 rounded-xl overflow-hidden">
              <div className="px-5 py-4 border-b border-slate-200 flex items-center justify-between gap-2">
                <div>
                  <h3 className="text-sm font-semibold text-slate-900">
                    Miamala Yote ya DSN Collect Gateway ({dsnOverview?.transactions.length ?? 0})
                  </h3>
                  <p className="text-xs text-slate-500">
                    Taarifa halisi za moja kwa moja kutoka akaunti yako ya DSN Collect.
                  </p>
                </div>
              </div>

              {loadingDsnOverview && !dsnOverview ? (
                <div className="p-6 text-center text-xs text-slate-500">
                  Inapakia miamala kutoka DSN Collect...
                </div>
              ) : !dsnOverview || dsnOverview.transactions.length === 0 ? (
                <div className="p-6 text-center text-xs text-slate-500">
                  Hakuna miamala ya DSN Collect iliyopatikana kwa sasa.
                </div>
              ) : (
                <div className="overflow-x-auto max-h-96">
                  <table className="w-full text-xs text-left">
                    <thead className="sticky top-0 bg-slate-50 border-b border-slate-200 text-slate-600">
                      <tr>
                        <th className="py-2.5 px-4 font-medium">Order ID</th>
                        <th className="py-2.5 px-4 font-medium">Mteja &amp; Simu</th>
                        <th className="py-2.5 px-4 font-medium">Mtandao</th>
                        <th className="py-2.5 px-4 font-medium text-right">Kiasi</th>
                        <th className="py-2.5 px-4 font-medium">Hali (DSN)</th>
                        <th className="py-2.5 px-4 font-medium">Tarehe</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {dsnOverview.transactions.map((tx) => {
                        const s = tx.status.toLowerCase();
                        const isPaid = ['successful', 'success', 'completed', 'paid'].includes(s);
                        const isFailed = ['failed', 'cancelled', 'expired', 'rejected'].includes(s);
                        return (
                          <tr key={`${tx.id}-${tx.orderId}`} className="hover:bg-slate-50/60">
                            <td className="py-2.5 px-4 font-mono-tabular font-semibold text-slate-900 whitespace-nowrap">
                              {tx.orderId}
                            </td>
                            <td className="py-2.5 px-4">
                              <p className="font-medium text-slate-900">{tx.customerName || '—'}</p>
                              <p className="font-mono-tabular text-slate-500">{tx.customerPhone}</p>
                            </td>
                            <td className="py-2.5 px-4 text-slate-600 capitalize">
                              {tx.paymentChannel.replace(/_/g, ' ')}
                            </td>
                            <td className="py-2.5 px-4 text-right font-mono-tabular font-medium text-slate-900 whitespace-nowrap">
                              {tx.amount.toLocaleString()} {tx.currency}
                            </td>
                            <td className="py-2.5 px-4 whitespace-nowrap">
                              <span
                                className={`font-semibold ${
                                  isPaid
                                    ? 'text-emerald-700'
                                    : isFailed
                                      ? 'text-red-600'
                                      : 'text-amber-700'
                                }`}
                              >
                                {isPaid ? 'Imelipwa' : isFailed ? 'Imeshindikana' : tx.status}
                              </span>
                            </td>
                            <td className="py-2.5 px-4 font-mono-tabular text-slate-500 whitespace-nowrap">
                              {tx.createdAt}
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              )}
            </section>

            {/* All Users Coin Balances Snapshot */}
            <section className="bg-white border border-slate-200 rounded-xl overflow-hidden">
              <div className="px-5 py-4 border-b border-slate-200 flex items-center justify-between">
                <h3 className="text-sm font-semibold text-slate-900">
                  Salio la Coin la Kila Mtumiaji ({users.length})
                </h3>
                <span className="text-xs font-mono-tabular font-semibold text-[#0f4c75]">
                  Jumla: {metrics.totalCoins.toLocaleString()} Coins
                </span>
              </div>
              <div className="overflow-x-auto max-h-72">
                <table className="w-full text-xs text-left">
                  <thead className="sticky top-0 bg-slate-50 border-b border-slate-200 text-slate-600">
                    <tr>
                      <th className="py-2.5 px-4 font-medium">Jina Kamili</th>
                      <th className="py-2.5 px-4 font-medium">Namba ya Simu</th>
                      <th className="py-2.5 px-4 font-medium">Hali</th>
                      <th className="py-2.5 px-4 font-medium text-right">Salio la Coin</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {users.map((u) => (
                      <tr key={u.uid} className="hover:bg-slate-50/60">
                        <td className="py-2.5 px-4 font-medium text-slate-900">
                          {u.fullName} {u.role === 'admin' ? '(Admin)' : ''}
                        </td>
                        <td className="py-2.5 px-4 font-mono-tabular text-slate-600">
                          {u.phone}
                        </td>
                        <td className="py-2.5 px-4">
                          <span
                            className={
                              u.accountStatus === 'active'
                                ? 'text-emerald-700 font-medium'
                                : 'text-red-600 font-medium'
                            }
                          >
                            {u.accountStatus === 'active' ? 'Hai' : 'Imesimamishwa'}
                          </span>
                        </td>
                        <td className="py-2.5 px-4 text-right font-mono-tabular font-semibold text-slate-900">
                          {u.coins.toLocaleString()} Coins
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </section>
          </div>
        )}

        {/* Sub-tab 2: Global Coin Pricing & Payment Configuration */}
        {adminSubTab === 'pricing' && (
          <form onSubmit={handleSaveGlobalCosts} className="space-y-6">
            <div className="bg-white border border-slate-200 rounded-lg p-5 space-y-4">
              <div className="flex items-center justify-between gap-4">
                <div className="flex items-center gap-2">
                  <Sliders className="w-4 h-4 text-[#0f4c75]" aria-hidden="true" />
                  <h3 className="text-sm font-semibold text-slate-900">
                    Gharama za Coin kwa Kila Huduma
                  </h3>
                </div>
                <button
                  type="submit"
                  disabled={savingCosts}
                  className="px-4 py-2 text-xs font-medium text-white bg-[#0f4c75] hover:bg-[#0b3a5b] disabled:opacity-60 rounded-lg transition-colors whitespace-nowrap shrink-0"
                >
                  {savingCosts ? 'Inahifadhi...' : 'Hifadhi Mipangilio Yote'}
                </button>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                <div className="space-y-1">
                  <label
                    htmlFor="cost-exportPng"
                    className="block text-xs font-medium text-slate-600"
                  >
                    Export PNG (Coins)
                  </label>
                  <input
                    id="cost-exportPng"
                    type="number"
                    min={0}
                    max={10000}
                    value={draftCosts.exportPng}
                    onChange={(e) =>
                      setDraftCosts((prev) => ({
                        ...prev,
                        exportPng: Number(e.target.value) || 0,
                      }))
                    }
                    className="w-full rounded-md border border-slate-200 px-3 py-1.5 text-sm font-mono-tabular text-slate-900 focus:border-[#0f4c75] focus:outline-none"
                  />
                </div>

                <div className="space-y-1">
                  <label
                    htmlFor="cost-printPdf"
                    className="block text-xs font-medium text-slate-600"
                  >
                    Print / PDF (Coins)
                  </label>
                  <input
                    id="cost-printPdf"
                    type="number"
                    min={0}
                    max={10000}
                    value={draftCosts.printPdf}
                    onChange={(e) =>
                      setDraftCosts((prev) => ({
                        ...prev,
                        printPdf: Number(e.target.value) || 0,
                      }))
                    }
                    className="w-full rounded-md border border-slate-200 px-3 py-1.5 text-sm font-mono-tabular text-slate-900 focus:border-[#0f4c75] focus:outline-none"
                  />
                </div>

                <div className="space-y-1">
                  <label
                    htmlFor="cost-liveQr"
                    className="block text-xs font-medium text-slate-600"
                  >
                    Live Dynamic QR (Coins)
                  </label>
                  <input
                    id="cost-liveQr"
                    type="number"
                    min={0}
                    max={10000}
                    value={draftCosts.liveQr}
                    onChange={(e) =>
                      setDraftCosts((prev) => ({
                        ...prev,
                        liveQr: Number(e.target.value) || 0,
                      }))
                    }
                    className="w-full rounded-md border border-slate-200 px-3 py-1.5 text-sm font-mono-tabular text-slate-900 focus:border-[#0f4c75] focus:outline-none"
                  />
                </div>

                <div className="space-y-1">
                  <label
                    htmlFor="cost-saveRecord"
                    className="block text-xs font-medium text-slate-600"
                  >
                    Hifadhi Kumbukumbu (Coins)
                  </label>
                  <input
                    id="cost-saveRecord"
                    type="number"
                    min={0}
                    max={10000}
                    value={draftCosts.saveRecord}
                    onChange={(e) =>
                      setDraftCosts((prev) => ({
                        ...prev,
                        saveRecord: Number(e.target.value) || 0,
                      }))
                    }
                    className="w-full rounded-md border border-slate-200 px-3 py-1.5 text-sm font-mono-tabular text-slate-900 focus:border-[#0f4c75] focus:outline-none"
                  />
                </div>
              </div>
            </div>

            {/* Mobile Money Payment Channels */}
            <div className="bg-white border border-slate-200 rounded-lg p-5 space-y-4">
              <h3 className="text-sm font-semibold text-slate-900">
                Namba za Kupokea Malipo (Mobile Money &amp; Lipa Namba)
              </h3>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                <div className="space-y-1">
                  <label className="block text-xs font-medium text-slate-600">
                    Jina la Akaunti ya Malipo
                  </label>
                  <input
                    type="text"
                    value={draftPaymentConfig.accountName}
                    onChange={(e) =>
                      setDraftPaymentConfig((prev) => ({
                        ...prev,
                        accountName: e.target.value,
                      }))
                    }
                    className="w-full rounded-md border border-slate-200 px-3 py-1.5 text-sm text-slate-900 focus:border-[#0f4c75] focus:outline-none"
                  />
                </div>
                <div className="space-y-1">
                  <label className="block text-xs font-medium text-slate-600">
                    M-Pesa (Vodacom)
                  </label>
                  <input
                    type="text"
                    value={draftPaymentConfig.mpesaNumber}
                    onChange={(e) =>
                      setDraftPaymentConfig((prev) => ({
                        ...prev,
                        mpesaNumber: e.target.value,
                      }))
                    }
                    className="w-full rounded-md border border-slate-200 px-3 py-1.5 text-sm font-mono-tabular text-slate-900 focus:border-[#0f4c75] focus:outline-none"
                  />
                </div>
                <div className="space-y-1">
                  <label className="block text-xs font-medium text-slate-600">
                    Airtel Money
                  </label>
                  <input
                    type="text"
                    value={draftPaymentConfig.airtelNumber}
                    onChange={(e) =>
                      setDraftPaymentConfig((prev) => ({
                        ...prev,
                        airtelNumber: e.target.value,
                      }))
                    }
                    className="w-full rounded-md border border-slate-200 px-3 py-1.5 text-sm font-mono-tabular text-slate-900 focus:border-[#0f4c75] focus:outline-none"
                  />
                </div>
                <div className="space-y-1">
                  <label className="block text-xs font-medium text-slate-600">
                    Mixx by Yas (Tigo Pesa)
                  </label>
                  <input
                    type="text"
                    value={draftPaymentConfig.tigoNumber}
                    onChange={(e) =>
                      setDraftPaymentConfig((prev) => ({
                        ...prev,
                        tigoNumber: e.target.value,
                      }))
                    }
                    className="w-full rounded-md border border-slate-200 px-3 py-1.5 text-sm font-mono-tabular text-slate-900 focus:border-[#0f4c75] focus:outline-none"
                  />
                </div>
                <div className="space-y-1">
                  <label className="block text-xs font-medium text-slate-600">
                    Halopesa
                  </label>
                  <input
                    type="text"
                    value={draftPaymentConfig.halopesaNumber}
                    onChange={(e) =>
                      setDraftPaymentConfig((prev) => ({
                        ...prev,
                        halopesaNumber: e.target.value,
                      }))
                    }
                    className="w-full rounded-md border border-slate-200 px-3 py-1.5 text-sm font-mono-tabular text-slate-900 focus:border-[#0f4c75] focus:outline-none"
                  />
                </div>
                <div className="space-y-1">
                  <label className="block text-xs font-medium text-slate-600">
                    Lipa Namba
                  </label>
                  <input
                    type="text"
                    value={draftPaymentConfig.lipaNamba}
                    onChange={(e) =>
                      setDraftPaymentConfig((prev) => ({
                        ...prev,
                        lipaNamba: e.target.value,
                      }))
                    }
                    className="w-full rounded-md border border-slate-200 px-3 py-1.5 text-sm font-mono-tabular text-slate-900 focus:border-[#0f4c75] focus:outline-none"
                  />
                </div>
              </div>

              <div className="space-y-1">
                <label className="block text-xs font-medium text-slate-600">
                  Maelekezo ya Malipo kwa Watumiaji
                </label>
                <textarea
                  rows={2}
                  value={draftPaymentConfig.instructions}
                  onChange={(e) =>
                    setDraftPaymentConfig((prev) => ({
                      ...prev,
                      instructions: e.target.value,
                    }))
                  }
                  className="w-full rounded-md border border-slate-200 px-3 py-2 text-xs text-slate-900 focus:border-[#0f4c75] focus:outline-none"
                />
              </div>
            </div>

            {/* Editable Coin Packages */}
            <div className="bg-white border border-slate-200 rounded-lg p-5 space-y-4">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <h3 className="text-sm font-semibold text-slate-900">
                  Vifurushi vya Kununua Coin (TZS)
                </h3>
                <div className="flex flex-wrap items-center gap-2">
                  <button
                    type="button"
                    onClick={() =>
                      setDraftPaymentConfig((prev) => ({
                        ...prev,
                        packages: DEFAULT_PAYMENT_CONFIG.packages,
                      }))
                    }
                    className="px-3 py-1.5 text-xs font-medium text-slate-700 border border-slate-200 hover:bg-slate-50 rounded-md transition-colors"
                  >
                    Rejesha Vifurushi 5 Chaguomsingi
                  </button>
                  {draftPaymentConfig.packages.length < 6 && (
                    <button
                      type="button"
                      onClick={() =>
                        setDraftPaymentConfig((prev) => ({
                          ...prev,
                          packages: [
                            ...prev.packages,
                            {
                              id: `pkg_${Date.now().toString().slice(-4)}`,
                              label: 'Kifurushi Kipya',
                              coins: 25,
                              priceTzs: 3000,
                            },
                          ],
                        }))
                      }
                      className="inline-flex items-center gap-1 px-3 py-1.5 text-xs font-medium text-[#0f4c75] border border-[#0f4c75]/30 hover:bg-[#0f4c75]/5 rounded-md transition-colors"
                    >
                      <Plus className="w-3.5 h-3.5" aria-hidden="true" />
                      Ongeza Kifurushi
                    </button>
                  )}
                </div>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {draftPaymentConfig.packages.map((pkg, idx) => (
                  <div
                    key={pkg.id}
                    className="rounded-lg border border-slate-200 p-3.5 grid grid-cols-12 gap-2.5 items-end"
                  >
                    <div className="col-span-12 sm:col-span-5 space-y-1">
                      <label className="block text-[11px] font-medium text-slate-500">
                        Jina la Kifurushi
                      </label>
                      <input
                        type="text"
                        value={pkg.label}
                        onChange={(e) =>
                          setDraftPaymentConfig((prev) => ({
                            ...prev,
                            packages: prev.packages.map((item, i) =>
                              i === idx ? { ...item, label: e.target.value } : item
                            ),
                          }))
                        }
                        className="w-full rounded-md border border-slate-200 px-2.5 py-1.5 text-xs text-slate-900 focus:border-[#0f4c75] focus:outline-none"
                      />
                    </div>
                    <div className="col-span-5 sm:col-span-3 space-y-1">
                      <label className="block text-[11px] font-medium text-slate-500">
                        Coin
                      </label>
                      <input
                        type="number"
                        min={1}
                        max={100000}
                        value={pkg.coins}
                        onChange={(e) =>
                          setDraftPaymentConfig((prev) => ({
                            ...prev,
                            packages: prev.packages.map((item, i) =>
                              i === idx
                                ? { ...item, coins: Math.max(1, Number(e.target.value) || 1) }
                                : item
                            ),
                          }))
                        }
                        className="w-full rounded-md border border-slate-200 px-2.5 py-1.5 text-xs font-mono-tabular text-slate-900 focus:border-[#0f4c75] focus:outline-none"
                      />
                    </div>
                    <div className="col-span-5 sm:col-span-3 space-y-1">
                      <label className="block text-[11px] font-medium text-slate-500">
                        Bei (TZS)
                      </label>
                      <input
                        type="number"
                        min={100}
                        max={50000000}
                        value={pkg.priceTzs}
                        onChange={(e) =>
                          setDraftPaymentConfig((prev) => ({
                            ...prev,
                            packages: prev.packages.map((item, i) =>
                              i === idx
                                ? {
                                    ...item,
                                    priceTzs: Math.max(100, Number(e.target.value) || 100),
                                  }
                                : item
                            ),
                          }))
                        }
                        className="w-full rounded-md border border-slate-200 px-2.5 py-1.5 text-xs font-mono-tabular text-slate-900 focus:border-[#0f4c75] focus:outline-none"
                      />
                    </div>
                    <div className="col-span-2 sm:col-span-1 flex justify-end">
                      {draftPaymentConfig.packages.length > 1 && (
                        <button
                          type="button"
                          aria-label={`Ondoa ${pkg.label}`}
                          onClick={() =>
                            setDraftPaymentConfig((prev) => ({
                              ...prev,
                              packages: prev.packages.filter((_, i) => i !== idx),
                            }))
                          }
                          className="p-1.5 text-slate-400 hover:text-red-600 rounded-md transition-colors"
                        >
                          <Trash2 className="w-4 h-4" aria-hidden="true" />
                        </button>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </form>
        )}

        {/* Sub-tab 3: Users & Services */}
        {adminSubTab === 'users' && (
          <>
            {/* Search & Status Filter */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div className="relative flex-1 max-w-md">
                <Search
                  className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2"
                  aria-hidden="true"
                />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Tafuta kwa jina, namba ya simu, au email..."
                  className="w-full rounded-lg border border-slate-200 bg-white pl-9 pr-3 py-2 text-sm text-slate-900 focus:border-[#0f4c75] focus:outline-none"
                />
              </div>

              <div
                className="flex items-center gap-1 p-1 bg-slate-200/70 rounded-lg self-start"
                role="group"
                aria-label="Chuja watumiaji"
              >
                {(
                  [
                    { id: 'all', label: 'Wote' },
                    { id: 'active', label: 'Hai' },
                    { id: 'suspended', label: 'Waliosimamishwa' },
                  ] as const
                ).map((tab) => (
                  <button
                    key={tab.id}
                    type="button"
                    onClick={() => setStatusFilter(tab.id)}
                    className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 ${
                      statusFilter === tab.id
                        ? 'bg-white text-slate-900 shadow-xs'
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    {tab.label}
                  </button>
                ))}
              </div>
            </div>

        {/* Users List */}
        {loadingUsers ? (
          <div className="bg-white border border-slate-200 rounded-lg p-6 space-y-4">
            <div className="h-5 w-64 bg-slate-200 rounded animate-pulse" />
            <div className="h-20 w-full bg-slate-100 rounded animate-pulse" />
          </div>
        ) : filteredUsers.length === 0 ? (
          <div className="bg-white border border-slate-200 rounded-lg p-8 text-center text-sm text-slate-500">
            Hakuna watumiaji waliopatikana kwa kichujio hiki.
          </div>
        ) : (
          <div className="space-y-4">
            {filteredUsers.map((user) => {
              const isExpanded = selectedUserId === user.uid;
              const enabledCount = Object.values(user.services || {}).filter(
                Boolean
              ).length;

              return (
                <div
                  key={user.uid}
                  className="bg-white border border-slate-200 rounded-lg overflow-hidden"
                >
                  {/* User Header Row */}
                  <div className="p-5 flex flex-col lg:flex-row lg:items-center justify-between gap-4 border-b border-slate-100">
                    <div className="space-y-1 min-w-0">
                      <div className="flex flex-wrap items-center gap-2">
                        <h3 className="text-base font-semibold text-slate-900 truncate">
                          {user.fullName}
                        </h3>
                        <span className="text-xs text-slate-400" aria-hidden="true">
                          ·
                        </span>
                        <span className="text-xs font-medium text-slate-600">
                          {user.role === 'admin' ? 'Admin' : 'Mtumiaji'}
                        </span>
                        <span className="text-xs text-slate-400" aria-hidden="true">
                          ·
                        </span>
                        <span
                          className={`inline-flex items-center gap-1 text-xs font-medium ${
                            user.accountStatus === 'active'
                              ? 'text-emerald-700'
                              : 'text-red-600'
                          }`}
                        >
                          {user.accountStatus === 'active' ? (
                            <ShieldCheck className="w-3.5 h-3.5" aria-hidden="true" />
                          ) : (
                            <ShieldAlert className="w-3.5 h-3.5" aria-hidden="true" />
                          )}
                          {user.accountStatus === 'active'
                            ? 'Akaunti Hai'
                            : 'Imesimamishwa'}
                        </span>
                      </div>

                      <div className="flex flex-wrap items-center gap-2 text-xs text-slate-500 font-mono-tabular">
                        <span>{user.phone}</span>
                        <span aria-hidden="true">·</span>
                        <span className="font-sans">{user.email}</span>
                        <span aria-hidden="true">·</span>
                        <span>
                          Huduma {enabledCount}/{SERVICE_DEFINITIONS.length}
                        </span>
                      </div>
                    </div>

                    <div className="flex flex-wrap items-center gap-3 shrink-0">
                      <div className="px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-lg flex items-center gap-2">
                        <Coins className="w-4 h-4 text-amber-600" aria-hidden="true" />
                        <span className="text-sm font-semibold font-mono-tabular text-slate-900">
                          {user.coins.toLocaleString()}
                        </span>
                        <span className="text-xs text-slate-500">Coins</span>
                      </div>

                      {user.role !== 'admin' && (
                        <button
                          type="button"
                          disabled={busyMap[`${user.uid}:status`]}
                          onClick={() => handleToggleStatus(user)}
                          className={`px-3 py-2 text-xs font-medium rounded-lg border transition-colors whitespace-nowrap shrink-0 ${
                            user.accountStatus === 'active'
                              ? 'border-red-200 text-red-700 hover:bg-red-50'
                              : 'border-emerald-200 text-emerald-700 hover:bg-emerald-50'
                          }`}
                        >
                          {user.accountStatus === 'active'
                            ? 'Simamisha'
                            : 'Washa Akaunti'}
                        </button>
                      )}

                      <button
                        type="button"
                        onClick={() =>
                          setSelectedUserId(isExpanded ? null : user.uid)
                        }
                        className="px-3 py-2 text-xs font-medium text-slate-700 border border-slate-200 hover:bg-slate-50 rounded-lg transition-colors whitespace-nowrap shrink-0"
                      >
                        {isExpanded ? 'Ficha Historia' : 'Historia ya Coin'}
                      </button>
                    </div>
                  </div>

                  {/* Individual Service Toggles + Coin Management */}
                  <div className="p-5 grid grid-cols-1 lg:grid-cols-12 gap-6">
                    {/* Left 7 cols: Per-Service One-by-One Toggles */}
                    <div className="lg:col-span-7 space-y-3">
                      <div className="flex items-center justify-between gap-2">
                        <h4 className="text-xs font-semibold text-slate-700">
                          Huduma za Mtumiaji (Washa / Zima Moja Moja)
                        </h4>
                        <div className="flex items-center gap-2">
                          <button
                            type="button"
                            disabled={busyMap[`${user.uid}:all`]}
                            onClick={() => handleToggleAllServices(user, true)}
                            className="text-xs font-medium text-[#0f4c75] hover:underline whitespace-nowrap"
                          >
                            Washa Zote
                          </button>
                          <span className="text-slate-300" aria-hidden="true">
                            |
                          </span>
                          <button
                            type="button"
                            disabled={busyMap[`${user.uid}:all`]}
                            onClick={() => handleToggleAllServices(user, false)}
                            className="text-xs font-medium text-slate-500 hover:text-slate-800 hover:underline whitespace-nowrap"
                          >
                            Zima Zote
                          </button>
                        </div>
                      </div>

                      <div className="divide-y divide-slate-100 border border-slate-200 rounded-lg">
                        {SERVICE_DEFINITIONS.map((svc) => {
                          const enabled = Boolean(user.services?.[svc.key]);
                          const busy = Boolean(busyMap[`${user.uid}:${svc.key}`]);
                          return (
                            <div
                              key={svc.key}
                              className="px-3.5 py-2.5 flex items-center justify-between gap-4"
                            >
                              <div className="min-w-0">
                                <p className="text-xs font-medium text-slate-900">
                                  {svc.label}
                                </p>
                                <p className="text-xs text-slate-500 truncate">
                                  {svc.subtitle}
                                </p>
                              </div>
                              <button
                                type="button"
                                role="switch"
                                aria-checked={enabled}
                                aria-label={`${svc.label} kwa ${user.fullName}`}
                                disabled={busy}
                                onClick={() =>
                                  handleToggleSingleService(user, svc.key)
                                }
                                className={`relative inline-flex h-6 w-11 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors focus:outline-none focus-visible:ring-2 focus-visible:ring-[#0f4c75] ${
                                  enabled ? 'bg-emerald-600' : 'bg-slate-300'
                                } ${busy ? 'opacity-50' : ''}`}
                              >
                                <span
                                  className={`pointer-events-none inline-block h-5 w-5 transform rounded-full bg-white shadow transition-transform ${
                                    enabled ? 'translate-x-5' : 'translate-x-0'
                                  }`}
                                />
                              </button>
                            </div>
                          );
                        })}
                      </div>
                    </div>

                    {/* Right 5 cols: Coin Top-up & Deduction */}
                    <div className="lg:col-span-5 space-y-3">
                      <h4 className="text-xs font-semibold text-slate-700">
                        Ongeza au Punguza Coin
                      </h4>

                      <div className="flex flex-wrap gap-2">
                        {[13, 28, 50, 100, 130].map((amt) => (
                          <button
                            key={amt}
                            type="button"
                            disabled={busyMap[`${user.uid}:coins`]}
                            onClick={() => handleCoinAction(user, 'topup', amt)}
                            className="px-3 py-1.5 text-xs font-medium font-mono-tabular bg-slate-100 hover:bg-slate-200 text-slate-800 rounded-md transition-colors whitespace-nowrap"
                          >
                            +{amt} Coins
                          </button>
                        ))}
                      </div>

                      <div className="space-y-2 pt-1">
                        <div className="grid grid-cols-2 gap-2">
                          <input
                            type="number"
                            min={1}
                            placeholder="Kiasi cha coin"
                            value={coinAmountInput[user.uid] || ''}
                            onChange={(e) =>
                              setCoinAmountInput((prev) => ({
                                ...prev,
                                [user.uid]: e.target.value,
                              }))
                            }
                            className="rounded-md border border-slate-200 px-3 py-2 text-xs font-mono-tabular text-slate-900 focus:border-[#0f4c75] focus:outline-none"
                          />
                          <input
                            type="text"
                            placeholder="Maelezo (hiari)"
                            value={coinNoteInput[user.uid] || ''}
                            onChange={(e) =>
                              setCoinNoteInput((prev) => ({
                                ...prev,
                                [user.uid]: e.target.value,
                              }))
                            }
                            className="rounded-md border border-slate-200 px-3 py-2 text-xs text-slate-900 focus:border-[#0f4c75] focus:outline-none"
                          />
                        </div>

                        <div className="grid grid-cols-2 gap-2">
                          <button
                            type="button"
                            disabled={busyMap[`${user.uid}:coins`]}
                            onClick={() => handleCoinAction(user, 'topup')}
                            className="px-3 py-2 text-xs font-medium text-white bg-[#0f4c75] hover:bg-[#0b3a5b] disabled:opacity-60 rounded-md transition-colors whitespace-nowrap"
                          >
                            Ongeza Coin
                          </button>
                          <button
                            type="button"
                            disabled={busyMap[`${user.uid}:coins`]}
                            onClick={() => handleCoinAction(user, 'deduct')}
                            className="px-3 py-2 text-xs font-medium text-slate-700 border border-slate-200 hover:bg-slate-50 disabled:opacity-60 rounded-md transition-colors whitespace-nowrap"
                          >
                            Punguza Coin
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Expandable Coin Transaction History */}
                  {isExpanded && (
                    <div className="border-t border-slate-200 bg-slate-50/70 px-5 py-4 space-y-2.5">
                      <h5 className="text-xs font-semibold text-slate-700">
                        Miamala ya Hivi Karibuni ya Coin
                      </h5>
                      {userTransactions.length === 0 ? (
                        <p className="text-xs text-slate-500">
                          Hakuna miamala ya coin bado kwa mtumiaji huyu.
                        </p>
                      ) : (
                        <div className="overflow-x-auto">
                          <table className="w-full text-xs text-left">
                            <thead>
                              <tr className="border-b border-slate-200 text-slate-500">
                                <th className="py-1.5 pr-3 font-medium">Aina</th>
                                <th className="py-1.5 pr-3 font-medium">Huduma</th>
                                <th className="py-1.5 pr-3 font-medium">Maelezo</th>
                                <th className="py-1.5 pr-3 font-medium text-right">
                                  Kiasi
                                </th>
                                <th className="py-1.5 font-medium text-right">
                                  Salio Baada
                                </th>
                              </tr>
                            </thead>
                            <tbody className="divide-y divide-slate-200/70">
                              {userTransactions.map((tx) => (
                                <tr key={tx.id}>
                                  <td className="py-2 pr-3 font-medium text-slate-800">
                                    {tx.type === 'topup'
                                      ? 'Nyongeza'
                                      : tx.type === 'deduct'
                                        ? 'Punguzo'
                                        : 'Matumizi'}
                                  </td>
                                  <td className="py-2 pr-3 text-slate-600">
                                    {tx.service}
                                  </td>
                                  <td className="py-2 pr-3 text-slate-600">
                                    {tx.note}
                                  </td>
                                  <td
                                    className={`py-2 pr-3 text-right font-mono-tabular font-medium ${
                                      tx.type === 'topup'
                                        ? 'text-emerald-700'
                                        : 'text-red-600'
                                    }`}
                                  >
                                    {tx.type === 'topup' ? '+' : '-'}
                                    {tx.amount}
                                  </td>
                                  <td className="py-2 text-right font-mono-tabular text-slate-900">
                                    {tx.balanceAfter}
                                  </td>
                                </tr>
                              ))}
                            </tbody>
                          </table>
                        </div>
                      )}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}
          </>
        )}
      </div>
    </div>
  );
};
