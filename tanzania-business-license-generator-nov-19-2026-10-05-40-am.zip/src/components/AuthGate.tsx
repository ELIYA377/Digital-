import React, { useState } from 'react';
import { User } from 'firebase/auth';
import { Eye, EyeOff, KeyRound, LogOut, ShieldCheck, Smartphone, UserPlus } from 'lucide-react';
import { ADMIN_BOOTSTRAP_EMAIL } from '../firebase';
import { UserProfile } from '../types/account';
import { registerUserProfile } from '../services/firestoreService';
import {
  maskPhone,
  normalizePhone,
  validateFourDigitPin,
  validatePhone,
  validateThreeNames,
  verifyPin,
} from '../utils/crypto';

interface AuthGateProps {
  firebaseUser: User | null;
  profile: UserProfile | null;
  loadingAuth: boolean;
  onGoogleSignIn: () => Promise<void>;
  onSignOut: () => Promise<void>;
  onPinUnlocked: () => void;
}

export const AuthGate: React.FC<AuthGateProps> = ({
  firebaseUser,
  profile,
  loadingAuth,
  onGoogleSignIn,
  onSignOut,
  onPinUnlocked,
}) => {
  const [authBusy, setAuthBusy] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  // Registration state
  const [fullName, setFullName] = useState('');
  const [phone, setPhone] = useState('');
  const [pin, setPin] = useState('');
  const [confirmPin, setConfirmPin] = useState('');
  const [showPin, setShowPin] = useState(false);

  // PIN Login state
  const [loginPhone, setLoginPhone] = useState('');
  const [loginPin, setLoginPin] = useState('');

  const handleGoogleConnect = async () => {
    setErrorMsg(null);
    setAuthBusy(true);
    try {
      await onGoogleSignIn();
    } catch (err) {
      setErrorMsg(
        err instanceof Error
          ? err.message
          : 'Imeshindikana kuunganisha akaunti ya Google.'
      );
    } finally {
      setAuthBusy(false);
    }
  };

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!firebaseUser) return;
    setErrorMsg(null);

    const nameErr = validateThreeNames(fullName);
    if (nameErr) {
      setErrorMsg(nameErr);
      return;
    }

    const phoneErr = validatePhone(phone);
    if (phoneErr) {
      setErrorMsg(phoneErr);
      return;
    }

    const pinErr = validateFourDigitPin(pin);
    if (pinErr) {
      setErrorMsg(pinErr);
      return;
    }

    if (pin !== confirmPin) {
      setErrorMsg('Password ya tarakimu 4 hazifanani. Hakikisha zinalingana.');
      return;
    }

    setAuthBusy(true);
    try {
      await registerUserProfile({
        uid: firebaseUser.uid,
        email: firebaseUser.email || '',
        fullName,
        phone,
        pin,
      });
      onPinUnlocked();
    } catch (err) {
      setErrorMsg(
        err instanceof Error ? err.message : 'Usajili umeshindikana. Jaribu tena.'
      );
    } finally {
      setAuthBusy(false);
    }
  };

  const handlePinLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!profile) return;
    setErrorMsg(null);

    if (profile.accountStatus === 'suspended') {
      setErrorMsg(
        'Akaunti yako imesimamishwa na Admin. Tafadhali wasiliana na Admin.'
      );
      return;
    }

    const pinErr = validateFourDigitPin(loginPin);
    if (pinErr) {
      setErrorMsg(pinErr);
      return;
    }

    if (normalizePhone(loginPhone) !== normalizePhone(profile.phone)) {
      setErrorMsg('Namba ya simu uliyoingiza hailingani na ya akaunti hii.');
      return;
    }

    setAuthBusy(true);
    try {
      const ok = await verifyPin(loginPin, profile.pinSalt, profile.pinHash);
      if (!ok) {
        setErrorMsg('Password (PIN) ya tarakimu 4 si sahihi.');
        return;
      }
      onPinUnlocked();
    } finally {
      setAuthBusy(false);
    }
  };

  if (loadingAuth) {
    return (
      <div className="min-h-screen bg-[#f4f6f8] flex items-center justify-center p-6">
        <div className="w-full max-w-md bg-white border border-slate-200 rounded-xl p-8 space-y-4">
          <div className="h-5 w-48 bg-slate-200 rounded animate-pulse" />
          <div className="h-4 w-full bg-slate-100 rounded animate-pulse" />
          <div className="h-10 w-full bg-slate-100 rounded animate-pulse" />
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#f4f6f8] flex flex-col justify-center items-center p-6">
      <div className="w-full max-w-md bg-white border border-slate-200 rounded-xl shadow-[0_8px_30px_rgba(15,23,42,0.06)] overflow-hidden">
        <div className="px-6 py-5 border-b border-slate-200 bg-slate-50/70">
          <p className="text-xs font-medium text-[#0f4c75]">
            Tanzania Business License Portal
          </p>
          <h1 className="font-display text-lg font-semibold text-slate-900 mt-0.5">
            {!firebaseUser
              ? 'Unganisha Kifaa na Akaunti'
              : !profile
                ? 'Jisajili Mtumiaji Mpya'
                : 'Ingia Kwa Namba ya Simu na PIN'}
          </h1>
        </div>

        <div className="p-6 space-y-5">
          {errorMsg && (
            <div
              role="alert"
              className="rounded-lg border border-red-200 bg-red-50 px-3.5 py-2.5 text-xs text-red-700"
            >
              {errorMsg}
            </div>
          )}

          {/* Step 1: Connect Google Account for Cross-Device Cloud Persistence */}
          {!firebaseUser && (
            <div className="space-y-4">
              <p className="text-sm text-slate-600 leading-relaxed">
                Mfumo huu unahifadhi kumbukumbu, salio la coin, na ruhusa za
                huduma kwenye wingu ili zifanye kazi kwenye simu au kompyuta
                yoyote.
              </p>
              <div className="rounded-lg border border-slate-200 bg-slate-50 p-3.5 text-xs text-slate-600 space-y-1.5">
                <p className="font-medium text-slate-800">Hatua za Kuanza:</p>
                <p>1. Thibitisha kifaa chako kwa kubonyeza Google Sign-In.</p>
                <p>
                  2. Jisajili kwa Majina Matatu, Namba ya Simu na Password ya
                  tarakimu 4.
                </p>
                <p>3. Tumia coin na huduma zilizowashwa na Admin.</p>
              </div>
              <button
                type="button"
                onClick={handleGoogleConnect}
                disabled={authBusy}
                className="w-full flex items-center justify-center gap-2 px-4 py-2.5 text-sm font-medium text-white bg-[#0f4c75] hover:bg-[#0b3a5b] disabled:opacity-60 rounded-lg transition-colors"
              >
                <ShieldCheck className="w-4 h-4" aria-hidden="true" />
                {authBusy ? 'Inaunganisha...' : 'Endelea na Google'}
              </button>
            </div>
          )}

          {/* Step 2: Register User (Majina Matatu + Namba ya Simu + 4-digit PIN) */}
          {firebaseUser && !profile && (
            <form onSubmit={handleRegister} className="space-y-4">
              {firebaseUser.email?.toLowerCase() ===
                ADMIN_BOOTSTRAP_EMAIL.toLowerCase() && (
                <div className="rounded-lg border border-emerald-200 bg-emerald-50 px-3.5 py-2.5 text-xs text-emerald-800">
                  Akaunti ya Admin imetambuliwa ({firebaseUser.email}). Kamilisha
                  usajili wako ili kufungua Admin Control Panel.
                </div>
              )}

              <div className="flex items-center justify-between text-xs text-slate-500">
                <span className="truncate">{firebaseUser.email}</span>
                <button
                  type="button"
                  onClick={onSignOut}
                  className="text-[#0f4c75] hover:underline whitespace-nowrap shrink-0 ml-2"
                >
                  Badili Akaunti
                </button>
              </div>

              <div className="space-y-1.5">
                <label
                  htmlFor="reg-fullname"
                  className="block text-xs font-medium text-slate-700"
                >
                  Majina Matatu (Jina la Kwanza, Kati na Mwisho)
                </label>
                <input
                  id="reg-fullname"
                  type="text"
                  required
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                  placeholder="Mfano: Juma Hassan Mwinyi"
                  className="w-full rounded-lg border border-slate-200 px-3 py-2 text-sm text-slate-900 focus:border-[#0f4c75] focus:ring-2 focus:ring-[#0f4c75]/15 focus:outline-none"
                />
              </div>

              <div className="space-y-1.5">
                <label
                  htmlFor="reg-phone"
                  className="block text-xs font-medium text-slate-700"
                >
                  Namba ya Simu
                </label>
                <input
                  id="reg-phone"
                  type="tel"
                  required
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  placeholder="0712345678"
                  className="w-full rounded-lg border border-slate-200 px-3 py-2 text-sm font-mono-tabular text-slate-900 focus:border-[#0f4c75] focus:ring-2 focus:ring-[#0f4c75]/15 focus:outline-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1.5">
                  <label
                    htmlFor="reg-pin"
                    className="block text-xs font-medium text-slate-700"
                  >
                    Password (Tarakimu 4)
                  </label>
                  <div className="relative">
                    <input
                      id="reg-pin"
                      type={showPin ? 'text' : 'password'}
                      inputMode="numeric"
                      maxLength={4}
                      required
                      value={pin}
                      onChange={(e) =>
                        setPin(e.target.value.replace(/\D/g, '').slice(0, 4))
                      }
                      placeholder="••••"
                      className="w-full rounded-lg border border-slate-200 px-3 py-2 pr-9 text-sm font-mono-tabular tracking-widest text-slate-900 focus:border-[#0f4c75] focus:ring-2 focus:ring-[#0f4c75]/15 focus:outline-none"
                    />
                    <button
                      type="button"
                      onClick={() => setShowPin((v) => !v)}
                      aria-label={showPin ? 'Ficha PIN' : 'Onyesha PIN'}
                      className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
                    >
                      {showPin ? (
                        <EyeOff className="w-4 h-4" />
                      ) : (
                        <Eye className="w-4 h-4" />
                      )}
                    </button>
                  </div>
                </div>

                <div className="space-y-1.5">
                  <label
                    htmlFor="reg-confirm-pin"
                    className="block text-xs font-medium text-slate-700"
                  >
                    Thibitisha Tarakimu 4
                  </label>
                  <input
                    id="reg-confirm-pin"
                    type={showPin ? 'text' : 'password'}
                    inputMode="numeric"
                    maxLength={4}
                    required
                    value={confirmPin}
                    onChange={(e) =>
                      setConfirmPin(e.target.value.replace(/\D/g, '').slice(0, 4))
                    }
                    placeholder="••••"
                    className="w-full rounded-lg border border-slate-200 px-3 py-2 text-sm font-mono-tabular tracking-widest text-slate-900 focus:border-[#0f4c75] focus:ring-2 focus:ring-[#0f4c75]/15 focus:outline-none"
                  />
                </div>
              </div>

              <button
                type="submit"
                disabled={authBusy}
                className="w-full flex items-center justify-center gap-2 px-4 py-2.5 text-sm font-medium text-white bg-[#0f4c75] hover:bg-[#0b3a5b] disabled:opacity-60 rounded-lg transition-colors"
              >
                <UserPlus className="w-4 h-4" aria-hidden="true" />
                {authBusy ? 'Inasajili...' : 'Jisajili na Hifadhi Akaunti'}
              </button>
            </form>
          )}

          {/* Step 3: Returning User Phone + 4-Digit PIN Verification */}
          {firebaseUser && profile && (
            <form onSubmit={handlePinLogin} className="space-y-4">
              <div className="rounded-lg border border-slate-200 bg-slate-50 px-3.5 py-2.5 flex items-center justify-between gap-3">
                <div className="min-w-0">
                  <p className="text-xs font-semibold text-slate-900 truncate">
                    {profile.fullName}
                  </p>
                  <p className="text-xs text-slate-500 font-mono-tabular">
                    Simu: {maskPhone(profile.phone)} · Coin: {profile.coins}
                  </p>
                </div>
                <button
                  type="button"
                  onClick={onSignOut}
                  className="inline-flex items-center gap-1 text-xs text-slate-600 hover:text-slate-900 whitespace-nowrap shrink-0"
                >
                  <LogOut className="w-3.5 h-3.5" aria-hidden="true" />
                  Toka
                </button>
              </div>

              <div className="space-y-1.5">
                <label
                  htmlFor="login-phone"
                  className="block text-xs font-medium text-slate-700"
                >
                  Namba ya Simu
                </label>
                <div className="relative">
                  <Smartphone
                    className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2"
                    aria-hidden="true"
                  />
                  <input
                    id="login-phone"
                    type="tel"
                    required
                    value={loginPhone}
                    onChange={(e) => setLoginPhone(e.target.value)}
                    placeholder="Ingiza namba yako ya simu"
                    className="w-full rounded-lg border border-slate-200 pl-9 pr-3 py-2 text-sm font-mono-tabular text-slate-900 focus:border-[#0f4c75] focus:ring-2 focus:ring-[#0f4c75]/15 focus:outline-none"
                  />
                </div>
              </div>

              <div className="space-y-1.5">
                <label
                  htmlFor="login-pin"
                  className="block text-xs font-medium text-slate-700"
                >
                  Password (Tarakimu 4)
                </label>
                <div className="relative">
                  <KeyRound
                    className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2"
                    aria-hidden="true"
                  />
                  <input
                    id="login-pin"
                    type={showPin ? 'text' : 'password'}
                    inputMode="numeric"
                    maxLength={4}
                    required
                    value={loginPin}
                    onChange={(e) =>
                      setLoginPin(e.target.value.replace(/\D/g, '').slice(0, 4))
                    }
                    placeholder="••••"
                    className="w-full rounded-lg border border-slate-200 pl-9 pr-9 py-2 text-sm font-mono-tabular tracking-widest text-slate-900 focus:border-[#0f4c75] focus:ring-2 focus:ring-[#0f4c75]/15 focus:outline-none"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPin((v) => !v)}
                    aria-label={showPin ? 'Ficha PIN' : 'Onyesha PIN'}
                    className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
                  >
                    {showPin ? (
                      <EyeOff className="w-4 h-4" />
                    ) : (
                      <Eye className="w-4 h-4" />
                    )}
                  </button>
                </div>
              </div>

              <button
                type="submit"
                disabled={authBusy}
                className="w-full flex items-center justify-center gap-2 px-4 py-2.5 text-sm font-medium text-white bg-[#0f4c75] hover:bg-[#0b3a5b] disabled:opacity-60 rounded-lg transition-colors"
              >
                {authBusy ? 'Inahakiki...' : 'Fungua Mfumo'}
              </button>
            </form>
          )}
        </div>
      </div>

      <footer className="mt-6 text-center text-xs text-slate-500">
        &copy; Digital sales. All rights reserved.
      </footer>
    </div>
  );
};
