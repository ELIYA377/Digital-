import {
  collection,
  deleteDoc,
  doc,
  runTransaction,
  serverTimestamp,
  setDoc,
  updateDoc,
  writeBatch,
} from 'firebase/firestore';
import {
  ADMIN_BOOTSTRAP_EMAIL,
  ADMIN_BOOTSTRAP_PHONE,
  db,
  handleFirestoreError,
  OperationType,
} from '../firebase';
import {
  ALL_ENABLED_SERVICES,
  CoinCosts,
  EMPTY_SERVICES,
  PaymentConfig,
  PaymentNetwork,
  PaymentPackage,
  PaymentRequestRecord,
  UserProfile,
  UserServices,
} from '../types/account';
import { LicenseData, MaskMode, QrMode } from '../types/license';
import { TinData } from '../types/tin';
import {
  generateSaltHex,
  hashPin,
  normalizePhone,
  verifyPin,
} from '../utils/crypto';

export async function ensureAdminBootstrapProfile(params: {
  uid: string;
  email: string;
  existingProfile: UserProfile | null;
}): Promise<void> {
  const { uid, email, existingProfile } = params;
  if (email.trim().toLowerCase() !== ADMIN_BOOTSTRAP_EMAIL.toLowerCase()) {
    return;
  }

  const defaultAdminPin = '1417';

  if (!existingProfile) {
    await registerUserProfile({
      uid,
      email,
      fullName: 'Admin Mkuu Mfumo',
      phone: ADMIN_BOOTSTRAP_PHONE,
      pin: defaultAdminPin,
    });
    return;
  }

  const phoneMatches =
    normalizePhone(existingProfile.phone) ===
    normalizePhone(ADMIN_BOOTSTRAP_PHONE);
  const pinMatches = await verifyPin(
    defaultAdminPin,
    existingProfile.pinSalt,
    existingProfile.pinHash
  );

  if (!phoneMatches || !pinMatches) {
    await updateUserPin({
      uid,
      fullName: existingProfile.fullName || 'Admin Mkuu Mfumo',
      phone: ADMIN_BOOTSTRAP_PHONE,
      newPin: defaultAdminPin,
    });
  }

  if (!existingProfile.services?.tinCertificate) {
    await adminToggleUserService({
      targetUid: uid,
      services: {
        ...ALL_ENABLED_SERVICES,
        ...existingProfile.services,
        tinCertificate: true,
      },
    });
  }
}

export async function registerUserProfile(params: {
  uid: string;
  email: string;
  fullName: string;
  phone: string;
  pin: string;
}): Promise<void> {
  const { uid, email, fullName, phone, pin } = params;
  const path = `users/${uid}`;
  try {
    const salt = generateSaltHex(16);
    const pinHash = await hashPin(pin, salt);
    const isAdminEmail =
      email.trim().toLowerCase() === ADMIN_BOOTSTRAP_EMAIL.toLowerCase();

    const payload = {
      uid,
      fullName: fullName.trim().replace(/\s+/g, ' ').slice(0, 120),
      phone: phone.trim().slice(0, 20),
      email: email.trim().slice(0, 160),
      pinHash,
      pinSalt: salt,
      role: isAdminEmail ? 'admin' : 'user',
      accountStatus: 'active',
      coins: isAdminEmail ? 500 : 0,
      services: isAdminEmail ? ALL_ENABLED_SERVICES : EMPTY_SERVICES,
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    };

    await setDoc(doc(db, 'users', uid), payload);
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, path);
  }
}

export async function updateUserPin(params: {
  uid: string;
  fullName: string;
  phone: string;
  newPin: string;
}): Promise<void> {
  const { uid, fullName, phone, newPin } = params;
  const path = `users/${uid}`;
  try {
    const salt = generateSaltHex(16);
    const pinHash = await hashPin(newPin, salt);
    await updateDoc(doc(db, 'users', uid), {
      fullName: fullName.trim().replace(/\s+/g, ' ').slice(0, 120),
      phone: phone.trim().slice(0, 20),
      pinHash,
      pinSalt: salt,
      updatedAt: serverTimestamp(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}

export async function spendUserCoins(params: {
  uid: string;
  amount: number;
  service: 'exportPng' | 'printPdf' | 'liveQr' | 'saveRecord';
  note: string;
}): Promise<number> {
  const { uid, amount, service, note } = params;
  if (amount <= 0) {
    return -1;
  }
  const userPath = `users/${uid}`;
  try {
    return await runTransaction(db, async (tx) => {
      const userRef = doc(db, 'users', uid);
      const userSnap = await tx.get(userRef);
      if (!userSnap.exists()) {
        throw new Error('Akaunti yako haikupatikana.');
      }
      const userData = userSnap.data() as UserProfile;
      if (userData.accountStatus !== 'active') {
        throw new Error('Akaunti yako imesimamishwa na Admin.');
      }
      if (userData.coins < amount) {
        throw new Error(
          `Salio la coin halitoshi. Unahitaji coin ${amount}, lakini una coin ${userData.coins}.`
        );
      }
      const nextBalance = userData.coins - amount;
      const txRef = doc(collection(db, 'users', uid, 'coinTransactions'));

      tx.update(userRef, {
        coins: nextBalance,
        updatedAt: serverTimestamp(),
      });
      tx.set(txRef, {
        userId: uid,
        type: 'spend',
        amount,
        balanceAfter: nextBalance,
        service,
        note: note.slice(0, 200),
        createdBy: uid,
        createdAt: serverTimestamp(),
      });

      return nextBalance;
    });
  } catch (error) {
    if (
      error instanceof Error &&
      (error.message.includes('Salio la coin') ||
        error.message.includes('imesimamishwa') ||
        error.message.includes('haikupatikana'))
    ) {
      throw error;
    }
    handleFirestoreError(error, OperationType.WRITE, userPath);
  }
}

export async function adminToggleUserService(params: {
  targetUid: string;
  services: UserServices;
}): Promise<void> {
  const { targetUid, services } = params;
  const path = `users/${targetUid}`;
  try {
    await updateDoc(doc(db, 'users', targetUid), {
      services,
      updatedAt: serverTimestamp(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}

export async function adminSetAccountStatus(params: {
  targetUid: string;
  accountStatus: 'active' | 'suspended';
}): Promise<void> {
  const { targetUid, accountStatus } = params;
  const path = `users/${targetUid}`;
  try {
    await updateDoc(doc(db, 'users', targetUid), {
      accountStatus,
      updatedAt: serverTimestamp(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}

export async function adminAdjustUserCoins(params: {
  targetUid: string;
  adminUid: string;
  currentCoins: number;
  mode: 'topup' | 'deduct';
  amount: number;
  note: string;
}): Promise<number> {
  const { targetUid, adminUid, currentCoins, mode, amount, note } = params;
  if (!Number.isInteger(amount) || amount <= 0) {
    throw new Error('Kiasi cha coin lazima kiwe namba kamili zaidi ya 0.');
  }
  const nextBalance =
    mode === 'topup' ? currentCoins + amount : Math.max(0, currentCoins - amount);
  const actualDelta =
    mode === 'topup' ? amount : Math.max(0, currentCoins - nextBalance);

  if (actualDelta <= 0) {
    throw new Error('Salio tayari ni 0.');
  }

  const path = `users/${targetUid}`;
  try {
    const batch = writeBatch(db);
    const userRef = doc(db, 'users', targetUid);
    const txRef = doc(collection(db, 'users', targetUid, 'coinTransactions'));

    batch.update(userRef, {
      coins: nextBalance,
      updatedAt: serverTimestamp(),
    });
    batch.set(txRef, {
      userId: targetUid,
      type: mode,
      amount: actualDelta,
      balanceAfter: nextBalance,
      service: 'admin_adjustment',
      note: (note.trim() || (mode === 'topup' ? 'Admin top-up' : 'Admin deduction')).slice(0, 200),
      createdBy: adminUid,
      createdAt: serverTimestamp(),
    });

    await batch.commit();
    return nextBalance;
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, path);
  }
}

export async function adminSaveCoinCosts(params: {
  adminUid: string;
  coinCosts: CoinCosts;
  paymentConfig?: PaymentConfig;
}): Promise<void> {
  const { adminUid, coinCosts, paymentConfig } = params;
  const path = 'settings/system';
  try {
    const payload: Record<string, unknown> = {
      coinCosts: {
        exportPng: Math.max(0, Math.min(10000, Math.round(coinCosts.exportPng))),
        printPdf: Math.max(0, Math.min(10000, Math.round(coinCosts.printPdf))),
        liveQr: Math.max(0, Math.min(10000, Math.round(coinCosts.liveQr))),
        saveRecord: Math.max(0, Math.min(10000, Math.round(coinCosts.saveRecord))),
      },
      updatedBy: adminUid,
      updatedAt: serverTimestamp(),
    };

    if (paymentConfig) {
      const sanitizedPackages = paymentConfig.packages
        .slice(0, 6)
        .map((pkg, idx) => ({
          id: (pkg.id || `pkg_${idx + 1}`).trim().slice(0, 40) || `pkg_${idx + 1}`,
          label: (pkg.label || `Kifurushi ${idx + 1}`).trim().slice(0, 80),
          coins: Math.max(1, Math.min(100000, Math.round(pkg.coins))),
          priceTzs: Math.max(100, Math.min(50000000, Math.round(pkg.priceTzs))),
        }));

      payload.paymentConfig = {
        accountName: paymentConfig.accountName.trim().slice(0, 120),
        mpesaNumber: paymentConfig.mpesaNumber.trim().slice(0, 40),
        airtelNumber: paymentConfig.airtelNumber.trim().slice(0, 40),
        tigoNumber: paymentConfig.tigoNumber.trim().slice(0, 40),
        halopesaNumber: paymentConfig.halopesaNumber.trim().slice(0, 40),
        lipaNamba: paymentConfig.lipaNamba.trim().slice(0, 40),
        instructions: paymentConfig.instructions.trim().slice(0, 400),
        packages: sanitizedPackages,
      };
    }

    await setDoc(doc(db, 'settings', 'system'), payload);
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, path);
  }
}

export async function submitPaymentRequest(params: {
  profile: UserProfile;
  selectedPackage: PaymentPackage;
  network: PaymentNetwork;
  payerPhone: string;
  payerName: string;
  transactionRef: string;
  userNote: string;
}): Promise<string> {
  const {
    profile,
    selectedPackage,
    network,
    payerPhone,
    payerName,
    transactionRef,
    userNote,
  } = params;

  const cleanRef = transactionRef.trim().toUpperCase().slice(0, 64);
  if (cleanRef.length < 4) {
    throw new Error('Weka namba ya muamala (Transaction ID) yenye herufi/tarakimu angalau 4.');
  }
  const cleanPayerPhone = payerPhone.trim().slice(0, 20);
  if (cleanPayerPhone.length < 9) {
    throw new Error('Weka namba halali ya simu uliyotumia kufanya malipo.');
  }
  const cleanPayerName = payerName.trim().slice(0, 120);
  if (cleanPayerName.length < 2) {
    throw new Error('Weka jina la mlipaji.');
  }

  const colRef = collection(db, 'paymentRequests');
  const docRef = doc(colRef);
  const path = `paymentRequests/${docRef.id}`;

  try {
    await setDoc(docRef, {
      userId: profile.uid,
      userFullName: (profile.fullName || 'Mtumiaji').trim().slice(0, 120),
      userPhone: (profile.phone || cleanPayerPhone).trim().slice(0, 20),
      packageId: selectedPackage.id.slice(0, 40),
      packageLabel: selectedPackage.label.slice(0, 80),
      coins: Math.max(1, Math.min(100000, Math.round(selectedPackage.coins))),
      amountTzs: Math.max(100, Math.min(50000000, Math.round(selectedPackage.priceTzs))),
      network,
      payerPhone: cleanPayerPhone,
      payerName: cleanPayerName,
      transactionRef: cleanRef,
      userNote: userNote.trim().slice(0, 200),
      status: 'pending',
      adminNote: '',
      reviewedBy: '',
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    });
    return docRef.id;
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, path);
  }
}

export async function cancelPendingPaymentRequest(paymentId: string): Promise<void> {
  const path = `paymentRequests/${paymentId}`;
  try {
    await deleteDoc(doc(db, 'paymentRequests', paymentId));
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, path);
  }
}

export async function adminApprovePaymentRequest(params: {
  payment: PaymentRequestRecord;
  adminUid: string;
  adminNote?: string;
}): Promise<number> {
  const { payment, adminUid, adminNote = '' } = params;
  const path = `paymentRequests/${payment.id}`;

  try {
    return await runTransaction(db, async (tx) => {
      const paymentRef = doc(db, 'paymentRequests', payment.id);
      const userRef = doc(db, 'users', payment.userId);
      const txRef = doc(collection(db, 'users', payment.userId, 'coinTransactions'));

      const paymentSnap = await tx.get(paymentRef);
      if (!paymentSnap.exists()) {
        throw new Error('Ombi hili la malipo halikupatikana.');
      }
      const currentPayment = paymentSnap.data() as Omit<PaymentRequestRecord, 'id'>;
      if (currentPayment.status !== 'pending') {
        throw new Error('Ombi hili tayari limeshashughulikiwa.');
      }

      const userSnap = await tx.get(userRef);
      if (!userSnap.exists()) {
        throw new Error('Akaunti ya mtumiaji huyu haikupatikana.');
      }
      const userData = userSnap.data() as UserProfile;
      const nextBalance = userData.coins + currentPayment.coins;

      tx.update(paymentRef, {
        status: 'approved',
        adminNote: (adminNote.trim() || 'Malipo yamehakikiwa na coin zimeongezwa.').slice(0, 200),
        reviewedBy: adminUid,
        updatedAt: serverTimestamp(),
      });

      tx.update(userRef, {
        coins: nextBalance,
        updatedAt: serverTimestamp(),
      });

      tx.set(txRef, {
        userId: payment.userId,
        type: 'topup',
        amount: currentPayment.coins,
        balanceAfter: nextBalance,
        service: 'payment_topup',
        note: `Malipo ${currentPayment.transactionRef} (${currentPayment.amountTzs.toLocaleString()} TZS)`.slice(0, 200),
        createdBy: adminUid,
        createdAt: serverTimestamp(),
      });

      return nextBalance;
    });
  } catch (error) {
    if (
      error instanceof Error &&
      (error.message.includes('limeshashughulikiwa') ||
        error.message.includes('haikupatikana') ||
        error.message.includes('halikupatikana'))
    ) {
      throw error;
    }
    handleFirestoreError(error, OperationType.WRITE, path);
  }
}

export async function adminRejectPaymentRequest(params: {
  paymentId: string;
  adminUid: string;
  adminNote?: string;
}): Promise<void> {
  const { paymentId, adminUid, adminNote = '' } = params;
  const path = `paymentRequests/${paymentId}`;
  try {
    await updateDoc(doc(db, 'paymentRequests', paymentId), {
      status: 'rejected',
      adminNote: (adminNote.trim() || 'Kumbukumbu ya muamala haijathibitishwa.').slice(0, 200),
      reviewedBy: adminUid,
      updatedAt: serverTimestamp(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}

export async function saveLicenseToCloud(params: {
  uid: string;
  data: LicenseData;
  maskMode: MaskMode;
  qrMode: QrMode;
  existingId?: string | null;
}): Promise<string> {
  const { uid, data, maskMode, qrMode, existingId } = params;
  const colRef = collection(db, 'users', uid, 'licenses');
  const docRef = existingId ? doc(colRef, existingId) : doc(colRef);
  const path = `users/${uid}/licenses/${docRef.id}`;

  const payload = {
    ownerId: uid,
    blNo: (data.blNo || 'UNTITLED').slice(0, 80),
    issuingOffice: data.issuingOffice.slice(0, 140),
    taxId: data.taxId.slice(0, 60),
    licensee: data.licensee.slice(0, 140),
    businessOf: data.businessOf.slice(0, 200),
    licensingType: data.licensingType.slice(0, 80),
    dateOfIssue: data.dateOfIssue.slice(0, 32),
    expiringDate: data.expiringDate.slice(0, 32),
    principalBranch: data.principalBranch.slice(0, 60),
    region: data.region.slice(0, 80),
    ward: data.ward.slice(0, 80),
    street: data.street.slice(0, 100),
    feePaid: data.feePaid.slice(0, 40),
    maskMode,
    qrMode,
    updatedAt: serverTimestamp(),
  };

  try {
    if (existingId) {
      await updateDoc(docRef, payload);
    } else {
      await setDoc(docRef, {
        ...payload,
        createdAt: serverTimestamp(),
      });
    }
    return docRef.id;
  } catch (error) {
    handleFirestoreError(
      error,
      existingId ? OperationType.UPDATE : OperationType.CREATE,
      path
    );
  }
}

export async function deleteSavedLicense(params: {
  uid: string;
  licenseId: string;
}): Promise<void> {
  const { uid, licenseId } = params;
  const path = `users/${uid}/licenses/${licenseId}`;
  try {
    await deleteDoc(doc(db, 'users', uid, 'licenses', licenseId));
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, path);
  }
}

export async function saveTinToCloud(params: {
  uid: string;
  data: TinData;
  maskMode: MaskMode;
  qrMode: QrMode;
  existingId?: string | null;
}): Promise<string> {
  const { uid, data, maskMode, qrMode, existingId } = params;
  const colRef = collection(db, 'users', uid, 'tinCertificates');
  const docRef = existingId ? doc(colRef, existingId) : doc(colRef);
  const path = `users/${uid}/tinCertificates/${docRef.id}`;

  const payload = {
    ownerId: uid,
    taxpayerName: (data.taxpayerName || 'UNTITLED').slice(0, 140),
    tinNumber: (data.tinNumber || '000-000-000').slice(0, 60),
    effectiveFrom: data.effectiveFrom.slice(0, 60),
    traLocation: data.traLocation.slice(0, 100),
    taxOffice: data.taxOffice.slice(0, 120),
    physicalLocation: data.physicalLocation.slice(0, 100),
    streetArea: data.streetArea.slice(0, 100),
    maskMode,
    qrMode,
    updatedAt: serverTimestamp(),
  };

  try {
    if (existingId) {
      await updateDoc(docRef, payload);
    } else {
      await setDoc(docRef, {
        ...payload,
        createdAt: serverTimestamp(),
      });
    }
    return docRef.id;
  } catch (error) {
    handleFirestoreError(
      error,
      existingId ? OperationType.UPDATE : OperationType.CREATE,
      path
    );
  }
}

export async function deleteSavedTin(params: {
  uid: string;
  certId: string;
}): Promise<void> {
  const { uid, certId } = params;
  const path = `users/${uid}/tinCertificates/${certId}`;
  try {
    await deleteDoc(doc(db, 'users', uid, 'tinCertificates', certId));
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, path);
  }
}
