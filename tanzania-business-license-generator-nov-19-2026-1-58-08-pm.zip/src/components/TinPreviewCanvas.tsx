import React, { useEffect, useRef, useState } from 'react';
import { MaskMode, QrMode, ZoomMode } from '../types/license';
import {
  TIN_FIELD_OVERLAYS,
  TIN_QR_BOX,
  TIN_TEMPLATE_HEIGHT,
  TIN_TEMPLATE_IMAGE_PATH,
  TIN_TEMPLATE_WIDTH,
  TinData,
  TinFieldKey,
} from '../types/tin';

interface TinPreviewCanvasProps {
  data: TinData;
  cleanedTemplateUrl: string | null;
  maskMode: MaskMode;
  qrMode: QrMode;
  qrDataUrl: string | null;
  zoomMode: ZoomMode;
  activeField: TinFieldKey | null;
  onSelectField: (key: TinFieldKey) => void;
}

export const TinPreviewCanvas: React.FC<TinPreviewCanvasProps> = ({
  data,
  cleanedTemplateUrl,
  maskMode,
  qrMode,
  qrDataUrl,
  zoomMode,
  activeField,
  onSelectField,
}) => {
  const stageRef = useRef<HTMLDivElement | null>(null);
  const [fitWidth, setFitWidth] = useState<number>(680);
  const [imageError, setImageError] = useState(false);

  useEffect(() => {
    const updateFitWidth = () => {
      if (!stageRef.current) return;
      const rect = stageRef.current.getBoundingClientRect();
      const availW = Math.max(280, rect.width - 64);
      const availH = Math.max(380, rect.height - 64);
      const widthByHeight =
        availH * (TIN_TEMPLATE_WIDTH / TIN_TEMPLATE_HEIGHT);
      const computed = Math.min(availW, widthByHeight, 760);
      setFitWidth(Math.round(computed));
    };

    updateFitWidth();
    const observer = new ResizeObserver(updateFitWidth);
    if (stageRef.current) {
      observer.observe(stageRef.current);
    }
    window.addEventListener('resize', updateFitWidth);
    return () => {
      observer.disconnect();
      window.removeEventListener('resize', updateFitWidth);
    };
  }, []);

  const displayWidth =
    zoomMode === 'fit'
      ? fitWidth
      : Math.round(TIN_TEMPLATE_WIDTH * (Number(zoomMode) / 100));

  const backgroundSrc =
    maskMode === 'seamless' && cleanedTemplateUrl
      ? cleanedTemplateUrl
      : TIN_TEMPLATE_IMAGE_PATH;

  return (
    <main
      ref={stageRef}
      className="print-stage flex-1 overflow-auto bg-[#e6eaf0] p-6 lg:p-8 flex justify-center items-start min-h-[540px]"
    >
      <div
        className="print-doc-frame relative bg-white shadow-[0_18px_45px_rgba(15,23,42,0.16)] border border-slate-300/70 shrink-0 select-none"
        style={{
          width: `${displayWidth}px`,
          aspectRatio: `${TIN_TEMPLATE_WIDTH} / ${TIN_TEMPLATE_HEIGHT}`,
          containerType: 'inline-size',
        }}
      >
        {!imageError ? (
          <img
            src={backgroundSrc}
            alt="Tanzania Revenue Authority TIN Certificate Template"
            referrerPolicy="no-referrer"
            onError={() => setImageError(true)}
            className="block w-full h-full object-cover pointer-events-none"
          />
        ) : (
          <div className="w-full h-full flex flex-col items-center justify-center bg-slate-50 text-slate-500 p-8 text-center">
            <p className="text-sm font-medium text-slate-700">
              TIN template background could not be loaded
            </p>
            <p className="text-xs text-slate-500 mt-1">
              Verify the template asset exists in public/assets/aistudio.
            </p>
          </div>
        )}

        {TIN_FIELD_OVERLAYS.map((field) => {
          const isActive = activeField === field.key;
          const rawValue = data[field.key] ?? '';
          const displayText =
            field.key === 'taxpayerName' ? rawValue.toUpperCase() : rawValue;

          const topPct = (field.y / TIN_TEMPLATE_HEIGHT) * 100;
          const leftPct = (field.x / TIN_TEMPLATE_WIDTH) * 100;
          const widthPct = (field.w / TIN_TEMPLATE_WIDTH) * 100;
          const heightPct = (field.h / TIN_TEMPLATE_HEIGHT) * 100;
          const fontSizeCqw = (field.fontSizePx / TIN_TEMPLATE_WIDTH) * 100;

          return (
            <button
              key={field.key}
              type="button"
              onClick={() => onSelectField(field.key)}
              title={`Edit ${field.label}`}
              className={`license-doc-font absolute z-10 flex items-center whitespace-nowrap overflow-hidden text-ellipsis cursor-text transition-shadow focus:outline-none ${
                field.align === 'center'
                  ? 'justify-center text-center'
                  : 'justify-start text-left'
              } ${
                isActive
                  ? 'ring-2 ring-[#2f6f3e]/50 rounded-[2px] bg-[#2f6f3e]/5'
                  : 'hover:ring-1 hover:ring-[#2f6f3e]/30 rounded-[2px]'
              }`}
              style={{
                top: `${topPct}%`,
                left: `${leftPct}%`,
                width: `${widthPct}%`,
                height: `${heightPct}%`,
                fontSize: `${fontSizeCqw}cqw`,
                fontWeight: field.fontWeight,
                letterSpacing: field.letterSpacing || 'normal',
                color: field.color,
                lineHeight: 1.15,
                backgroundColor:
                  maskMode === 'opaque'
                    ? '#fdfdfd'
                    : isActive
                      ? 'rgba(47, 111, 62, 0.05)'
                      : 'transparent',
              }}
            >
              {displayText}
            </button>
          );
        })}

        {qrMode === 'live' && qrDataUrl && (
          <div
            className="absolute z-10 bg-white flex items-center justify-center p-[0.3%]"
            style={{
              top: `${(TIN_QR_BOX.y / TIN_TEMPLATE_HEIGHT) * 100}%`,
              left: `${(TIN_QR_BOX.x / TIN_TEMPLATE_WIDTH) * 100}%`,
              width: `${(TIN_QR_BOX.w / TIN_TEMPLATE_WIDTH) * 100}%`,
              height: `${(TIN_QR_BOX.h / TIN_TEMPLATE_HEIGHT) * 100}%`,
            }}
          >
            <img
              src={qrDataUrl}
              alt={`Verification QR code for TIN ${data.tinNumber}`}
              className="w-full h-full object-contain [image-rendering:pixelated]"
            />
          </div>
        )}
      </div>
    </main>
  );
};
