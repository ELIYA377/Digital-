import React, { useEffect, useMemo, useState } from 'react';
import {
  CloudUpload,
  Download,
  Eraser,
  Lock,
  Printer,
  RotateCcw,
} from 'lucide-react';
import { MaskMode, QrMode, ZoomMode } from '../types/license';
import { CoinCosts, UserProfile } from '../types/account';
import { TinData, TinFieldKey } from '../types/tin';
import {
  ALL_PHYSICAL_LOCATIONS,
  ALL_STREET_AREAS,
  ALL_TAX_OFFICES,
  ALL_TRA_LOCATIONS,
  PHYSICAL_LOCATION_GROUPS,
  STREET_AREA_GROUPS,
  TAX_OFFICE_GROUPS,
  TRA_LOCATION_GROUPS,
  TinSelectGroup,
  TinSelectOption,
  getTodayOrdinalDate,
  isoToOrdinalDate,
  ordinalToIsoDate,
} from '../data/tanzaniaTraLocations';
import {
  RegionHierarchy,
  loadCombinedRegionHierarchy,
  resolveRegionFromInput,
} from '../services/tzLocationsService';

const FORM_ZOOM_OPTIONS: { value: ZoomMode; label: string }[] = [
  { value: 'fit', label: 'Fit' },
  { value: '75', label: '75%' },
  { value: '100', label: '100%' },
  { value: '125', label: '125%' },
];

interface TinFormSidebarProps {
  data: TinData;
  profile: UserProfile;
  isAdmin: boolean;
  coinCosts: CoinCosts;
  activeField: TinFieldKey | null;
  maskMode: MaskMode;
  qrMode: QrMode;
  zoomMode: ZoomMode;
  canPrintPdf: boolean;
  editingTinId: string | null;
  isSavingRecord: boolean;
  isExporting: boolean;
  onChangeField: (key: TinFieldKey, value: string) => void;
  onFocusField: (key: TinFieldKey | null) => void;
  onChangeMaskMode: (mode: MaskMode) => void;
  onRequestQrMode: (mode: QrMode) => void;
  onChangeZoomMode: (mode: ZoomMode) => void;
  onSaveToCloud: () => void;
  onPrint: () => void;
  onDownload: () => void;
  onResetDefaults: () => void;
  onClearFields: () => void;
  registerInputRef: (
    key: TinFieldKey,
    el: HTMLInputElement | HTMLSelectElement | null
  ) => void;
}

interface TinInputConfig {
  key: TinFieldKey;
  label: string;
  placeholder: string;
  mono?: boolean;
  kind?: 'text' | 'select' | 'date';
  options?: TinSelectOption[];
  optionGroups?: TinSelectGroup[];
}

const TIN_DETAIL_FIELDS: TinInputConfig[] = [
  {
    key: 'taxpayerName',
    label: 'Taxpayer Name',
    placeholder: 'MERANIA JUMA MABIHO',
  },
  {
    key: 'tinNumber',
    label: 'TIN Number',
    placeholder: '212-534-307',
    mono: true,
  },
  {
    key: 'effectiveFrom',
    label: 'Effective From',
    placeholder: '9th November 2026',
    kind: 'date',
  },
];

const TIN_OFFICE_FIELDS: TinInputConfig[] = [
  {
    key: 'traLocation',
    label: 'TRA Location',
    placeholder: 'Andika TRA Location...',
    kind: 'select',
    options: ALL_TRA_LOCATIONS,
    optionGroups: TRA_LOCATION_GROUPS,
  },
  {
    key: 'taxOffice',
    label: 'Tax Office',
    placeholder: 'Andika jina la Tax Office / Centre...',
    kind: 'select',
    options: ALL_TAX_OFFICES,
    optionGroups: TAX_OFFICE_GROUPS,
  },
  {
    key: 'physicalLocation',
    label: 'Physical Location',
    placeholder: 'Andika eneo (mfano NAMONGE)...',
    kind: 'select',
    options: ALL_PHYSICAL_LOCATIONS,
    optionGroups: PHYSICAL_LOCATION_GROUPS,
  },
  {
    key: 'streetArea',
    label: 'Street / Area',
    placeholder: 'Andika mtaa / eneo...',
    kind: 'select',
    options: ALL_STREET_AREAS,
    optionGroups: STREET_AREA_GROUPS,
  },
];

export const TinFormSidebar: React.FC<TinFormSidebarProps> = ({
  data,
  profile,
  isAdmin,
  coinCosts,
  activeField,
  maskMode,
  qrMode,
  zoomMode,
  canPrintPdf,
  editingTinId,
  isSavingRecord,
  isExporting,
  onChangeField,
  onFocusField,
  onChangeMaskMode,
  onRequestQrMode,
  onChangeZoomMode,
  onSaveToCloud,
  onPrint,
  onDownload,
  onResetDefaults,
  onClearFields,
  registerInputRef,
}) => {
  const [customFields, setCustomFields] = useState<
    Partial<Record<TinFieldKey, boolean>>
  >({});
  const [selectedDistrict, setSelectedDistrict] = useState<string>('');
  const [regionHierarchy, setRegionHierarchy] =
    useState<RegionHierarchy | null>(null);
  const [isLoadingRegion, setIsLoadingRegion] = useState(false);

  const resolvedRegion = useMemo(
    () => resolveRegionFromInput(data.traLocation),
    [data.traLocation]
  );

  useEffect(() => {
    let cancelled = false;
    if (!resolvedRegion) {
      setRegionHierarchy(null);
      setSelectedDistrict('');
      setIsLoadingRegion(false);
      return;
    }

    setIsLoadingRegion(true);
    loadCombinedRegionHierarchy(resolvedRegion.slugs)
      .then((loaded) => {
        if (!cancelled) {
          setRegionHierarchy(loaded);
          setSelectedDistrict((prev) => {
            if (prev && loaded?.districts.some((d) => d.name === prev)) {
              return prev;
            }
            if (
              resolvedRegion.defaultDistrict &&
              loaded?.districts.some(
                (d) => d.name === resolvedRegion.defaultDistrict
              )
            ) {
              return resolvedRegion.defaultDistrict;
            }
            const physUpper = data.physicalLocation.trim().toUpperCase();
            const physMatch = loaded?.districts.find(
              (d) =>
                d.name === physUpper ||
                d.wards.some((w) => w.name === physUpper)
            );
            return physMatch ? physMatch.name : '';
          });
          setIsLoadingRegion(false);
        }
      })
      .catch(() => {
        if (!cancelled) {
          setRegionHierarchy(null);
          setIsLoadingRegion(false);
        }
      });

    return () => {
      cancelled = true;
    };
  }, [resolvedRegion]);

  const physicalLocationGroups = useMemo<TinSelectGroup[]>(() => {
    if (!regionHierarchy) return PHYSICAL_LOCATION_GROUPS;
    const districts = selectedDistrict
      ? regionHierarchy.districts.filter((d) => d.name === selectedDistrict)
      : regionHierarchy.districts;

    const groups: TinSelectGroup[] = [];
    for (const dist of districts) {
      const seen = new Set<string>();
      const opts: TinSelectOption[] = [{ value: dist.name, label: `${dist.name} (WILAYA)` }];
      seen.add(dist.name);
      for (const ward of dist.wards) {
        if (!seen.has(ward.name)) {
          seen.add(ward.name);
          opts.push({ value: ward.name, label: ward.name });
        }
      }
      groups.push({
        group: `Wilaya: ${dist.name} (${dist.wards.length} Kata)`,
        options: opts,
      });
    }
    return groups.length > 0 ? groups : PHYSICAL_LOCATION_GROUPS;
  }, [regionHierarchy, selectedDistrict]);

  const allPhysicalLocationOptions = useMemo<TinSelectOption[]>(
    () =>
      regionHierarchy
        ? physicalLocationGroups.flatMap((g) => g.options)
        : ALL_PHYSICAL_LOCATIONS,
    [regionHierarchy, physicalLocationGroups]
  );

  const streetAreaGroups = useMemo<TinSelectGroup[]>(() => {
    if (!regionHierarchy) return STREET_AREA_GROUPS;
    const districts = selectedDistrict
      ? regionHierarchy.districts.filter((d) => d.name === selectedDistrict)
      : regionHierarchy.districts;

    const physNeedle = data.physicalLocation.trim().toUpperCase();
    if (physNeedle) {
      const matchedGroups: TinSelectGroup[] = [];
      for (const dist of districts) {
        // Match ward by physicalLocation
        const matchedWards = dist.wards.filter((w) => w.name === physNeedle);
        for (const ward of matchedWards) {
          if (ward.streetsAndVillages.length > 0) {
            matchedGroups.push({
              group: `${dist.name} — Kata ya ${ward.name} (${ward.streetsAndVillages.length})`,
              options: ward.streetsAndVillages.map((sv) => ({
                value: sv,
                label: sv,
              })),
            });
          }
        }
      }
      if (matchedGroups.length > 0) return matchedGroups;

      // Match district name if physicalLocation equals a district name
      const matchedDist = districts.find((d) => d.name === physNeedle);
      if (matchedDist) {
        return matchedDist.wards
          .filter((w) => w.streetsAndVillages.length > 0)
          .map((w) => ({
            group: `Kata: ${w.name} (${w.streetsAndVillages.length})`,
            options: w.streetsAndVillages.map((sv) => ({
              value: sv,
              label: sv,
            })),
          }));
      }
    }

    if (selectedDistrict) {
      const dist = districts[0];
      if (!dist) return STREET_AREA_GROUPS;
      return dist.wards
        .filter((w) => w.streetsAndVillages.length > 0)
        .map((w) => ({
          group: `Kata: ${w.name} (${w.streetsAndVillages.length})`,
          options: w.streetsAndVillages.map((sv) => ({
            value: sv,
            label: sv,
          })),
        }));
    }

    const regionGroups = districts
      .map((dist) => {
        const uniqueNames = Array.from(
          new Set(dist.wards.flatMap((w) => w.streetsOnly))
        ).sort((a, b) => a.localeCompare(b));
        return {
          group: `Wilaya: ${dist.name} (${uniqueNames.length} Mitaa/Vijiji)`,
          options: uniqueNames.map((sv) => ({ value: sv, label: sv })),
        };
      })
      .filter((g) => g.options.length > 0);

    return regionGroups.length > 0 ? regionGroups : STREET_AREA_GROUPS;
  }, [regionHierarchy, selectedDistrict, data.physicalLocation]);

  const allStreetAreaOptions = useMemo<TinSelectOption[]>(
    () =>
      regionHierarchy
        ? streetAreaGroups.flatMap((g) => g.options)
        : ALL_STREET_AREAS,
    [regionHierarchy, streetAreaGroups]
  );

  const canEdit = isAdmin || Boolean(profile.services?.tinCertificate);
  const canDownloadPdf =
    isAdmin ||
    Boolean(profile.services?.printPdf) ||
    Boolean(profile.services?.exportPng);
  const downloadCost = profile.services?.printPdf
    ? coinCosts.printPdf
    : coinCosts.exportPng;
  const canSaveRecords =
    isAdmin ||
    (Boolean(profile.services?.saveRecords) &&
      Boolean(profile.services?.tinCertificate));

  const renderSelectField = (field: TinInputConfig) => {
    const isFocused = activeField === field.key;
    const options = field.options || [];
    const currentValue = data[field.key] ?? '';
    const matchedOpt = options.find(
      (opt) => opt.value.toUpperCase() === currentValue.trim().toUpperCase()
    );
    const matchesPreset = Boolean(matchedOpt);
    const isCustomMode =
      Boolean(customFields[field.key]) ||
      (currentValue !== '' && !matchesPreset);
    const selectValue = isCustomMode
      ? '__custom__'
      : matchedOpt
        ? matchedOpt.value
        : currentValue;

    return (
      <div key={field.key} className="space-y-1.5">
        <label
          htmlFor={`tin-field-${field.key}`}
          className="block text-xs font-medium text-slate-600"
        >
          {field.label}
        </label>
        <select
          id={`tin-field-${field.key}`}
          ref={(el) => registerInputRef(field.key, el)}
          disabled={!canEdit}
          value={selectValue}
          onFocus={() => onFocusField(field.key)}
          onBlur={() => onFocusField(null)}
          onChange={(e) => {
            const val = e.target.value;
            if (val === '__custom__') {
              setCustomFields((prev) => ({ ...prev, [field.key]: true }));
            } else {
              if (field.key === 'traLocation') {
                setSelectedDistrict('');
                setCustomFields((prev) => ({
                  ...prev,
                  traLocation: false,
                  physicalLocation: false,
                  streetArea: false,
                }));
              } else {
                setCustomFields((prev) => ({ ...prev, [field.key]: false }));
              }
              onChangeField(field.key, val);
            }
          }}
          className={`w-full rounded-md border px-3 py-2 text-sm text-slate-900 transition-colors focus:outline-none disabled:bg-slate-100 disabled:text-slate-500 disabled:cursor-not-allowed ${
            isFocused
              ? 'border-[#2f6f3e] ring-2 ring-[#2f6f3e]/15 bg-white'
              : 'border-slate-200 bg-slate-50/50 hover:border-slate-300 focus:border-[#2f6f3e] focus:bg-white'
          }`}
        >
          <option value="">-- Chagua {field.label} --</option>
          {field.optionGroups
            ? field.optionGroups.map((grp) => (
                <optgroup key={grp.group} label={grp.group}>
                  {grp.options.map((opt) => (
                    <option key={opt.value} value={opt.value}>
                      {opt.label}
                    </option>
                  ))}
                </optgroup>
              ))
            : options.map((opt) => (
                <option key={opt.value} value={opt.value}>
                  {opt.label}
                </option>
              ))}
          <option value="__custom__">Nyingine (Andika mwenyewe...)</option>
        </select>

        {isCustomMode && (
          <input
            type="text"
            disabled={!canEdit}
            value={currentValue}
            placeholder={field.placeholder}
            onFocus={() => onFocusField(field.key)}
            onBlur={() => onFocusField(null)}
            onChange={(e) =>
              onChangeField(field.key, e.target.value.toUpperCase())
            }
            className="w-full rounded-md border border-slate-200 bg-white px-3 py-2 text-sm uppercase text-slate-900 placeholder:normal-case placeholder:text-slate-400 focus:border-[#2f6f3e] focus:outline-none disabled:bg-slate-100 disabled:text-slate-500"
          />
        )}
      </div>
    );
  };

  const renderDateField = (field: TinInputConfig) => {
    const isFocused = activeField === field.key;
    const currentValue = data[field.key] ?? '';
    const isoValue = ordinalToIsoDate(currentValue);

    return (
      <div key={field.key} className="space-y-1.5">
        <div className="flex items-center justify-between gap-2">
          <label
            htmlFor={`tin-field-${field.key}`}
            className="block text-xs font-medium text-slate-600"
          >
            {field.label}
          </label>
          <button
            type="button"
            disabled={!canEdit}
            onClick={() =>
              onChangeField('effectiveFrom', getTodayOrdinalDate())
            }
            className="text-[11px] font-medium text-[#2f6f3e] hover:underline disabled:opacity-40"
          >
            Chagua Leo
          </button>
        </div>
        <input
          id={`tin-field-${field.key}`}
          ref={(el) => registerInputRef(field.key, el)}
          type="date"
          disabled={!canEdit}
          value={isoValue}
          onFocus={() => onFocusField(field.key)}
          onBlur={() => onFocusField(null)}
          onChange={(e) => {
            const picked = e.target.value;
            onChangeField(
              field.key,
              picked ? isoToOrdinalDate(picked) : ''
            );
          }}
          className={`w-full rounded-md border px-3 py-2 text-sm font-mono-tabular text-slate-900 transition-colors focus:outline-none disabled:bg-slate-100 disabled:text-slate-500 disabled:cursor-not-allowed ${
            isFocused
              ? 'border-[#2f6f3e] ring-2 ring-[#2f6f3e]/15 bg-white'
              : 'border-slate-200 bg-slate-50/50 hover:border-slate-300 focus:border-[#2f6f3e] focus:bg-white'
          }`}
        />
        {currentValue && (
          <p className="text-[11px] text-slate-500">
            Inaonekana kwenye cheti: <strong className="text-slate-700">{currentValue}</strong>
          </p>
        )}
      </div>
    );
  };

  const renderInput = (field: TinInputConfig) => {
    if (field.kind === 'select') {
      return renderSelectField(field);
    }
    if (field.kind === 'date') {
      return renderDateField(field);
    }

    const isFocused = activeField === field.key;
    return (
      <div key={field.key} className="space-y-1.5">
        <label
          htmlFor={`tin-field-${field.key}`}
          className="block text-xs font-medium text-slate-600"
        >
          {field.label}
          {field.key === 'tinNumber' && (
            <span className="ml-1.5 text-[11px] font-normal text-slate-400">
              (XXX-XXX-XXX)
            </span>
          )}
        </label>
        <input
          id={`tin-field-${field.key}`}
          ref={(el) => registerInputRef(field.key, el)}
          type="text"
          inputMode={field.key === 'tinNumber' ? 'numeric' : undefined}
          disabled={!canEdit}
          value={data[field.key]}
          placeholder={field.placeholder}
          onFocus={() => onFocusField(field.key)}
          onBlur={() => onFocusField(null)}
          onChange={(e) => onChangeField(field.key, e.target.value)}
          className={`w-full rounded-md border px-3 py-2 text-sm text-slate-900 placeholder:text-slate-400 transition-colors focus:outline-none disabled:bg-slate-100 disabled:text-slate-500 disabled:cursor-not-allowed ${
            field.mono ? 'font-mono-tabular' : ''
          } ${field.key === 'taxpayerName' ? 'uppercase' : ''} ${
            isFocused
              ? 'border-[#2f6f3e] ring-2 ring-[#2f6f3e]/15 bg-white'
              : 'border-slate-200 bg-slate-50/50 hover:border-slate-300 focus:border-[#2f6f3e] focus:bg-white'
          }`}
        />
      </div>
    );
  };

  return (
    <aside className="no-print w-full lg:w-[380px] lg:shrink-0 bg-white border-b lg:border-b-0 lg:border-r border-slate-200 flex flex-col lg:h-full">
      <form
        onSubmit={(e) => e.preventDefault()}
        className="flex-1 flex flex-col min-h-0"
      >
        <div className="flex-1 overflow-y-auto px-6 py-5 space-y-6">
        {!canEdit && (
          <div className="rounded-lg border border-amber-200 bg-amber-50 px-3.5 py-2.5 text-xs text-amber-800 flex items-start gap-2">
            <Lock className="w-4 h-4 shrink-0 mt-0.5" aria-hidden="true" />
            <span>
              Huduma ya Cheti cha TIN haijawashwa bado. Wasiliana na Admin
              kuwasha huduma hii kwa akaunti yako.
            </span>
          </div>
        )}

        {/* Section 1: TIN Certificate Details */}
        <section aria-labelledby="tin-section-details">
          <div className="flex items-baseline justify-between mb-3.5">
            <h2
              id="tin-section-details"
              className="text-sm font-semibold text-slate-900"
            >
              TIN Certificate Details
            </h2>
            <span className="text-xs text-slate-400 tabular-nums">3 fields</span>
          </div>
          <div className="space-y-3">
            {TIN_DETAIL_FIELDS.map(renderInput)}
          </div>
        </section>

        <hr className="border-slate-200" />

        {/* Section 2: TRA Office & Location */}
        <section aria-labelledby="tin-section-location">
          <div className="flex items-baseline justify-between mb-3.5">
            <h2
              id="tin-section-location"
              className="text-sm font-semibold text-slate-900"
            >
              TRA Office &amp; Location
            </h2>
            <span className="text-xs text-slate-400 tabular-nums">
              {regionHierarchy
                ? `${regionHierarchy.districts.length} Wilaya`
                : '4 fields'}
            </span>
          </div>
          <div className="space-y-3">
            {renderSelectField(TIN_OFFICE_FIELDS[0])}
            {renderSelectField(TIN_OFFICE_FIELDS[1])}

            <div className="space-y-1.5">
              <div className="flex items-center justify-between gap-2">
                <label
                  htmlFor="tin-field-district-filter"
                  className="block text-xs font-medium text-slate-600"
                >
                  Wilaya (Chuja Kata na Vijiji)
                </label>
                {isLoadingRegion && (
                  <span className="text-[11px] text-[#2f6f3e]">
                    Inapakia...
                  </span>
                )}
              </div>
              <select
                id="tin-field-district-filter"
                disabled={!canEdit || !regionHierarchy}
                value={selectedDistrict}
                onChange={(e) => {
                  setSelectedDistrict(e.target.value);
                  setCustomFields((prev) => ({
                    ...prev,
                    physicalLocation: false,
                    streetArea: false,
                  }));
                }}
                className="w-full rounded-md border border-slate-200 bg-slate-50/50 hover:border-slate-300 focus:border-[#2f6f3e] focus:bg-white px-3 py-2 text-sm text-slate-900 transition-colors focus:outline-none disabled:bg-slate-100 disabled:text-slate-500 disabled:cursor-not-allowed"
              >
                <option value="">
                  {regionHierarchy
                    ? `-- Wilaya Zote za ${regionHierarchy.regionName} (${regionHierarchy.districts.length}) --`
                    : '-- Chagua TRA Location kwanza --'}
                </option>
                {regionHierarchy?.districts.map((dist) => (
                  <option key={dist.name} value={dist.name}>
                    {dist.name} ({dist.wards.length} Kata)
                  </option>
                ))}
              </select>
            </div>

            {renderSelectField({
              key: 'physicalLocation',
              label: 'Physical Location (Wilaya / Kata)',
              placeholder: 'Andika eneo (mfano NAMONGE)...',
              kind: 'select',
              options: allPhysicalLocationOptions,
              optionGroups: physicalLocationGroups,
            })}

            {renderSelectField({
              key: 'streetArea',
              label: 'Street / Area (Mtaa / Kijiji)',
              placeholder: 'Andika mtaa au kijiji...',
              kind: 'select',
              options: allStreetAreaOptions,
              optionGroups: streetAreaGroups,
            })}
          </div>
        </section>

        <hr className="border-slate-200" />

        {/* Section 3: Formatting & Save */}
        <section aria-labelledby="tin-section-formatting" className="space-y-4">
          <h2
            id="tin-section-formatting"
            className="text-sm font-semibold text-slate-900"
          >
            Formatting &amp; Cloud Sync
          </h2>

          <div className="space-y-1.5">
            <span className="block text-xs font-medium text-slate-600">
              Background Overlay
            </span>
            <div
              className="grid grid-cols-2 gap-1 p-1 bg-slate-100 rounded-lg"
              role="group"
              aria-label="TIN background overlay mode"
            >
              <button
                type="button"
                onClick={() => onChangeMaskMode('seamless')}
                className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap ${
                  maskMode === 'seamless'
                    ? 'bg-white text-slate-900 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Seamless Blend
              </button>
              <button
                type="button"
                onClick={() => onChangeMaskMode('opaque')}
                className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap ${
                  maskMode === 'opaque'
                    ? 'bg-white text-slate-900 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Opaque Mask
              </button>
            </div>
          </div>

          <div className="space-y-1.5">
            <div className="flex items-center justify-between">
              <span className="block text-xs font-medium text-slate-600">
                QR Verification Code
              </span>
              <span className="text-[11px] font-medium text-emerald-700">
                Inasoma Moja kwa Moja
              </span>
            </div>
            <div
              className="grid grid-cols-2 gap-1 p-1 bg-slate-100 rounded-lg"
              role="group"
              aria-label="TIN QR code mode"
            >
              <button
                type="button"
                onClick={() => onRequestQrMode('live')}
                className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap ${
                  qrMode === 'live'
                    ? 'bg-white text-slate-900 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Taarifa za TIN (Auto)
              </button>
              <button
                type="button"
                onClick={() => onRequestQrMode('template')}
                className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap ${
                  qrMode === 'template'
                    ? 'bg-white text-slate-900 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Original QR
              </button>
            </div>
            <p className="text-[11px] text-slate-500 leading-snug">
              Taarifa zote za TIN unazojaza zinaingizwa moja kwa moja kwenye QR code hii ili mtu akiscan zisomeke papo hapo.
            </p>
          </div>

          <div className="space-y-1.5">
            <span className="block text-xs font-medium text-slate-600">
              Preview Zoom
            </span>
            <div
              className="grid grid-cols-4 gap-1 p-1 bg-slate-100 rounded-lg"
              role="group"
              aria-label="TIN preview zoom level inside form"
            >
              {FORM_ZOOM_OPTIONS.map((opt) => (
                <button
                  key={opt.value}
                  type="button"
                  onClick={() => onChangeZoomMode(opt.value)}
                  className={`px-2 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap tabular-nums ${
                    zoomMode === opt.value
                      ? 'bg-white text-slate-900 shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  {opt.label}
                </button>
              ))}
            </div>
          </div>

          <div className="pt-1 space-y-2.5">
            <button
              type="button"
              disabled={isExporting || !canEdit}
              onClick={onDownload}
              className={`w-full inline-flex items-center justify-center gap-2 px-4 py-2.5 text-xs font-medium rounded-lg transition-colors disabled:opacity-50 ${
                canDownloadPdf
                  ? 'text-white bg-[#2f6f3e] hover:bg-[#245630]'
                  : 'text-white bg-slate-400 hover:bg-slate-500'
              }`}
            >
              {!canDownloadPdf ? (
                <Lock className="w-3.5 h-3.5" aria-hidden="true" />
              ) : (
                <Download className="w-3.5 h-3.5" aria-hidden="true" />
              )}
              {isExporting ? 'Inapakua PDF...' : 'Download PDF'}
              {!isAdmin && canDownloadPdf && (
                <span className="font-mono-tabular text-white/80">
                  ({downloadCost} Coins)
                </span>
              )}
            </button>
            {!isAdmin && (
              <p className="text-[11px] text-slate-500 leading-snug">
                Kila document unayopakua (PDF) hukata Coin {downloadCost} na utapokea taarifa ya salio.
              </p>
            )}

            <button
              type="button"
              onClick={onPrint}
              className={`w-full inline-flex items-center justify-center gap-2 px-4 py-2.5 text-xs font-medium rounded-lg border transition-colors ${
                canPrintPdf
                  ? 'border-slate-200 text-slate-700 bg-white hover:bg-slate-50 hover:border-slate-300'
                  : 'border-slate-200 text-slate-400 bg-slate-50'
              }`}
            >
              {canPrintPdf ? (
                <Printer className="w-3.5 h-3.5" aria-hidden="true" />
              ) : (
                <Lock className="w-3.5 h-3.5" aria-hidden="true" />
              )}
              Print / PDF
            </button>

            <button
              type="button"
              disabled={isSavingRecord || !canEdit}
              onClick={onSaveToCloud}
              className={`w-full inline-flex items-center justify-center gap-2 px-4 py-2.5 text-xs font-medium rounded-lg border transition-colors disabled:opacity-50 ${
                canSaveRecords
                  ? 'border-[#2f6f3e] text-[#2f6f3e] bg-[#2f6f3e]/5 hover:bg-[#2f6f3e]/10'
                  : 'border-slate-200 text-slate-500 bg-slate-50'
              }`}
            >
              {!canSaveRecords ? (
                <Lock className="w-3.5 h-3.5" aria-hidden="true" />
              ) : (
                <CloudUpload className="w-3.5 h-3.5" aria-hidden="true" />
              )}
              {isSavingRecord
                ? 'Inahifadhi...'
                : editingTinId
                  ? 'Sasisha Cheti cha TIN'
                  : 'Hifadhi Cheti cha TIN'}
              {!isAdmin && canSaveRecords && !editingTinId && (
                <span className="font-mono-tabular text-slate-500">
                  ({coinCosts.saveRecord} Coins)
                </span>
              )}
            </button>
          </div>
        </section>
      </div>

      {/* Bottom Utility Bar */}
      <div className="px-6 py-3.5 border-t border-slate-200 bg-slate-50/70 flex items-center justify-between gap-3">
        <button
          type="button"
          disabled={!canEdit}
          onClick={() => {
            setCustomFields({});
            setSelectedDistrict('');
            onResetDefaults();
          }}
          className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-medium text-slate-700 hover:text-slate-900 hover:bg-slate-200/60 disabled:opacity-40 rounded-md transition-colors whitespace-nowrap shrink-0"
        >
          <RotateCcw className="w-3.5 h-3.5" aria-hidden="true" />
          Reset Sample
        </button>
        <button
          type="button"
          disabled={!canEdit}
          onClick={() => {
            setCustomFields({});
            setSelectedDistrict('');
            onClearFields();
          }}
          className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-medium text-slate-600 hover:text-slate-900 hover:bg-slate-200/60 disabled:opacity-40 rounded-md transition-colors whitespace-nowrap shrink-0"
        >
          <Eraser className="w-3.5 h-3.5" aria-hidden="true" />
          Clear All
        </button>
      </div>
      </form>
    </aside>
  );
};
