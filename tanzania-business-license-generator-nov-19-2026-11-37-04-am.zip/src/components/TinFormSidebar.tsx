import React from 'react';
import { CloudUpload, Download, Eraser, Lock, RotateCcw } from 'lucide-react';
import { MaskMode, QrMode } from '../types/license';
import { CoinCosts, UserProfile } from '../types/account';
import { TinData, TinFieldKey } from '../types/tin';

interface TinFormSidebarProps {
  data: TinData;
  profile: UserProfile;
  isAdmin: boolean;
  coinCosts: CoinCosts;
  activeField: TinFieldKey | null;
  maskMode: MaskMode;
  qrMode: QrMode;
  editingTinId: string | null;
  isSavingRecord: boolean;
  isExporting: boolean;
  onChangeField: (key: TinFieldKey, value: string) => void;
  onFocusField: (key: TinFieldKey | null) => void;
  onChangeMaskMode: (mode: MaskMode) => void;
  onRequestQrMode: (mode: QrMode) => void;
  onSaveToCloud: () => void;
  onDownload: () => void;
  onResetDefaults: () => void;
  onClearFields: () => void;
  registerInputRef: (key: TinFieldKey, el: HTMLInputElement | null) => void;
}

interface TinInputConfig {
  key: TinFieldKey;
  label: string;
  placeholder: string;
  mono?: boolean;
}

const TIN_DETAIL_FIELDS: TinInputConfig[] = [
  {
    key: 'taxpayerName',
    label: 'Taxpayer Name',
    placeholder: 'MERANIA JUMA MABIHO',
  },
  {
    key: 'tinNumber',
    label: 'TIN Number',
    placeholder: '212-534-307',
    mono: true,
  },
  {
    key: 'effectiveFrom',
    label: 'Effective From',
    placeholder: '9th November 2026',
  },
];

const TIN_OFFICE_FIELDS: TinInputConfig[] = [
  {
    key: 'traLocation',
    label: 'TRA Location',
    placeholder: 'GEITA',
  },
  {
    key: 'taxOffice',
    label: 'Tax Office',
    placeholder: 'RUZENWE TAX CENTRE',
  },
  {
    key: 'physicalLocation',
    label: 'Physical Location',
    placeholder: 'NAMONGE',
  },
  {
    key: 'streetArea',
    label: 'Street / Area',
    placeholder: 'MUHAMA',
  },
];

export const TinFormSidebar: React.FC<TinFormSidebarProps> = ({
  data,
  profile,
  isAdmin,
  coinCosts,
  activeField,
  maskMode,
  qrMode,
  editingTinId,
  isSavingRecord,
  isExporting,
  onChangeField,
  onFocusField,
  onChangeMaskMode,
  onRequestQrMode,
  onSaveToCloud,
  onDownload,
  onResetDefaults,
  onClearFields,
  registerInputRef,
}) => {
  const canEdit = isAdmin || Boolean(profile.services?.tinCertificate);
  const canLiveQr = isAdmin || Boolean(profile.services?.liveQr);
  const canExportPng = isAdmin || Boolean(profile.services?.exportPng);
  const canSaveRecords =
    isAdmin ||
    (Boolean(profile.services?.saveRecords) &&
      Boolean(profile.services?.tinCertificate));

  const renderInput = (field: TinInputConfig) => {
    const isFocused = activeField === field.key;
    return (
      <div key={field.key} className="space-y-1.5">
        <label
          htmlFor={`tin-field-${field.key}`}
          className="block text-xs font-medium text-slate-600"
        >
          {field.label}
        </label>
        <input
          id={`tin-field-${field.key}`}
          ref={(el) => registerInputRef(field.key, el)}
          type="text"
          disabled={!canEdit}
          value={data[field.key]}
          placeholder={field.placeholder}
          onFocus={() => onFocusField(field.key)}
          onBlur={() => onFocusField(null)}
          onChange={(e) => onChangeField(field.key, e.target.value)}
          className={`w-full rounded-md border px-3 py-2 text-sm text-slate-900 placeholder:text-slate-400 transition-colors focus:outline-none disabled:bg-slate-100 disabled:text-slate-500 disabled:cursor-not-allowed ${
            field.mono ? 'font-mono-tabular' : ''
          } ${
            isFocused
              ? 'border-[#2f6f3e] ring-2 ring-[#2f6f3e]/15 bg-white'
              : 'border-slate-200 bg-slate-50/50 hover:border-slate-300 focus:border-[#2f6f3e] focus:bg-white'
          }`}
        />
      </div>
    );
  };

  return (
    <aside className="no-print w-full lg:w-[380px] lg:shrink-0 bg-white border-b lg:border-b-0 lg:border-r border-slate-200 flex flex-col lg:h-full">
      <div className="flex-1 overflow-y-auto px-6 py-5 space-y-6">
        {!canEdit && (
          <div className="rounded-lg border border-amber-200 bg-amber-50 px-3.5 py-2.5 text-xs text-amber-800 flex items-start gap-2">
            <Lock className="w-4 h-4 shrink-0 mt-0.5" aria-hidden="true" />
            <span>
              Huduma ya Cheti cha TIN haijawashwa bado. Wasiliana na Admin
              kuwasha huduma hii kwa akaunti yako.
            </span>
          </div>
        )}

        {/* Section 1: TIN Certificate Details */}
        <section aria-labelledby="tin-section-details">
          <div className="flex items-baseline justify-between mb-3.5">
            <h2
              id="tin-section-details"
              className="text-sm font-semibold text-slate-900"
            >
              TIN Certificate Details
            </h2>
            <span className="text-xs text-slate-400 tabular-nums">3 fields</span>
          </div>
          <div className="space-y-3">
            {TIN_DETAIL_FIELDS.map(renderInput)}
          </div>
        </section>

        <hr className="border-slate-200" />

        {/* Section 2: TRA Office & Location */}
        <section aria-labelledby="tin-section-location">
          <div className="flex items-baseline justify-between mb-3.5">
            <h2
              id="tin-section-location"
              className="text-sm font-semibold text-slate-900"
            >
              TRA Office &amp; Location
            </h2>
            <span className="text-xs text-slate-400 tabular-nums">4 fields</span>
          </div>
          <div className="space-y-3">
            {TIN_OFFICE_FIELDS.map(renderInput)}
          </div>
        </section>

        <hr className="border-slate-200" />

        {/* Section 3: Formatting & Save */}
        <section aria-labelledby="tin-section-formatting" className="space-y-4">
          <h2
            id="tin-section-formatting"
            className="text-sm font-semibold text-slate-900"
          >
            Formatting &amp; Cloud Sync
          </h2>

          <div className="space-y-1.5">
            <span className="block text-xs font-medium text-slate-600">
              Background Overlay
            </span>
            <div
              className="grid grid-cols-2 gap-1 p-1 bg-slate-100 rounded-lg"
              role="group"
              aria-label="TIN background overlay mode"
            >
              <button
                type="button"
                onClick={() => onChangeMaskMode('seamless')}
                className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap ${
                  maskMode === 'seamless'
                    ? 'bg-white text-slate-900 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Seamless Blend
              </button>
              <button
                type="button"
                onClick={() => onChangeMaskMode('opaque')}
                className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap ${
                  maskMode === 'opaque'
                    ? 'bg-white text-slate-900 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Opaque Mask
              </button>
            </div>
          </div>

          <div className="space-y-1.5">
            <div className="flex items-center justify-between">
              <span className="block text-xs font-medium text-slate-600">
                QR Verification Code
              </span>
              {!isAdmin && (
                <span className="text-xs text-slate-400 font-mono-tabular">
                  {canLiveQr ? `${coinCosts.liveQr} Coins` : 'Imefungwa'}
                </span>
              )}
            </div>
            <div
              className="grid grid-cols-2 gap-1 p-1 bg-slate-100 rounded-lg"
              role="group"
              aria-label="TIN QR code mode"
            >
              <button
                type="button"
                onClick={() => onRequestQrMode('template')}
                className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap ${
                  qrMode === 'template'
                    ? 'bg-white text-slate-900 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Original QR
              </button>
              <button
                type="button"
                onClick={() => onRequestQrMode('live')}
                className={`inline-flex items-center justify-center gap-1 px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap ${
                  qrMode === 'live'
                    ? 'bg-white text-slate-900 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                {!canLiveQr && <Lock className="w-3 h-3 text-slate-400" />}
                Live Dynamic QR
              </button>
            </div>
          </div>

          <div className="pt-1 space-y-2.5">
            <button
              type="button"
              disabled={isExporting || !canEdit}
              onClick={onDownload}
              className={`w-full inline-flex items-center justify-center gap-2 px-4 py-2.5 text-xs font-medium rounded-lg transition-colors disabled:opacity-50 ${
                canExportPng
                  ? 'text-white bg-[#2f6f3e] hover:bg-[#245630]'
                  : 'text-white bg-slate-400 hover:bg-slate-500'
              }`}
            >
              {!canExportPng ? (
                <Lock className="w-3.5 h-3.5" aria-hidden="true" />
              ) : (
                <Download className="w-3.5 h-3.5" aria-hidden="true" />
              )}
              {isExporting ? 'Inapakua...' : 'Download (Chrome PNG)'}
              {!isAdmin && canExportPng && (
                <span className="font-mono-tabular text-white/80">
                  ({coinCosts.exportPng} Coins)
                </span>
              )}
            </button>

            <button
              type="button"
              disabled={isSavingRecord || !canEdit}
              onClick={onSaveToCloud}
              className={`w-full inline-flex items-center justify-center gap-2 px-4 py-2.5 text-xs font-medium rounded-lg border transition-colors disabled:opacity-50 ${
                canSaveRecords
                  ? 'border-[#2f6f3e] text-[#2f6f3e] bg-[#2f6f3e]/5 hover:bg-[#2f6f3e]/10'
                  : 'border-slate-200 text-slate-500 bg-slate-50'
              }`}
            >
              {!canSaveRecords ? (
                <Lock className="w-3.5 h-3.5" aria-hidden="true" />
              ) : (
                <CloudUpload className="w-3.5 h-3.5" aria-hidden="true" />
              )}
              {isSavingRecord
                ? 'Inahifadhi...'
                : editingTinId
                  ? 'Sasisha Cheti cha TIN'
                  : 'Hifadhi Cheti cha TIN'}
              {!isAdmin && canSaveRecords && !editingTinId && (
                <span className="font-mono-tabular text-slate-500">
                  ({coinCosts.saveRecord} Coins)
                </span>
              )}
            </button>
          </div>
        </section>
      </div>

      {/* Bottom Utility Bar */}
      <div className="px-6 py-3.5 border-t border-slate-200 bg-slate-50/70 flex items-center justify-between gap-3">
        <button
          type="button"
          disabled={!canEdit}
          onClick={onResetDefaults}
          className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-medium text-slate-700 hover:text-slate-900 hover:bg-slate-200/60 disabled:opacity-40 rounded-md transition-colors whitespace-nowrap shrink-0"
        >
          <RotateCcw className="w-3.5 h-3.5" aria-hidden="true" />
          Reset Sample
        </button>
        <button
          type="button"
          disabled={!canEdit}
          onClick={onClearFields}
          className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-medium text-slate-600 hover:text-slate-900 hover:bg-slate-200/60 disabled:opacity-40 rounded-md transition-colors whitespace-nowrap shrink-0"
        >
          <Eraser className="w-3.5 h-3.5" aria-hidden="true" />
          Clear All
        </button>
      </div>
    </aside>
  );
};
