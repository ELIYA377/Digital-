import React, { useEffect, useMemo, useState } from 'react';
import {
  collection,
  limit,
  onSnapshot,
  orderBy,
  query,
} from 'firebase/firestore';
import {
  CheckCircle2,
  Clock,
  Coins,
  CreditCard,
  Search,
  ShieldAlert,
  ShieldCheck,
  Sliders,
  XCircle,
} from 'lucide-react';
import { db, handleFirestoreError, OperationType } from '../firebase';
import {
  ALL_ENABLED_SERVICES,
  CoinCosts,
  CoinTransactionRecord,
  EMPTY_SERVICES,
  PAYMENT_NETWORK_LABELS,
  PaymentConfig,
  PaymentRequestRecord,
  SERVICE_DEFINITIONS,
  ServiceKey,
  UserProfile,
} from '../types/account';
import {
  adminAdjustUserCoins,
  adminApprovePaymentRequest,
  adminRejectPaymentRequest,
  adminSaveCoinCosts,
  adminSetAccountStatus,
  adminToggleUserService,
} from '../services/firestoreService';

interface AdminControlPanelProps {
  currentAdminUid: string;
  coinCosts: CoinCosts;
  paymentConfig: PaymentConfig;
  paymentRequests: PaymentRequestRecord[];
}

export const AdminControlPanel: React.FC<AdminControlPanelProps> = ({
  currentAdminUid,
  coinCosts,
  paymentConfig,
  paymentRequests,
}) => {
  const [adminSubTab, setAdminSubTab] = useState<'users' | 'payments' | 'pricing'>('users');
  const [users, setUsers] = useState<UserProfile[]>([]);
  const [loadingUsers, setLoadingUsers] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'active' | 'suspended'>('all');
  const [selectedUserId, setSelectedUserId] = useState<string | null>(null);
  const [userTransactions, setUserTransactions] = useState<CoinTransactionRecord[]>([]);
  const [busyMap, setBusyMap] = useState<Record<string, boolean>>({});
  const [feedback, setFeedback] = useState<{ type: 'ok' | 'err'; text: string } | null>(null);

  // Coin adjustment input state per user
  const [coinAmountInput, setCoinAmountInput] = useState<Record<string, string>>({});
  const [coinNoteInput, setCoinNoteInput] = useState<Record<string, string>>({});

  // Payment queue filter & admin notes
  const [paymentFilter, setPaymentFilter] = useState<'all' | 'pending' | 'approved' | 'rejected'>('pending');
  const [paymentAdminNotes, setPaymentAdminNotes] = useState<Record<string, string>>({});

  // Global coin pricing & payment config state
  const [draftCosts, setDraftCosts] = useState<CoinCosts>(coinCosts);
  const [draftPaymentConfig, setDraftPaymentConfig] = useState<PaymentConfig>(paymentConfig);
  const [savingCosts, setSavingCosts] = useState(false);

  useEffect(() => {
    setDraftCosts(coinCosts);
  }, [coinCosts]);

  useEffect(() => {
    setDraftPaymentConfig(paymentConfig);
  }, [paymentConfig]);

  useEffect(() => {
    const usersQuery = query(
      collection(db, 'users'),
      orderBy('createdAt', 'desc')
    );
    const unsub = onSnapshot(
      usersQuery,
      (snap) => {
        const list: UserProfile[] = snap.docs.map((d) => d.data() as UserProfile);
        setUsers(list);
        setLoadingUsers(false);
      },
      (err) => {
        setLoadingUsers(false);
        handleFirestoreError(err, OperationType.LIST, 'users');
      }
    );
    return () => unsub();
  }, []);

  useEffect(() => {
    if (!selectedUserId) {
      setUserTransactions([]);
      return;
    }
    const txQuery = query(
      collection(db, 'users', selectedUserId, 'coinTransactions'),
      orderBy('createdAt', 'desc'),
      limit(15)
    );
    const unsub = onSnapshot(
      txQuery,
      (snap) => {
        setUserTransactions(
          snap.docs.map((d) => ({
            id: d.id,
            ...(d.data() as Omit<CoinTransactionRecord, 'id'>),
          }))
        );
      },
      (err) => {
        handleFirestoreError(
          err,
          OperationType.LIST,
          `users/${selectedUserId}/coinTransactions`
        );
      }
    );
    return () => unsub();
  }, [selectedUserId]);

  const filteredUsers = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    return users.filter((u) => {
      if (statusFilter !== 'all' && u.accountStatus !== statusFilter) {
        return false;
      }
      if (!q) return true;
      return (
        u.fullName.toLowerCase().includes(q) ||
        u.phone.toLowerCase().includes(q) ||
        u.email.toLowerCase().includes(q)
      );
    });
  }, [users, searchQuery, statusFilter]);

  const metrics = useMemo(() => {
    const totalUsers = users.length;
    const activeUsers = users.filter((u) => u.accountStatus === 'active').length;
    const totalCoins = users.reduce((sum, u) => sum + (u.coins || 0), 0);
    const totalEnabledServices = users.reduce(
      (sum, u) =>
        sum +
        Object.values(u.services || {}).filter(Boolean).length,
      0
    );
    return { totalUsers, activeUsers, totalCoins, totalEnabledServices };
  }, [users]);

  const handleToggleSingleService = async (
    user: UserProfile,
    serviceKey: ServiceKey
  ) => {
    const busyKey = `${user.uid}:${serviceKey}`;
    setBusyMap((prev) => ({ ...prev, [busyKey]: true }));
    setFeedback(null);
    try {
      const nextServices = {
        ...EMPTY_SERVICES,
        ...user.services,
        [serviceKey]: !Boolean(user.services?.[serviceKey]),
      };
      await adminToggleUserService({
        targetUid: user.uid,
        services: nextServices,
      });
    } catch (err) {
      setFeedback({
        type: 'err',
        text: err instanceof Error ? err.message : 'Imeshindikana kubadili huduma.',
      });
    } finally {
      setBusyMap((prev) => ({ ...prev, [busyKey]: false }));
    }
  };

  const handleToggleAllServices = async (user: UserProfile, enable: boolean) => {
    const busyKey = `${user.uid}:all`;
    setBusyMap((prev) => ({ ...prev, [busyKey]: true }));
    setFeedback(null);
    try {
      await adminToggleUserService({
        targetUid: user.uid,
        services: enable ? ALL_ENABLED_SERVICES : EMPTY_SERVICES,
      });
    } catch (err) {
      setFeedback({
        type: 'err',
        text: err instanceof Error ? err.message : 'Imeshindikana kubadili huduma.',
      });
    } finally {
      setBusyMap((prev) => ({ ...prev, [busyKey]: false }));
    }
  };

  const handleToggleStatus = async (user: UserProfile) => {
    const busyKey = `${user.uid}:status`;
    setBusyMap((prev) => ({ ...prev, [busyKey]: true }));
    setFeedback(null);
    try {
      await adminSetAccountStatus({
        targetUid: user.uid,
        accountStatus: user.accountStatus === 'active' ? 'suspended' : 'active',
      });
    } catch (err) {
      setFeedback({
        type: 'err',
        text: err instanceof Error ? err.message : 'Imeshindikana kubadili hali ya akaunti.',
      });
    } finally {
      setBusyMap((prev) => ({ ...prev, [busyKey]: false }));
    }
  };

  const handleCoinAction = async (
    user: UserProfile,
    mode: 'topup' | 'deduct',
    presetAmount?: number
  ) => {
    const rawAmt = presetAmount ?? Number(coinAmountInput[user.uid] || 0);
    if (!Number.isInteger(rawAmt) || rawAmt <= 0) {
      setFeedback({
        type: 'err',
        text: 'Ingiza idadi halali ya coin (namba kamili zaidi ya 0).',
      });
      return;
    }
    const busyKey = `${user.uid}:coins`;
    setBusyMap((prev) => ({ ...prev, [busyKey]: true }));
    setFeedback(null);
    try {
      await adminAdjustUserCoins({
        targetUid: user.uid,
        adminUid: currentAdminUid,
        currentCoins: user.coins,
        mode,
        amount: rawAmt,
        note:
          coinNoteInput[user.uid] ||
          (mode === 'topup' ? 'Admin ameongeza coin' : 'Admin amepunguza coin'),
      });
      setCoinAmountInput((prev) => ({ ...prev, [user.uid]: '' }));
      setCoinNoteInput((prev) => ({ ...prev, [user.uid]: '' }));
      setFeedback({
        type: 'ok',
        text: `${mode === 'topup' ? 'Zimeongezwa' : 'Zimepunguzwa'} coin ${rawAmt} kwa ${user.fullName}.`,
      });
    } catch (err) {
      setFeedback({
        type: 'err',
        text: err instanceof Error ? err.message : 'Imeshindikana kurekebisha coin.',
      });
    } finally {
      setBusyMap((prev) => ({ ...prev, [busyKey]: false }));
    }
  };

  const pendingPaymentsCount = useMemo(
    () => paymentRequests.filter((p) => p.status === 'pending').length,
    [paymentRequests]
  );

  const filteredPayments = useMemo(() => {
    if (paymentFilter === 'all') return paymentRequests;
    return paymentRequests.filter((p) => p.status === paymentFilter);
  }, [paymentRequests, paymentFilter]);

  const handleSaveGlobalCosts = async (e: React.FormEvent) => {
    e.preventDefault();
    setSavingCosts(true);
    setFeedback(null);
    try {
      await adminSaveCoinCosts({
        adminUid: currentAdminUid,
        coinCosts: draftCosts,
        paymentConfig: draftPaymentConfig,
      });
      setFeedback({
        type: 'ok',
        text: 'Bei za coin, namba za malipo, na vifurushi vimehifadhiwa.',
      });
    } catch (err) {
      setFeedback({
        type: 'err',
        text: err instanceof Error ? err.message : 'Imeshindikana kuhifadhi mipangilio.',
      });
    } finally {
      setSavingCosts(false);
    }
  };

  const handleApprovePayment = async (payment: PaymentRequestRecord) => {
    const busyKey = `pay:${payment.id}`;
    setBusyMap((prev) => ({ ...prev, [busyKey]: true }));
    setFeedback(null);
    try {
      const nextBalance = await adminApprovePaymentRequest({
        payment,
        adminUid: currentAdminUid,
        adminNote: paymentAdminNotes[payment.id] || '',
      });
      setFeedback({
        type: 'ok',
        text: `Malipo ${payment.transactionRef} yamekubaliwa. ${payment.userFullName} ameongezewa coin ${payment.coins} (Salio jipya: ${nextBalance}).`,
      });
    } catch (err) {
      setFeedback({
        type: 'err',
        text: err instanceof Error ? err.message : 'Imeshindikana kukubali malipo.',
      });
    } finally {
      setBusyMap((prev) => ({ ...prev, [busyKey]: false }));
    }
  };

  const handleRejectPayment = async (payment: PaymentRequestRecord) => {
    const busyKey = `pay:${payment.id}`;
    setBusyMap((prev) => ({ ...prev, [busyKey]: true }));
    setFeedback(null);
    try {
      await adminRejectPaymentRequest({
        paymentId: payment.id,
        adminUid: currentAdminUid,
        adminNote: paymentAdminNotes[payment.id] || '',
      });
      setFeedback({
        type: 'ok',
        text: `Ombi ${payment.transactionRef} limekataliwa.`,
      });
    } catch (err) {
      setFeedback({
        type: 'err',
        text: err instanceof Error ? err.message : 'Imeshindikana kukataa malipo.',
      });
    } finally {
      setBusyMap((prev) => ({ ...prev, [busyKey]: false }));
    }
  };

  const handleVerifyDsnPayment = async (payment: PaymentRequestRecord) => {
    const busyKey = `paycheck:${payment.id}`;
    setBusyMap((prev) => ({ ...prev, [busyKey]: true }));
    setFeedback(null);
    try {
      const res = await fetch(
        `/api/payments/dsn/status/${encodeURIComponent(payment.transactionRef)}`
      );
      const json = (await res.json()) as {
        ok?: boolean;
        paid?: boolean;
        failed?: boolean;
        status?: string;
        channel?: string;
        message?: string;
      };
      if (!res.ok || !json.ok) {
        throw new Error(json.message || 'Imeshindikana kukagua muamala kwenye DSN.');
      }
      setFeedback({
        type: json.failed ? 'err' : 'ok',
        text: json.paid
          ? `DSN Collect imethibitisha malipo ya ${payment.transactionRef}${json.channel ? ` (${json.channel})` : ''}. Unaweza kukubali sasa.`
          : `Hali kwenye DSN Collect kwa ${payment.transactionRef}: ${json.status || 'pending'}.`,
      });
    } catch (err) {
      setFeedback({
        type: 'err',
        text: err instanceof Error ? err.message : 'Hitilafu ya kukagua DSN.',
      });
    } finally {
      setBusyMap((prev) => ({ ...prev, [busyKey]: false }));
    }
  };

  return (
    <div className="flex-1 overflow-y-auto bg-[#f4f6f8] p-6 lg:p-8">
      <div className="max-w-6xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <h2 className="font-display text-xl font-semibold text-slate-900">
              Admin Control Panel
            </h2>
            <p className="text-sm text-slate-600 mt-0.5">
              Washa au zima huduma moja moja kwa kila mtumiaji na dhibiti salio lao la coin.
            </p>
          </div>
        </div>

        {feedback && (
          <div
            role="status"
            className={`rounded-lg border px-4 py-2.5 text-xs font-medium ${
              feedback.type === 'ok'
                ? 'border-emerald-200 bg-emerald-50 text-emerald-800'
                : 'border-red-200 bg-red-50 text-red-700'
            }`}
          >
            {feedback.text}
          </div>
        )}

        {/* 4-column Summary Metrics */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          <div className="bg-white border border-slate-200 rounded-lg p-4">
            <p className="text-xs text-slate-500">Watumiaji Wote</p>
            <p className="text-2xl font-semibold text-slate-900 tabular-nums mt-1">
              {metrics.totalUsers}
            </p>
          </div>
          <div className="bg-white border border-slate-200 rounded-lg p-4">
            <p className="text-xs text-slate-500">Akaunti Hai</p>
            <p className="text-2xl font-semibold text-emerald-700 tabular-nums mt-1">
              {metrics.activeUsers}
            </p>
          </div>
          <div className="bg-white border border-slate-200 rounded-lg p-4">
            <p className="text-xs text-slate-500">Jumla ya Coin</p>
            <p className="text-2xl font-semibold text-[#0f4c75] tabular-nums mt-1">
              {metrics.totalCoins.toLocaleString()}
            </p>
          </div>
          <div className="bg-white border border-slate-200 rounded-lg p-4">
            <p className="text-xs text-slate-500">Malipo Yanayosubiri</p>
            <p className="text-2xl font-semibold text-amber-700 tabular-nums mt-1">
              {pendingPaymentsCount}
            </p>
          </div>
        </div>

        {/* Admin Control Panel Internal Navigation */}
        <div className="border-b border-slate-200 flex items-center gap-6 text-sm font-medium overflow-x-auto">
          <button
            type="button"
            onClick={() => setAdminSubTab('users')}
            className={`py-2.5 border-b-2 transition-colors whitespace-nowrap shrink-0 ${
              adminSubTab === 'users'
                ? 'border-[#0f4c75] text-slate-900'
                : 'border-transparent text-slate-500 hover:text-slate-900'
            }`}
          >
            Watumiaji &amp; Huduma ({metrics.totalUsers})
          </button>
          <button
            type="button"
            onClick={() => setAdminSubTab('payments')}
            className={`py-2.5 border-b-2 transition-colors whitespace-nowrap shrink-0 ${
              adminSubTab === 'payments'
                ? 'border-[#0f4c75] text-slate-900'
                : 'border-transparent text-slate-500 hover:text-slate-900'
            }`}
          >
            Maombi ya Malipo ({pendingPaymentsCount})
          </button>
          <button
            type="button"
            onClick={() => setAdminSubTab('pricing')}
            className={`py-2.5 border-b-2 transition-colors whitespace-nowrap shrink-0 ${
              adminSubTab === 'pricing'
                ? 'border-[#0f4c75] text-slate-900'
                : 'border-transparent text-slate-500 hover:text-slate-900'
            }`}
          >
            Bei &amp; Namba za Malipo
          </button>
        </div>

        {/* Sub-tab 1: Payment Approvals Queue */}
        {adminSubTab === 'payments' && (
          <div className="space-y-4">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div className="flex items-center gap-2">
                <CreditCard className="w-4 h-4 text-[#0f4c75]" aria-hidden="true" />
                <h3 className="text-sm font-semibold text-slate-900">
                  Uhakiki wa Malipo ya Watumiaji
                </h3>
              </div>

              <div
                className="flex items-center gap-1 p-1 bg-slate-200/70 rounded-lg"
                role="group"
                aria-label="Chuja maombi ya malipo"
              >
                {(
                  [
                    { id: 'pending', label: 'Inasubiri' },
                    { id: 'approved', label: 'Yamekubaliwa' },
                    { id: 'rejected', label: 'Yamekataliwa' },
                    { id: 'all', label: 'Yote' },
                  ] as const
                ).map((tab) => (
                  <button
                    key={tab.id}
                    type="button"
                    onClick={() => setPaymentFilter(tab.id)}
                    className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 ${
                      paymentFilter === tab.id
                        ? 'bg-white text-slate-900 shadow-xs'
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    {tab.label}
                  </button>
                ))}
              </div>
            </div>

            {filteredPayments.length === 0 ? (
              <div className="bg-white border border-slate-200 rounded-lg p-8 text-center text-sm text-slate-500">
                Hakuna maombi ya malipo kwa kichujio hiki.
              </div>
            ) : (
              <div className="space-y-3">
                {filteredPayments.map((pay) => {
                  const busy = Boolean(busyMap[`pay:${pay.id}`]);
                  return (
                    <div
                      key={pay.id}
                      className="bg-white border border-slate-200 rounded-lg p-5 flex flex-col lg:flex-row lg:items-center justify-between gap-4"
                    >
                      <div className="space-y-1.5 min-w-0">
                        <div className="flex flex-wrap items-center gap-2">
                          <span className="text-sm font-semibold font-mono-tabular text-slate-900">
                            {pay.transactionRef}
                          </span>
                          <span className="text-slate-300" aria-hidden="true">
                            ·
                          </span>
                          <span className="text-sm font-semibold text-slate-800">
                            {pay.userFullName}
                          </span>
                          <span className="text-slate-300" aria-hidden="true">
                            ·
                          </span>
                          {pay.status === 'approved' ? (
                            <span className="inline-flex items-center gap-1 text-xs font-medium text-emerald-700">
                              <CheckCircle2 className="w-3.5 h-3.5" aria-hidden="true" />
                              Imekubaliwa
                            </span>
                          ) : pay.status === 'rejected' ? (
                            <span className="inline-flex items-center gap-1 text-xs font-medium text-red-600">
                              <XCircle className="w-3.5 h-3.5" aria-hidden="true" />
                              Imekataliwa
                            </span>
                          ) : (
                            <span className="inline-flex items-center gap-1 text-xs font-medium text-amber-700">
                              <Clock className="w-3.5 h-3.5" aria-hidden="true" />
                              Inasubiri Uhakiki
                            </span>
                          )}
                        </div>

                        <div className="flex flex-wrap items-center gap-2 text-xs text-slate-600">
                          <span className="font-mono-tabular font-semibold text-[#0f4c75]">
                            +{pay.coins.toLocaleString()} Coins ({pay.amountTzs.toLocaleString()} TZS)
                          </span>
                          <span aria-hidden="true">·</span>
                          <span>{PAYMENT_NETWORK_LABELS[pay.network]}</span>
                          <span aria-hidden="true">·</span>
                          <span className="font-mono-tabular">
                            Mlipaji: {pay.payerName} ({pay.payerPhone})
                          </span>
                        </div>

                        {pay.userNote && (
                          <p className="text-xs text-slate-500">
                            Ujumbe wa mtumiaji: {pay.userNote}
                          </p>
                        )}
                        {pay.adminNote && pay.status !== 'pending' && (
                          <p className="text-xs text-slate-600">
                            Maelezo ya Admin: {pay.adminNote}
                          </p>
                        )}
                      </div>

                      {pay.status === 'pending' && (
                        <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2 shrink-0">
                          <input
                            type="text"
                            placeholder="Maelezo ya Admin (hiari)"
                            value={paymentAdminNotes[pay.id] || ''}
                            onChange={(e) =>
                              setPaymentAdminNotes((prev) => ({
                                ...prev,
                                [pay.id]: e.target.value,
                              }))
                            }
                            className="rounded-md border border-slate-200 px-3 py-2 text-xs text-slate-900 focus:border-[#0f4c75] focus:outline-none sm:w-48"
                          />
                          {pay.transactionRef.startsWith('DSN_') && (
                            <button
                              type="button"
                              disabled={Boolean(busyMap[`paycheck:${pay.id}`])}
                              onClick={() => handleVerifyDsnPayment(pay)}
                              className="px-3 py-2 text-xs font-medium text-[#0f4c75] border border-[#0f4c75]/30 hover:bg-[#0f4c75]/5 disabled:opacity-60 rounded-md transition-colors whitespace-nowrap"
                            >
                              Kagua DSN
                            </button>
                          )}
                          <button
                            type="button"
                            disabled={busy}
                            onClick={() => handleApprovePayment(pay)}
                            className="px-3.5 py-2 text-xs font-medium text-white bg-emerald-700 hover:bg-emerald-800 disabled:opacity-60 rounded-md transition-colors whitespace-nowrap"
                          >
                            Kubali &amp; Ongeza Coin
                          </button>
                          <button
                            type="button"
                            disabled={busy}
                            onClick={() => handleRejectPayment(pay)}
                            className="px-3.5 py-2 text-xs font-medium text-red-700 border border-red-200 hover:bg-red-50 disabled:opacity-60 rounded-md transition-colors whitespace-nowrap"
                          >
                            Kataa
                          </button>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        )}

        {/* Sub-tab 2: Global Coin Pricing & Payment Configuration */}
        {adminSubTab === 'pricing' && (
          <form onSubmit={handleSaveGlobalCosts} className="space-y-6">
            <div className="bg-white border border-slate-200 rounded-lg p-5 space-y-4">
              <div className="flex items-center justify-between gap-4">
                <div className="flex items-center gap-2">
                  <Sliders className="w-4 h-4 text-[#0f4c75]" aria-hidden="true" />
                  <h3 className="text-sm font-semibold text-slate-900">
                    Gharama za Coin kwa Kila Huduma
                  </h3>
                </div>
                <button
                  type="submit"
                  disabled={savingCosts}
                  className="px-4 py-2 text-xs font-medium text-white bg-[#0f4c75] hover:bg-[#0b3a5b] disabled:opacity-60 rounded-lg transition-colors whitespace-nowrap shrink-0"
                >
                  {savingCosts ? 'Inahifadhi...' : 'Hifadhi Mipangilio Yote'}
                </button>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                <div className="space-y-1">
                  <label
                    htmlFor="cost-exportPng"
                    className="block text-xs font-medium text-slate-600"
                  >
                    Export PNG (Coins)
                  </label>
                  <input
                    id="cost-exportPng"
                    type="number"
                    min={0}
                    max={10000}
                    value={draftCosts.exportPng}
                    onChange={(e) =>
                      setDraftCosts((prev) => ({
                        ...prev,
                        exportPng: Number(e.target.value) || 0,
                      }))
                    }
                    className="w-full rounded-md border border-slate-200 px-3 py-1.5 text-sm font-mono-tabular text-slate-900 focus:border-[#0f4c75] focus:outline-none"
                  />
                </div>

                <div className="space-y-1">
                  <label
                    htmlFor="cost-printPdf"
                    className="block text-xs font-medium text-slate-600"
                  >
                    Print / PDF (Coins)
                  </label>
                  <input
                    id="cost-printPdf"
                    type="number"
                    min={0}
                    max={10000}
                    value={draftCosts.printPdf}
                    onChange={(e) =>
                      setDraftCosts((prev) => ({
                        ...prev,
                        printPdf: Number(e.target.value) || 0,
                      }))
                    }
                    className="w-full rounded-md border border-slate-200 px-3 py-1.5 text-sm font-mono-tabular text-slate-900 focus:border-[#0f4c75] focus:outline-none"
                  />
                </div>

                <div className="space-y-1">
                  <label
                    htmlFor="cost-liveQr"
                    className="block text-xs font-medium text-slate-600"
                  >
                    Live Dynamic QR (Coins)
                  </label>
                  <input
                    id="cost-liveQr"
                    type="number"
                    min={0}
                    max={10000}
                    value={draftCosts.liveQr}
                    onChange={(e) =>
                      setDraftCosts((prev) => ({
                        ...prev,
                        liveQr: Number(e.target.value) || 0,
                      }))
                    }
                    className="w-full rounded-md border border-slate-200 px-3 py-1.5 text-sm font-mono-tabular text-slate-900 focus:border-[#0f4c75] focus:outline-none"
                  />
                </div>

                <div className="space-y-1">
                  <label
                    htmlFor="cost-saveRecord"
                    className="block text-xs font-medium text-slate-600"
                  >
                    Hifadhi Kumbukumbu (Coins)
                  </label>
                  <input
                    id="cost-saveRecord"
                    type="number"
                    min={0}
                    max={10000}
                    value={draftCosts.saveRecord}
                    onChange={(e) =>
                      setDraftCosts((prev) => ({
                        ...prev,
                        saveRecord: Number(e.target.value) || 0,
                      }))
                    }
                    className="w-full rounded-md border border-slate-200 px-3 py-1.5 text-sm font-mono-tabular text-slate-900 focus:border-[#0f4c75] focus:outline-none"
                  />
                </div>
              </div>
            </div>

            {/* Mobile Money Payment Channels */}
            <div className="bg-white border border-slate-200 rounded-lg p-5 space-y-4">
              <h3 className="text-sm font-semibold text-slate-900">
                Namba za Kupokea Malipo (Mobile Money &amp; Lipa Namba)
              </h3>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                <div className="space-y-1">
                  <label className="block text-xs font-medium text-slate-600">
                    Jina la Akaunti ya Malipo
                  </label>
                  <input
                    type="text"
                    value={draftPaymentConfig.accountName}
                    onChange={(e) =>
                      setDraftPaymentConfig((prev) => ({
                        ...prev,
                        accountName: e.target.value,
                      }))
                    }
                    className="w-full rounded-md border border-slate-200 px-3 py-1.5 text-sm text-slate-900 focus:border-[#0f4c75] focus:outline-none"
                  />
                </div>
                <div className="space-y-1">
                  <label className="block text-xs font-medium text-slate-600">
                    M-Pesa (Vodacom)
                  </label>
                  <input
                    type="text"
                    value={draftPaymentConfig.mpesaNumber}
                    onChange={(e) =>
                      setDraftPaymentConfig((prev) => ({
                        ...prev,
                        mpesaNumber: e.target.value,
                      }))
                    }
                    className="w-full rounded-md border border-slate-200 px-3 py-1.5 text-sm font-mono-tabular text-slate-900 focus:border-[#0f4c75] focus:outline-none"
                  />
                </div>
                <div className="space-y-1">
                  <label className="block text-xs font-medium text-slate-600">
                    Airtel Money
                  </label>
                  <input
                    type="text"
                    value={draftPaymentConfig.airtelNumber}
                    onChange={(e) =>
                      setDraftPaymentConfig((prev) => ({
                        ...prev,
                        airtelNumber: e.target.value,
                      }))
                    }
                    className="w-full rounded-md border border-slate-200 px-3 py-1.5 text-sm font-mono-tabular text-slate-900 focus:border-[#0f4c75] focus:outline-none"
                  />
                </div>
                <div className="space-y-1">
                  <label className="block text-xs font-medium text-slate-600">
                    Mixx by Yas (Tigo Pesa)
                  </label>
                  <input
                    type="text"
                    value={draftPaymentConfig.tigoNumber}
                    onChange={(e) =>
                      setDraftPaymentConfig((prev) => ({
                        ...prev,
                        tigoNumber: e.target.value,
                      }))
                    }
                    className="w-full rounded-md border border-slate-200 px-3 py-1.5 text-sm font-mono-tabular text-slate-900 focus:border-[#0f4c75] focus:outline-none"
                  />
                </div>
                <div className="space-y-1">
                  <label className="block text-xs font-medium text-slate-600">
                    Halopesa
                  </label>
                  <input
                    type="text"
                    value={draftPaymentConfig.halopesaNumber}
                    onChange={(e) =>
                      setDraftPaymentConfig((prev) => ({
                        ...prev,
                        halopesaNumber: e.target.value,
                      }))
                    }
                    className="w-full rounded-md border border-slate-200 px-3 py-1.5 text-sm font-mono-tabular text-slate-900 focus:border-[#0f4c75] focus:outline-none"
                  />
                </div>
                <div className="space-y-1">
                  <label className="block text-xs font-medium text-slate-600">
                    Lipa Namba
                  </label>
                  <input
                    type="text"
                    value={draftPaymentConfig.lipaNamba}
                    onChange={(e) =>
                      setDraftPaymentConfig((prev) => ({
                        ...prev,
                        lipaNamba: e.target.value,
                      }))
                    }
                    className="w-full rounded-md border border-slate-200 px-3 py-1.5 text-sm font-mono-tabular text-slate-900 focus:border-[#0f4c75] focus:outline-none"
                  />
                </div>
              </div>

              <div className="space-y-1">
                <label className="block text-xs font-medium text-slate-600">
                  Maelekezo ya Malipo kwa Watumiaji
                </label>
                <textarea
                  rows={2}
                  value={draftPaymentConfig.instructions}
                  onChange={(e) =>
                    setDraftPaymentConfig((prev) => ({
                      ...prev,
                      instructions: e.target.value,
                    }))
                  }
                  className="w-full rounded-md border border-slate-200 px-3 py-2 text-xs text-slate-900 focus:border-[#0f4c75] focus:outline-none"
                />
              </div>
            </div>

            {/* Editable Coin Packages */}
            <div className="bg-white border border-slate-200 rounded-lg p-5 space-y-4">
              <h3 className="text-sm font-semibold text-slate-900">
                Vifurushi vya Kununua Coin (TZS)
              </h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {draftPaymentConfig.packages.map((pkg, idx) => (
                  <div
                    key={pkg.id}
                    className="rounded-lg border border-slate-200 p-3.5 grid grid-cols-3 gap-2.5"
                  >
                    <div className="col-span-3 sm:col-span-1 space-y-1">
                      <label className="block text-[11px] font-medium text-slate-500">
                        Jina la Kifurushi
                      </label>
                      <input
                        type="text"
                        value={pkg.label}
                        onChange={(e) =>
                          setDraftPaymentConfig((prev) => ({
                            ...prev,
                            packages: prev.packages.map((item, i) =>
                              i === idx ? { ...item, label: e.target.value } : item
                            ),
                          }))
                        }
                        className="w-full rounded-md border border-slate-200 px-2.5 py-1.5 text-xs text-slate-900 focus:border-[#0f4c75] focus:outline-none"
                      />
                    </div>
                    <div className="space-y-1">
                      <label className="block text-[11px] font-medium text-slate-500">
                        Coin
                      </label>
                      <input
                        type="number"
                        min={1}
                        max={100000}
                        value={pkg.coins}
                        onChange={(e) =>
                          setDraftPaymentConfig((prev) => ({
                            ...prev,
                            packages: prev.packages.map((item, i) =>
                              i === idx
                                ? { ...item, coins: Math.max(1, Number(e.target.value) || 1) }
                                : item
                            ),
                          }))
                        }
                        className="w-full rounded-md border border-slate-200 px-2.5 py-1.5 text-xs font-mono-tabular text-slate-900 focus:border-[#0f4c75] focus:outline-none"
                      />
                    </div>
                    <div className="space-y-1">
                      <label className="block text-[11px] font-medium text-slate-500">
                        Bei (TZS)
                      </label>
                      <input
                        type="number"
                        min={100}
                        max={50000000}
                        value={pkg.priceTzs}
                        onChange={(e) =>
                          setDraftPaymentConfig((prev) => ({
                            ...prev,
                            packages: prev.packages.map((item, i) =>
                              i === idx
                                ? {
                                    ...item,
                                    priceTzs: Math.max(100, Number(e.target.value) || 100),
                                  }
                                : item
                            ),
                          }))
                        }
                        className="w-full rounded-md border border-slate-200 px-2.5 py-1.5 text-xs font-mono-tabular text-slate-900 focus:border-[#0f4c75] focus:outline-none"
                      />
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </form>
        )}

        {/* Sub-tab 3: Users & Services */}
        {adminSubTab === 'users' && (
          <>
            {/* Search & Status Filter */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div className="relative flex-1 max-w-md">
                <Search
                  className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2"
                  aria-hidden="true"
                />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Tafuta kwa jina, namba ya simu, au email..."
                  className="w-full rounded-lg border border-slate-200 bg-white pl-9 pr-3 py-2 text-sm text-slate-900 focus:border-[#0f4c75] focus:outline-none"
                />
              </div>

              <div
                className="flex items-center gap-1 p-1 bg-slate-200/70 rounded-lg self-start"
                role="group"
                aria-label="Chuja watumiaji"
              >
                {(
                  [
                    { id: 'all', label: 'Wote' },
                    { id: 'active', label: 'Hai' },
                    { id: 'suspended', label: 'Waliosimamishwa' },
                  ] as const
                ).map((tab) => (
                  <button
                    key={tab.id}
                    type="button"
                    onClick={() => setStatusFilter(tab.id)}
                    className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 ${
                      statusFilter === tab.id
                        ? 'bg-white text-slate-900 shadow-xs'
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    {tab.label}
                  </button>
                ))}
              </div>
            </div>

        {/* Users List */}
        {loadingUsers ? (
          <div className="bg-white border border-slate-200 rounded-lg p-6 space-y-4">
            <div className="h-5 w-64 bg-slate-200 rounded animate-pulse" />
            <div className="h-20 w-full bg-slate-100 rounded animate-pulse" />
          </div>
        ) : filteredUsers.length === 0 ? (
          <div className="bg-white border border-slate-200 rounded-lg p-8 text-center text-sm text-slate-500">
            Hakuna watumiaji waliopatikana kwa kichujio hiki.
          </div>
        ) : (
          <div className="space-y-4">
            {filteredUsers.map((user) => {
              const isExpanded = selectedUserId === user.uid;
              const enabledCount = Object.values(user.services || {}).filter(
                Boolean
              ).length;

              return (
                <div
                  key={user.uid}
                  className="bg-white border border-slate-200 rounded-lg overflow-hidden"
                >
                  {/* User Header Row */}
                  <div className="p-5 flex flex-col lg:flex-row lg:items-center justify-between gap-4 border-b border-slate-100">
                    <div className="space-y-1 min-w-0">
                      <div className="flex flex-wrap items-center gap-2">
                        <h3 className="text-base font-semibold text-slate-900 truncate">
                          {user.fullName}
                        </h3>
                        <span className="text-xs text-slate-400" aria-hidden="true">
                          ·
                        </span>
                        <span className="text-xs font-medium text-slate-600">
                          {user.role === 'admin' ? 'Admin' : 'Mtumiaji'}
                        </span>
                        <span className="text-xs text-slate-400" aria-hidden="true">
                          ·
                        </span>
                        <span
                          className={`inline-flex items-center gap-1 text-xs font-medium ${
                            user.accountStatus === 'active'
                              ? 'text-emerald-700'
                              : 'text-red-600'
                          }`}
                        >
                          {user.accountStatus === 'active' ? (
                            <ShieldCheck className="w-3.5 h-3.5" aria-hidden="true" />
                          ) : (
                            <ShieldAlert className="w-3.5 h-3.5" aria-hidden="true" />
                          )}
                          {user.accountStatus === 'active'
                            ? 'Akaunti Hai'
                            : 'Imesimamishwa'}
                        </span>
                      </div>

                      <div className="flex flex-wrap items-center gap-2 text-xs text-slate-500 font-mono-tabular">
                        <span>{user.phone}</span>
                        <span aria-hidden="true">·</span>
                        <span className="font-sans">{user.email}</span>
                        <span aria-hidden="true">·</span>
                        <span>
                          Huduma {enabledCount}/{SERVICE_DEFINITIONS.length}
                        </span>
                      </div>
                    </div>

                    <div className="flex flex-wrap items-center gap-3 shrink-0">
                      <div className="px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-lg flex items-center gap-2">
                        <Coins className="w-4 h-4 text-amber-600" aria-hidden="true" />
                        <span className="text-sm font-semibold font-mono-tabular text-slate-900">
                          {user.coins.toLocaleString()}
                        </span>
                        <span className="text-xs text-slate-500">Coins</span>
                      </div>

                      {user.role !== 'admin' && (
                        <button
                          type="button"
                          disabled={busyMap[`${user.uid}:status`]}
                          onClick={() => handleToggleStatus(user)}
                          className={`px-3 py-2 text-xs font-medium rounded-lg border transition-colors whitespace-nowrap shrink-0 ${
                            user.accountStatus === 'active'
                              ? 'border-red-200 text-red-700 hover:bg-red-50'
                              : 'border-emerald-200 text-emerald-700 hover:bg-emerald-50'
                          }`}
                        >
                          {user.accountStatus === 'active'
                            ? 'Simamisha'
                            : 'Washa Akaunti'}
                        </button>
                      )}

                      <button
                        type="button"
                        onClick={() =>
                          setSelectedUserId(isExpanded ? null : user.uid)
                        }
                        className="px-3 py-2 text-xs font-medium text-slate-700 border border-slate-200 hover:bg-slate-50 rounded-lg transition-colors whitespace-nowrap shrink-0"
                      >
                        {isExpanded ? 'Ficha Historia' : 'Historia ya Coin'}
                      </button>
                    </div>
                  </div>

                  {/* Individual Service Toggles + Coin Management */}
                  <div className="p-5 grid grid-cols-1 lg:grid-cols-12 gap-6">
                    {/* Left 7 cols: Per-Service One-by-One Toggles */}
                    <div className="lg:col-span-7 space-y-3">
                      <div className="flex items-center justify-between gap-2">
                        <h4 className="text-xs font-semibold text-slate-700">
                          Huduma za Mtumiaji (Washa / Zima Moja Moja)
                        </h4>
                        <div className="flex items-center gap-2">
                          <button
                            type="button"
                            disabled={busyMap[`${user.uid}:all`]}
                            onClick={() => handleToggleAllServices(user, true)}
                            className="text-xs font-medium text-[#0f4c75] hover:underline whitespace-nowrap"
                          >
                            Washa Zote
                          </button>
                          <span className="text-slate-300" aria-hidden="true">
                            |
                          </span>
                          <button
                            type="button"
                            disabled={busyMap[`${user.uid}:all`]}
                            onClick={() => handleToggleAllServices(user, false)}
                            className="text-xs font-medium text-slate-500 hover:text-slate-800 hover:underline whitespace-nowrap"
                          >
                            Zima Zote
                          </button>
                        </div>
                      </div>

                      <div className="divide-y divide-slate-100 border border-slate-200 rounded-lg">
                        {SERVICE_DEFINITIONS.map((svc) => {
                          const enabled = Boolean(user.services?.[svc.key]);
                          const busy = Boolean(busyMap[`${user.uid}:${svc.key}`]);
                          return (
                            <div
                              key={svc.key}
                              className="px-3.5 py-2.5 flex items-center justify-between gap-4"
                            >
                              <div className="min-w-0">
                                <p className="text-xs font-medium text-slate-900">
                                  {svc.label}
                                </p>
                                <p className="text-xs text-slate-500 truncate">
                                  {svc.subtitle}
                                </p>
                              </div>
                              <button
                                type="button"
                                role="switch"
                                aria-checked={enabled}
                                aria-label={`${svc.label} kwa ${user.fullName}`}
                                disabled={busy}
                                onClick={() =>
                                  handleToggleSingleService(user, svc.key)
                                }
                                className={`relative inline-flex h-6 w-11 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors focus:outline-none focus-visible:ring-2 focus-visible:ring-[#0f4c75] ${
                                  enabled ? 'bg-emerald-600' : 'bg-slate-300'
                                } ${busy ? 'opacity-50' : ''}`}
                              >
                                <span
                                  className={`pointer-events-none inline-block h-5 w-5 transform rounded-full bg-white shadow transition-transform ${
                                    enabled ? 'translate-x-5' : 'translate-x-0'
                                  }`}
                                />
                              </button>
                            </div>
                          );
                        })}
                      </div>
                    </div>

                    {/* Right 5 cols: Coin Top-up & Deduction */}
                    <div className="lg:col-span-5 space-y-3">
                      <h4 className="text-xs font-semibold text-slate-700">
                        Ongeza au Punguza Coin
                      </h4>

                      <div className="flex flex-wrap gap-2">
                        {[20, 50, 100, 250].map((amt) => (
                          <button
                            key={amt}
                            type="button"
                            disabled={busyMap[`${user.uid}:coins`]}
                            onClick={() => handleCoinAction(user, 'topup', amt)}
                            className="px-3 py-1.5 text-xs font-medium font-mono-tabular bg-slate-100 hover:bg-slate-200 text-slate-800 rounded-md transition-colors whitespace-nowrap"
                          >
                            +{amt} Coins
                          </button>
                        ))}
                      </div>

                      <div className="space-y-2 pt-1">
                        <div className="grid grid-cols-2 gap-2">
                          <input
                            type="number"
                            min={1}
                            placeholder="Kiasi cha coin"
                            value={coinAmountInput[user.uid] || ''}
                            onChange={(e) =>
                              setCoinAmountInput((prev) => ({
                                ...prev,
                                [user.uid]: e.target.value,
                              }))
                            }
                            className="rounded-md border border-slate-200 px-3 py-2 text-xs font-mono-tabular text-slate-900 focus:border-[#0f4c75] focus:outline-none"
                          />
                          <input
                            type="text"
                            placeholder="Maelezo (hiari)"
                            value={coinNoteInput[user.uid] || ''}
                            onChange={(e) =>
                              setCoinNoteInput((prev) => ({
                                ...prev,
                                [user.uid]: e.target.value,
                              }))
                            }
                            className="rounded-md border border-slate-200 px-3 py-2 text-xs text-slate-900 focus:border-[#0f4c75] focus:outline-none"
                          />
                        </div>

                        <div className="grid grid-cols-2 gap-2">
                          <button
                            type="button"
                            disabled={busyMap[`${user.uid}:coins`]}
                            onClick={() => handleCoinAction(user, 'topup')}
                            className="px-3 py-2 text-xs font-medium text-white bg-[#0f4c75] hover:bg-[#0b3a5b] disabled:opacity-60 rounded-md transition-colors whitespace-nowrap"
                          >
                            Ongeza Coin
                          </button>
                          <button
                            type="button"
                            disabled={busyMap[`${user.uid}:coins`]}
                            onClick={() => handleCoinAction(user, 'deduct')}
                            className="px-3 py-2 text-xs font-medium text-slate-700 border border-slate-200 hover:bg-slate-50 disabled:opacity-60 rounded-md transition-colors whitespace-nowrap"
                          >
                            Punguza Coin
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Expandable Coin Transaction History */}
                  {isExpanded && (
                    <div className="border-t border-slate-200 bg-slate-50/70 px-5 py-4 space-y-2.5">
                      <h5 className="text-xs font-semibold text-slate-700">
                        Miamala ya Hivi Karibuni ya Coin
                      </h5>
                      {userTransactions.length === 0 ? (
                        <p className="text-xs text-slate-500">
                          Hakuna miamala ya coin bado kwa mtumiaji huyu.
                        </p>
                      ) : (
                        <div className="overflow-x-auto">
                          <table className="w-full text-xs text-left">
                            <thead>
                              <tr className="border-b border-slate-200 text-slate-500">
                                <th className="py-1.5 pr-3 font-medium">Aina</th>
                                <th className="py-1.5 pr-3 font-medium">Huduma</th>
                                <th className="py-1.5 pr-3 font-medium">Maelezo</th>
                                <th className="py-1.5 pr-3 font-medium text-right">
                                  Kiasi
                                </th>
                                <th className="py-1.5 font-medium text-right">
                                  Salio Baada
                                </th>
                              </tr>
                            </thead>
                            <tbody className="divide-y divide-slate-200/70">
                              {userTransactions.map((tx) => (
                                <tr key={tx.id}>
                                  <td className="py-2 pr-3 font-medium text-slate-800">
                                    {tx.type === 'topup'
                                      ? 'Nyongeza'
                                      : tx.type === 'deduct'
                                        ? 'Punguzo'
                                        : 'Matumizi'}
                                  </td>
                                  <td className="py-2 pr-3 text-slate-600">
                                    {tx.service}
                                  </td>
                                  <td className="py-2 pr-3 text-slate-600">
                                    {tx.note}
                                  </td>
                                  <td
                                    className={`py-2 pr-3 text-right font-mono-tabular font-medium ${
                                      tx.type === 'topup'
                                        ? 'text-emerald-700'
                                        : 'text-red-600'
                                    }`}
                                  >
                                    {tx.type === 'topup' ? '+' : '-'}
                                    {tx.amount}
                                  </td>
                                  <td className="py-2 text-right font-mono-tabular text-slate-900">
                                    {tx.balanceAfter}
                                  </td>
                                </tr>
                              ))}
                            </tbody>
                          </table>
                        </div>
                      )}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}
          </>
        )}
      </div>
    </div>
  );
};
