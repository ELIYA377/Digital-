import 'dotenv/config';
import express from 'express';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const PORT = Number(process.env.PORT || 3000);
const DSN_BASE_URL = 'https://www.dsntechnology.co.tz/api/v1';

interface DsnOrderSnapshot {
  orderId: string;
  status: string;
  paid: boolean;
  failed: boolean;
  amount?: number;
  reference?: string;
  gatewayReference?: string;
  channel?: string;
  updatedAt: number;
}

const dsnOrderCache = new Map<string, DsnOrderSnapshot>();

function normalizeTanzaniaPhone(input: string): string {
  const digits = input.replace(/\D/g, '');
  if (digits.startsWith('255') && digits.length === 12) {
    return digits;
  }
  if (digits.startsWith('0') && digits.length === 10) {
    return `255${digits.slice(1)}`;
  }
  if (digits.length === 9 && (digits.startsWith('7') || digits.startsWith('6'))) {
    return `255${digits}`;
  }
  return digits;
}

function classifyDsnStatus(rawStatus: string | undefined): {
  paid: boolean;
  failed: boolean;
  normalized: string;
} {
  const s = (rawStatus || '').trim().toLowerCase();
  const paid = ['successful', 'success', 'completed', 'paid', 'settled'].includes(s);
  const failed = ['failed', 'cancelled', 'canceled', 'expired', 'rejected', 'error'].includes(s);
  return {
    paid,
    failed,
    normalized: paid ? 'successful' : failed ? 'failed' : s || 'pending',
  };
}

function getDsnCredentials(): { apiKey: string; userId: string } {
  return {
    apiKey: (process.env.DSN_API_KEY || '').trim(),
    userId: (process.env.DSN_USER_ID || '').trim(),
  };
}

async function startServer() {
  const app = express();
  app.use(express.json({ limit: '1mb' }));

  // DSN Collect configuration check (never returns secret keys)
  app.get('/api/payments/dsn/config', (_req, res) => {
    const { apiKey, userId } = getDsnCredentials();
    const appUrl = (process.env.APP_URL || '').replace(/\/$/, '');
    res.json({
      configured: Boolean(apiKey && userId),
      hasApiKey: Boolean(apiKey),
      hasUserId: Boolean(userId),
      webhookUrl: appUrl ? `${appUrl}/api/payments/dsn/webhook` : '/api/payments/dsn/webhook',
    });
  });

  // Trigger USSD Push collection via DSN Collect
  app.post('/api/payments/dsn/collect', async (req, res) => {
    const { apiKey, userId } = getDsnCredentials();
    if (!apiKey) {
      res.status(503).json({
        ok: false,
        code: 'MISSING_API_KEY',
        message: 'DSN_API_KEY haijawekwa kwenye mazingira ya server.',
      });
      return;
    }
    if (!userId) {
      res.status(400).json({
        ok: false,
        code: 'MISSING_USER_ID',
        message:
          'Merchant User ID (DSN_USER_ID, mfano DSN-0036) inahitajika kutoka akaunti yako ya DSN Collect ili kutuma USSD Push.',
      });
      return;
    }

    const body = req.body as {
      amount?: number;
      phone?: string;
      orderId?: string;
      customerName?: string;
      customerEmail?: string;
      description?: string;
    };

    const amount = Math.round(Number(body.amount || 0));
    const normalizedPhone = normalizeTanzaniaPhone(String(body.phone || ''));
    const orderId = String(body.orderId || `ORD_${Date.now()}`).trim();

    if (!Number.isFinite(amount) || amount < 100) {
      res.status(400).json({
        ok: false,
        message: 'Kiasi cha malipo (TZS) si sahihi.',
      });
      return;
    }
    if (!/^255[67]\d{8}$/.test(normalizedPhone)) {
      res.status(400).json({
        ok: false,
        message:
          'Weka namba sahihi ya simu ya Tanzania (mfano 0712345678 au 255712345678).',
      });
      return;
    }

    try {
      const upstreamRes = await fetch(`${DSN_BASE_URL}/collect`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Accept: 'application/json',
          'X-API-Key': apiKey,
          'X-User-Id': userId,
        },
        body: JSON.stringify({
          amount,
          phone: normalizedPhone,
          customer_phone: normalizedPhone,
          customer_name: String(body.customerName || 'Mteja').slice(0, 120),
          customer_email: String(body.customerEmail || 'customer@digitalsales.co.tz').slice(0, 160),
          order_id: orderId,
          reference: orderId,
          description: String(body.description || 'Malipo ya Coin').slice(0, 200),
          user_id: userId,
        }),
      });

      const rawText = await upstreamRes.text();
      let data: Record<string, unknown> = {};
      try {
        data = JSON.parse(rawText) as Record<string, unknown>;
      } catch {
        data = { rawText };
      }

      if (!upstreamRes.ok) {
        const msg =
          (typeof data.description === 'string' && data.description) ||
          (typeof data.message === 'string' && data.message) ||
          `DSN Collect imerudisha hitilafu (${upstreamRes.status}).`;
        res.status(upstreamRes.status).json({
          ok: false,
          code: data.code || 'DSN_ERROR',
          message: msg,
        });
        return;
      }

      const resolvedOrderId =
        (typeof data.order_id === 'string' && data.order_id) ||
        (typeof (data.data as Record<string, unknown> | undefined)?.order_id === 'string' &&
          ((data.data as Record<string, unknown>).order_id as string)) ||
        orderId;

      dsnOrderCache.set(resolvedOrderId, {
        orderId: resolvedOrderId,
        status: 'pending',
        paid: false,
        failed: false,
        amount,
        updatedAt: Date.now(),
      });

      res.json({
        ok: true,
        orderId: resolvedOrderId,
        phone: normalizedPhone,
        amount,
        message:
          (typeof data.message === 'string' && data.message) ||
          'Ombi la USSD Push limetumwa kwenye simu yako. Weka namba ya siri (PIN) kukamilisha malipo.',
        gateway: data,
      });
    } catch (err) {
      res.status(502).json({
        ok: false,
        message:
          err instanceof Error
            ? `Imeshindikana kuwasiliana na DSN Collect: ${err.message}`
            : 'Imeshindikana kuwasiliana na DSN Collect.',
      });
    }
  });

  // Query live payment status from DSN Collect
  app.get('/api/payments/dsn/status/:orderId', async (req, res) => {
    const orderId = String(req.params.orderId || '').trim();
    if (!orderId || orderId.length > 128) {
      res.status(400).json({ ok: false, message: 'Order ID si sahihi.' });
      return;
    }

    const cached = dsnOrderCache.get(orderId);
    if (cached && cached.paid) {
      res.json({
        ok: true,
        orderId,
        status: cached.status,
        paid: true,
        failed: false,
        amount: cached.amount,
        reference: cached.reference,
        gatewayReference: cached.gatewayReference,
        channel: cached.channel,
      });
      return;
    }

    const { apiKey, userId } = getDsnCredentials();
    if (!apiKey || !userId) {
      res.status(400).json({
        ok: false,
        code: !apiKey ? 'MISSING_API_KEY' : 'MISSING_USER_ID',
        message:
          'DSN_API_KEY na DSN_USER_ID vinahitajika kukagua hali ya muamala.',
      });
      return;
    }

    try {
      const upstreamRes = await fetch(
        `${DSN_BASE_URL}/status/${encodeURIComponent(orderId)}`,
        {
          method: 'GET',
          headers: {
            Accept: 'application/json',
            'X-API-Key': apiKey,
            'X-User-Id': userId,
          },
        }
      );

      const rawText = await upstreamRes.text();
      let data: Record<string, unknown> = {};
      try {
        data = JSON.parse(rawText) as Record<string, unknown>;
      } catch {
        data = { rawText };
      }

      if (!upstreamRes.ok) {
        const msg =
          (typeof data.description === 'string' && data.description) ||
          (typeof data.message === 'string' && data.message) ||
          `Imeshindikana kukagua muamala (${upstreamRes.status}).`;
        res.status(upstreamRes.status).json({
          ok: false,
          orderId,
          message: msg,
        });
        return;
      }

      const nested = (data.data as Record<string, unknown> | undefined) || data;
      const rawStatus =
        (typeof nested.payment_status === 'string' && nested.payment_status) ||
        (typeof nested.status === 'string' && nested.status) ||
        (typeof data.status === 'string' && data.status) ||
        'pending';

      const classified = classifyDsnStatus(rawStatus);
      const snapshot: DsnOrderSnapshot = {
        orderId,
        status: classified.normalized,
        paid: classified.paid,
        failed: classified.failed,
        amount: typeof nested.amount === 'number' ? nested.amount : undefined,
        reference:
          typeof nested.reference === 'string' ? nested.reference : undefined,
        gatewayReference:
          typeof nested.gateway_reference === 'string'
            ? nested.gateway_reference
            : undefined,
        channel: typeof nested.channel === 'string' ? nested.channel : undefined,
        updatedAt: Date.now(),
      };
      dsnOrderCache.set(orderId, snapshot);

      res.json({
        ok: true,
        ...snapshot,
        rawStatus,
      });
    } catch (err) {
      res.status(502).json({
        ok: false,
        orderId,
        message:
          err instanceof Error
            ? `Hitilafu ya mtandao wa DSN Collect: ${err.message}`
            : 'Hitilafu ya mtandao wa DSN Collect.',
      });
    }
  });

  // Real-time webhook endpoint for DSN Collect notifications
  app.post('/api/payments/dsn/webhook', (req, res) => {
    const body = (req.body || {}) as Record<string, unknown>;
    const orderId =
      (typeof body.order_id === 'string' && body.order_id) ||
      (typeof body.reference === 'string' && body.reference) ||
      '';

    if (orderId) {
      const rawStatus =
        (typeof body.status === 'string' && body.status) ||
        (body.event === 'payment.successful' ? 'successful' : 'pending');
      const classified = classifyDsnStatus(rawStatus);
      dsnOrderCache.set(orderId, {
        orderId,
        status: classified.normalized,
        paid: classified.paid,
        failed: classified.failed,
        amount: typeof body.amount === 'number' ? body.amount : undefined,
        reference:
          typeof body.reference === 'string' ? body.reference : undefined,
        gatewayReference:
          typeof body.gateway_reference === 'string'
            ? body.gateway_reference
            : undefined,
        channel: typeof body.channel === 'string' ? body.channel : undefined,
        updatedAt: Date.now(),
      });
    }

    res.status(200).json({ received: true });
  });

  // Vite dev middleware vs production static dist
  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distDir = path.resolve(__dirname, 'dist');
    app.use(express.static(distDir));
    app.get('/{*splat}', (_req, res) => {
      res.sendFile(path.join(distDir, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running on http://0.0.0.0:${PORT}`);
  });
}

void startServer();
