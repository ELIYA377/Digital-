import { useCallback, useEffect, useRef, useState } from 'react';
import {
  onAuthStateChanged,
  signInWithPopup,
  signOut,
  User,
} from 'firebase/auth';
import {
  collection,
  doc,
  limit,
  onSnapshot,
  orderBy,
  query,
  where,
} from 'firebase/firestore';
import QRCode from 'qrcode';
import {
  AlertCircle,
  ArrowLeft,
  CheckCircle2,
  Coins,
  Download,
  Lock,
  LogOut,
  Printer,
} from 'lucide-react';
import {
  ADMIN_BOOTSTRAP_EMAIL,
  auth,
  db,
  googleProvider,
  handleFirestoreError,
  OperationType,
} from './firebase';
import {
  DEFAULT_LICENSE_DATA,
  LicenseData,
  LicenseFieldKey,
  MaskMode,
  QrMode,
  TEMPLATE_IMAGE_PATH,
  ZoomMode,
} from './types/license';
import {
  DEFAULT_TIN_DATA,
  formatTinNumber,
  TIN_FIELD_OVERLAYS,
  TIN_TEMPLATE_HEIGHT,
  TIN_TEMPLATE_IMAGE_PATH,
  TIN_TEMPLATE_WIDTH,
  TinData,
  TinFieldKey,
} from './types/tin';
import {
  AdminActivityLogRecord,
  CoinCosts,
  CoinTransactionRecord,
  DEFAULT_COIN_COSTS,
  DEFAULT_PAYMENT_CONFIG,
  PaymentConfig,
  PaymentRequestRecord,
  SavedLicenseRecord,
  SavedTinRecord,
  UserProfile,
} from './types/account';
import {
  buildChromeDocumentBaseName,
  buildLicensePdf,
  buildTinPdf,
  composeLicenseQrWithTausiLogo,
  createCleanedTemplateDataUrl,
  extractTausiQrLogoDataUrl,
  triggerChromeBlobDownload,
} from './utils/templateProcessor';
import {
  adminApprovePaymentRequest,
  adminSaveCoinCosts,
  deleteSavedLicense,
  deleteSavedTin,
  ensureAdminBootstrapProfile,
  logAdminActivity,
  saveLicenseToCloud,
  saveTinToCloud,
  spendUserCoins,
} from './services/firestoreService';
import { AuthGate } from './components/AuthGate';
import { ToolsHub } from './components/ToolsHub';
import { PaymentPanel } from './components/PaymentPanel';
import { AdminControlPanel } from './components/AdminControlPanel';
import { SavedRecordsPanel } from './components/SavedRecordsPanel';
import { LicenseFormSidebar } from './components/LicenseFormSidebar';
import { LicensePreviewCanvas } from './components/LicensePreviewCanvas';
import { TinFormSidebar } from './components/TinFormSidebar';
import { TinPreviewCanvas } from './components/TinPreviewCanvas';
import { TermsModal } from './components/TermsModal';

type WorkspaceTab = 'hub' | 'editor' | 'tin' | 'payment' | 'records' | 'admin';

const ZOOM_OPTIONS: { value: ZoomMode; label: string }[] = [
  { value: 'fit', label: 'Fit' },
  { value: '75', label: '75%' },
  { value: '100', label: '100%' },
  { value: '125', label: '125%' },
];

export default function App() {
  // Auth & Profile State
  const [firebaseUser, setFirebaseUser] = useState<User | null>(null);
  const [loadingAuth, setLoadingAuth] = useState(true);
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [loadingProfile, setLoadingProfile] = useState(false);
  const [bootstrappingAdmin, setBootstrappingAdmin] = useState(false);
  const [pinUnlocked, setPinUnlocked] = useState(false);

  // Global Coin Costs, Payment Config & User Cloud Data
  const [coinCosts, setCoinCosts] = useState<CoinCosts>(DEFAULT_COIN_COSTS);
  const [paymentConfig, setPaymentConfig] = useState<PaymentConfig>(
    DEFAULT_PAYMENT_CONFIG
  );
  const [paymentRequests, setPaymentRequests] = useState<
    PaymentRequestRecord[]
  >([]);
  const [savedLicenses, setSavedLicenses] = useState<SavedLicenseRecord[]>([]);
  const [savedTins, setSavedTins] = useState<SavedTinRecord[]>([]);
  const [transactions, setTransactions] = useState<CoinTransactionRecord[]>([]);
  const [adminLogs, setAdminLogs] = useState<AdminActivityLogRecord[]>([]);
  const [editingLicenseId, setEditingLicenseId] = useState<string | null>(null);
  const [editingTinId, setEditingTinId] = useState<string | null>(null);

  // Workspace UI State
  const [activeTab, setActiveTab] = useState<WorkspaceTab>('hub');
  const [zoomMode, setZoomMode] = useState<ZoomMode>('fit');
  const [showTermsModal, setShowTermsModal] = useState(false);

  // Business License Editor State
  const [data, setData] = useState<LicenseData>(DEFAULT_LICENSE_DATA);
  const [maskMode, setMaskMode] = useState<MaskMode>('seamless');
  const [qrMode, setQrMode] = useState<QrMode>('live');
  const [activeField, setActiveField] = useState<LicenseFieldKey | null>(null);
  const [cleanedTemplateUrl, setCleanedTemplateUrl] = useState<string | null>(
    null
  );
  const [tausiLogoUrl, setTausiLogoUrl] = useState<string | null>(null);
  const [qrDataUrl, setQrDataUrl] = useState<string | null>(null);

  // TIN Certificate Editor State
  const [tinData, setTinData] = useState<TinData>(DEFAULT_TIN_DATA);
  const [tinMaskMode, setTinMaskMode] = useState<MaskMode>('seamless');
  const [tinQrMode, setTinQrMode] = useState<QrMode>('live');
  const [activeTinField, setActiveTinField] = useState<TinFieldKey | null>(
    null
  );
  const [cleanedTinTemplateUrl, setCleanedTinTemplateUrl] = useState<
    string | null
  >(null);
  const [tinQrDataUrl, setTinQrDataUrl] = useState<string | null>(null);

  const [isExporting, setIsExporting] = useState(false);
  const [isSavingRecord, setIsSavingRecord] = useState(false);
  const [notice, setNotice] = useState<{
    type: 'ok' | 'err';
    text: string;
  } | null>(null);

  const inputRefs = useRef<
    Partial<Record<LicenseFieldKey, HTMLInputElement | HTMLSelectElement | null>>
  >({});
  const tinInputRefs = useRef<
    Partial<Record<TinFieldKey, HTMLInputElement | HTMLSelectElement | null>>
  >({});

  // Subscribe to Firebase Auth state
  useEffect(() => {
    const unsub = onAuthStateChanged(auth, (user) => {
      setFirebaseUser(user);
      setLoadingAuth(false);
      if (user) {
        const unlocked =
          sessionStorage.getItem(`pin_unlocked_${user.uid}`) === '1';
        setPinUnlocked(unlocked);
      } else {
        setProfile(null);
        setPinUnlocked(false);
      }
    });
    return () => unsub();
  }, []);

  // Subscribe to current user's Firestore profile
  useEffect(() => {
    if (!firebaseUser) return;
    setLoadingProfile(true);
    const userPath = `users/${firebaseUser.uid}`;
    const isAdminEmail =
      firebaseUser.email?.toLowerCase() === ADMIN_BOOTSTRAP_EMAIL.toLowerCase();

    const unsub = onSnapshot(
      doc(db, 'users', firebaseUser.uid),
      (snap) => {
        const existingData = snap.exists()
          ? (snap.data() as UserProfile)
          : null;
        if (existingData) {
          setProfile(existingData);
        } else {
          setProfile(null);
        }
        setLoadingProfile(false);

        if (isAdminEmail) {
          setBootstrappingAdmin(true);
          void ensureAdminBootstrapProfile({
            uid: firebaseUser.uid,
            email: firebaseUser.email || ADMIN_BOOTSTRAP_EMAIL,
            existingProfile: existingData,
          }).finally(() => {
            setBootstrappingAdmin(false);
          });
        }
      },
      (err) => {
        setLoadingProfile(false);
        handleFirestoreError(err, OperationType.GET, userPath);
      }
    );
    return () => unsub();
  }, [firebaseUser]);

  const autoApprovingIdsRef = useRef<Set<string>>(new Set());
  const syncedPackagesOnceRef = useRef(false);
  const syncedDownloadCostOnceRef = useRef(false);

  // Subscribe to global coin pricing & payment settings
  useEffect(() => {
    if (!firebaseUser) return;
    const isAdminUser =
      profile?.role === 'admin' ||
      firebaseUser.email?.toLowerCase() === ADMIN_BOOTSTRAP_EMAIL.toLowerCase();

    const unsub = onSnapshot(
      doc(db, 'settings', 'system'),
      (snap) => {
        if (snap.exists()) {
          const d = snap.data() as {
            coinCosts?: CoinCosts;
            paymentConfig?: PaymentConfig;
          };
          const migratedFlag =
            typeof window !== 'undefined' &&
            window.localStorage.getItem('ddp_migrated_pdf_2coins') === '1';
          const hasLegacyTenCoinDownload =
            !migratedFlag &&
            Boolean(d.coinCosts) &&
            d.coinCosts!.exportPng === 10 &&
            d.coinCosts!.printPdf === 10;

          const resolvedCosts: CoinCosts = d.coinCosts
            ? hasLegacyTenCoinDownload
              ? { ...d.coinCosts, exportPng: 2, printPdf: 2 }
              : d.coinCosts
            : DEFAULT_COIN_COSTS;
          setCoinCosts(resolvedCosts);

          let nextConfig: PaymentConfig | undefined;
          let hasLegacyDefaultIds = false;
          if (d.paymentConfig) {
            const savedPkgs = d.paymentConfig.packages || [];
            hasLegacyDefaultIds =
              savedPkgs.length === 0 ||
              savedPkgs.some((p) =>
                ['pkg_starter', 'pkg_standard', 'pkg_business', 'pkg_pro'].includes(
                  p.id
                )
              );
            nextConfig = {
              ...DEFAULT_PAYMENT_CONFIG,
              ...d.paymentConfig,
              packages: hasLegacyDefaultIds
                ? DEFAULT_PAYMENT_CONFIG.packages
                : savedPkgs,
            };
            setPaymentConfig(nextConfig);
          }

          const shouldSyncPackages =
            isAdminUser && hasLegacyDefaultIds && !syncedPackagesOnceRef.current;
          const shouldSyncDownloadCost =
            isAdminUser &&
            hasLegacyTenCoinDownload &&
            !syncedDownloadCostOnceRef.current;

          if (shouldSyncPackages || shouldSyncDownloadCost) {
            if (shouldSyncPackages) syncedPackagesOnceRef.current = true;
            if (shouldSyncDownloadCost) {
              syncedDownloadCostOnceRef.current = true;
              if (typeof window !== 'undefined') {
                window.localStorage.setItem('ddp_migrated_pdf_2coins', '1');
              }
            }
            void adminSaveCoinCosts({
              adminUid: firebaseUser.uid,
              coinCosts: resolvedCosts,
              paymentConfig: nextConfig,
              skipAuditLog: true,
            }).catch(() => {
              // Non-fatal; local UI already uses updated costs/packages
            });
          }
        }
      },
      (err) => {
        handleFirestoreError(err, OperationType.GET, 'settings/system');
      }
    );
    return () => unsub();
  }, [firebaseUser, profile?.role]);

  // Subscribe to user's saved licenses, TIN certificates, payment requests & coin transactions
  useEffect(() => {
    if (!firebaseUser || !profile || !pinUnlocked) {
      setSavedLicenses([]);
      setSavedTins([]);
      setTransactions([]);
      setPaymentRequests([]);
      setAdminLogs([]);
      return;
    }

    const userIsAdmin =
      profile.role === 'admin' ||
      firebaseUser.email?.toLowerCase() === ADMIN_BOOTSTRAP_EMAIL.toLowerCase();

    const licensesPath = `users/${firebaseUser.uid}/licenses`;
    const licensesQ = query(
      collection(db, 'users', firebaseUser.uid, 'licenses'),
      orderBy('updatedAt', 'desc')
    );
    const unsubLicenses = onSnapshot(
      licensesQ,
      (snap) => {
        setSavedLicenses(
          snap.docs.map((d) => ({
            id: d.id,
            ...(d.data() as Omit<SavedLicenseRecord, 'id'>),
          }))
        );
      },
      (err) => {
        handleFirestoreError(err, OperationType.LIST, licensesPath);
      }
    );

    const tinsPath = `users/${firebaseUser.uid}/tinCertificates`;
    const tinsQ = query(
      collection(db, 'users', firebaseUser.uid, 'tinCertificates'),
      orderBy('updatedAt', 'desc')
    );
    const unsubTins = onSnapshot(
      tinsQ,
      (snap) => {
        setSavedTins(
          snap.docs.map((d) => ({
            id: d.id,
            ...(d.data() as Omit<SavedTinRecord, 'id'>),
          }))
        );
      },
      (err) => {
        handleFirestoreError(err, OperationType.LIST, tinsPath);
      }
    );

    const txPath = `users/${firebaseUser.uid}/coinTransactions`;
    const txQ = query(
      collection(db, 'users', firebaseUser.uid, 'coinTransactions'),
      orderBy('createdAt', 'desc'),
      limit(30)
    );
    const unsubTx = onSnapshot(
      txQ,
      (snap) => {
        setTransactions(
          snap.docs.map((d) => ({
            id: d.id,
            ...(d.data() as Omit<CoinTransactionRecord, 'id'>),
          }))
        );
      },
      (err) => {
        handleFirestoreError(err, OperationType.LIST, txPath);
      }
    );

    const paymentsPath = 'paymentRequests';
    const paymentsQ = userIsAdmin
      ? query(collection(db, 'paymentRequests'), orderBy('createdAt', 'desc'))
      : query(
          collection(db, 'paymentRequests'),
          where('userId', '==', firebaseUser.uid)
        );
    const unsubPayments = onSnapshot(
      paymentsQ,
      (snap) => {
        const list = snap.docs.map((d) => ({
          id: d.id,
          ...(d.data() as Omit<PaymentRequestRecord, 'id'>),
        }));
        if (!userIsAdmin) {
          list.sort((a, b) => {
            const ta = a.createdAt ? a.createdAt.toMillis() : Date.now();
            const tb = b.createdAt ? b.createdAt.toMillis() : Date.now();
            return tb - ta;
          });
        }
        setPaymentRequests(list);
      },
      (err) => {
        handleFirestoreError(err, OperationType.LIST, paymentsPath);
      }
    );

    let unsubAdminLogs = () => {};
    if (userIsAdmin) {
      const logsQ = query(
        collection(db, 'adminActivityLogs'),
        orderBy('createdAt', 'desc'),
        limit(150)
      );
      unsubAdminLogs = onSnapshot(
        logsQ,
        (snap) => {
          setAdminLogs(
            snap.docs.map((d) => ({
              id: d.id,
              ...(d.data() as Omit<AdminActivityLogRecord, 'id'>),
            }))
          );
        },
        (err) => {
          handleFirestoreError(err, OperationType.LIST, 'adminActivityLogs');
        }
      );
    } else {
      setAdminLogs([]);
    }

    return () => {
      unsubLicenses();
      unsubTins();
      unsubTx();
      unsubPayments();
      unsubAdminLogs();
    };
  }, [firebaseUser, profile, pinUnlocked]);

  // Automatic DSN Collect reconciliation & coin crediting when Admin session is active
  useEffect(() => {
    if (!firebaseUser || !profile || !pinUnlocked) return;
    const userIsAdmin =
      profile.role === 'admin' ||
      firebaseUser.email?.toLowerCase() === ADMIN_BOOTSTRAP_EMAIL.toLowerCase();
    if (!userIsAdmin) return;

    const pendingDsn = paymentRequests.filter(
      (req) =>
        req.status === 'pending' &&
        (req.transactionRef.startsWith('DSN_') ||
          req.transactionRef.startsWith('ORD-') ||
          req.userNote.includes('DSN Collect'))
    );
    if (pendingDsn.length === 0) return;

    let cancelled = false;
    const reconcilePendingDsn = async () => {
      for (const req of pendingDsn) {
        if (cancelled) return;
        if (autoApprovingIdsRef.current.has(req.id)) continue;
        try {
          const res = await fetch(
            `/api/payments/dsn/status/${encodeURIComponent(req.transactionRef)}`
          );
          if (!res.ok) continue;
          const json = (await res.json()) as {
            ok?: boolean;
            paid?: boolean;
            channel?: string;
          };
          if (json.ok && json.paid && !autoApprovingIdsRef.current.has(req.id)) {
            autoApprovingIdsRef.current.add(req.id);
            try {
              const nextBalance = await adminApprovePaymentRequest({
                payment: req,
                adminUid: firebaseUser.uid,
                actorName: profile.fullName,
                adminNote: `Imethibitishwa kiotomatiki kupitia DSN Collect${json.channel ? ` (${json.channel})` : ''}.`,
              });
              if (!cancelled) {
                setNotice({
                  type: 'ok',
                  text: `Malipo ${req.transactionRef} ya ${req.userFullName} yamethibitishwa kiotomatiki na kuongeza Coin ${req.coins} (Salio jipya: ${nextBalance}).`,
                });
              }
            } catch {
              autoApprovingIdsRef.current.delete(req.id);
            }
          }
        } catch {
          // Ignore transient network polling errors
        }
      }
    };

    void reconcilePendingDsn();
    const timer = window.setInterval(() => {
      void reconcilePendingDsn();
    }, 5000);

    return () => {
      cancelled = true;
      window.clearInterval(timer);
    };
  }, [firebaseUser, profile, pinUnlocked, paymentRequests]);

  // Reconstruct watermark-preserving blank templates & extract Tausi QR logo once on mount
  useEffect(() => {
    let active = true;
    createCleanedTemplateDataUrl(TEMPLATE_IMAGE_PATH)
      .then((url) => {
        if (active) setCleanedTemplateUrl(url);
      })
      .catch(() => {
        if (active) setCleanedTemplateUrl(null);
      });

    extractTausiQrLogoDataUrl(TEMPLATE_IMAGE_PATH)
      .then((url) => {
        if (active) setTausiLogoUrl(url);
      })
      .catch(() => {
        if (active) setTausiLogoUrl(null);
      });

    createCleanedTemplateDataUrl(
      TIN_TEMPLATE_IMAGE_PATH,
      TIN_TEMPLATE_WIDTH,
      TIN_TEMPLATE_HEIGHT,
      TIN_FIELD_OVERLAYS
    )
      .then((url) => {
        if (active) setCleanedTinTemplateUrl(url);
      })
      .catch(() => {
        if (active) setCleanedTinTemplateUrl(null);
      });

    return () => {
      active = false;
    };
  }, []);

  // Generate scannable QR code for Business License with all edited fields & centered Tausi logo
  useEffect(() => {
    if (qrMode !== 'live') return;
    let active = true;

    const payload = [
      `UNITED REPUBLIC OF TANZANIA - BUSINESS LICENSE`,
      `B.L. NO: ${data.blNo}`,
      `ISSUING OFFICE: ${data.issuingOffice}`,
      `TIN: ${data.taxId}`,
      `ISSUED TO: ${data.licensee}`,
      `BUSINESS OF: ${data.businessOf}`,
      `LICENSING TYPE: ${data.licensingType}`,
      `DATE OF ISSUE: ${data.dateOfIssue}`,
      `EXPIRING DATE: ${data.expiringDate}`,
      `PRINCIPAL / BRANCH: ${data.principalBranch}`,
      `REGION: ${data.region}`,
      `WARD: ${data.ward}`,
      `STREET: ${data.street}`,
      `FEE PAID (TZS): ${data.feePaid}`,
    ].join('\n');

    QRCode.toDataURL(payload, {
      margin: 1,
      width: 480,
      color: { dark: '#111827', light: '#ffffff' },
      errorCorrectionLevel: 'H',
    })
      .then((rawQrUrl) => composeLicenseQrWithTausiLogo(rawQrUrl, tausiLogoUrl))
      .then((finalUrl) => {
        if (active) setQrDataUrl(finalUrl);
      })
      .catch(() => {
        if (active) setQrDataUrl(null);
      });

    return () => {
      active = false;
    };
  }, [qrMode, data, tausiLogoUrl]);

  // Generate scannable QR code for TIN Certificate with all edited fields
  useEffect(() => {
    if (tinQrMode !== 'live') return;
    let active = true;

    const payload = [
      `TRA - CERTIFICATE OF REGISTRATION (TIN)`,
      `TAXPAYER NAME: ${tinData.taxpayerName}`,
      `TIN NUMBER: ${tinData.tinNumber}`,
      `EFFECTIVE FROM: ${tinData.effectiveFrom}`,
      `TRA LOCATION: ${tinData.traLocation}`,
      `TAX OFFICE: ${tinData.taxOffice}`,
      `PHYSICAL LOCATION: ${tinData.physicalLocation}`,
      `STREET / AREA: ${tinData.streetArea}`,
    ].join('\n');

    QRCode.toDataURL(payload, {
      margin: 1,
      width: 480,
      color: { dark: '#111827', light: '#ffffff' },
      errorCorrectionLevel: 'L',
    })
      .then((url) => {
        if (active) setTinQrDataUrl(url);
      })
      .catch(() => {
        if (active) setTinQrDataUrl(null);
      });

    return () => {
      active = false;
    };
  }, [tinQrMode, tinData]);

  const isAdmin =
    Boolean(profile?.role === 'admin') ||
    firebaseUser?.email?.toLowerCase() === ADMIN_BOOTSTRAP_EMAIL.toLowerCase();

  const handleGoogleSignIn = useCallback(async () => {
    await signInWithPopup(auth, googleProvider);
  }, []);

  const openWorkspaceTab = useCallback((tab: WorkspaceTab) => {
    setNotice(null);
    setActiveTab(tab);
  }, []);

  const handleSignOut = useCallback(async () => {
    if (firebaseUser) {
      sessionStorage.removeItem(`pin_unlocked_${firebaseUser.uid}`);
    }
    setPinUnlocked(false);
    setActiveTab('hub');
    await signOut(auth);
  }, [firebaseUser]);

  const handleLockSession = useCallback(() => {
    if (firebaseUser) {
      sessionStorage.removeItem(`pin_unlocked_${firebaseUser.uid}`);
    }
    setPinUnlocked(false);
  }, [firebaseUser]);

  const handlePinUnlocked = useCallback(() => {
    if (firebaseUser) {
      sessionStorage.setItem(`pin_unlocked_${firebaseUser.uid}`, '1');
    }
    setPinUnlocked(true);
  }, [firebaseUser]);

  // Business License Handlers
  const handleChangeField = useCallback(
    (key: LicenseFieldKey, value: string) => {
      const nextValue =
        key === 'taxId'
          ? formatTinNumber(value)
          : key === 'licensee'
            ? value.toUpperCase()
            : value;
      setData((prev) => ({ ...prev, [key]: nextValue }));
    },
    []
  );

  const handleSelectFieldOnPreview = useCallback((key: LicenseFieldKey) => {
    setActiveField(key);
    const input = inputRefs.current[key];
    if (input) {
      input.focus();
      input.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    }
  }, []);

  const registerInputRef = useCallback(
    (
      key: LicenseFieldKey,
      el: HTMLInputElement | HTMLSelectElement | null
    ) => {
      inputRefs.current[key] = el;
    },
    []
  );

  const handleResetDefaults = useCallback(() => {
    setData(DEFAULT_LICENSE_DATA);
    setEditingLicenseId(null);
  }, []);

  const handleClearFields = useCallback(() => {
    setEditingLicenseId(null);
    setData({
      blNo: '',
      issuingOffice: '',
      taxId: '',
      licensee: '',
      businessOf: '',
      licensingType: '',
      dateOfIssue: '',
      expiringDate: '',
      principalBranch: '',
      region: '',
      ward: '',
      street: '',
      feePaid: '',
    });
  }, []);

  // TIN Certificate Handlers
  const handleChangeTinField = useCallback(
    (key: TinFieldKey, value: string) => {
      const nextValue =
        key === 'tinNumber'
          ? formatTinNumber(value)
          : key === 'taxpayerName'
            ? value.toUpperCase()
            : value;
      setTinData((prev) => ({ ...prev, [key]: nextValue }));
    },
    []
  );

  const handleSelectTinFieldOnPreview = useCallback((key: TinFieldKey) => {
    setActiveTinField(key);
    const input = tinInputRefs.current[key];
    if (input) {
      input.focus();
      input.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    }
  }, []);

  const registerTinInputRef = useCallback(
    (key: TinFieldKey, el: HTMLInputElement | HTMLSelectElement | null) => {
      tinInputRefs.current[key] = el;
    },
    []
  );

  const handleResetTinDefaults = useCallback(() => {
    setTinData(DEFAULT_TIN_DATA);
    setEditingTinId(null);
  }, []);

  const handleClearTinFields = useCallback(() => {
    setEditingTinId(null);
    setTinData({
      taxpayerName: '',
      tinNumber: '',
      effectiveFrom: '',
      traLocation: '',
      taxOffice: '',
      physicalLocation: '',
      streetArea: '',
    });
  }, []);

  const checkServiceAccessAndBalance = useCallback(
    (params: {
      servicePerm: keyof UserProfile['services'];
      altServicePerm?: keyof UserProfile['services'];
      requireTinAccess?: boolean;
      serviceName: string;
      cost?: number;
    }): boolean => {
      if (!profile || !firebaseUser) return false;

      if (profile.accountStatus !== 'active') {
        setNotice({
          type: 'err',
          text: 'Akaunti yako imesimamishwa na Admin.',
        });
        return false;
      }

      if (params.requireTinAccess && !isAdmin && !profile.services?.tinCertificate) {
        setNotice({
          type: 'err',
          text: 'Huduma ya "Cheti cha TIN" haijawashwa bado. Wasiliana na Admin kuwasha huduma hii.',
        });
        return false;
      }

      const hasMainPerm = Boolean(profile.services?.[params.servicePerm]);
      const hasAltPerm = params.altServicePerm
        ? Boolean(profile.services?.[params.altServicePerm])
        : false;

      if (!isAdmin && !hasMainPerm && !hasAltPerm) {
        setNotice({
          type: 'err',
          text: `Huduma ya "${params.serviceName}" haijawashwa bado. Wasiliana na Admin kuwasha huduma hii.`,
        });
        return false;
      }

      if (!isAdmin && (params.cost ?? 0) > 0) {
        const required = params.cost ?? 0;
        if (profile.coins < required) {
          setNotice({
            type: 'err',
            text: `Salio la coin halitoshi kwa "${params.serviceName}". Unahitaji Coin ${required}, salio lako ni Coin ${profile.coins}.`,
          });
          return false;
        }
      }

      return true;
    },
    [profile, firebaseUser, isAdmin]
  );

  const ensureServiceAndSpendCoins = useCallback(
    async (params: {
      servicePerm: keyof UserProfile['services'];
      altServicePerm?: keyof UserProfile['services'];
      requireTinAccess?: boolean;
      serviceName: string;
      spendKey?: 'exportPng' | 'printPdf' | 'liveQr' | 'saveRecord';
      cost?: number;
      note: string;
    }): Promise<{ allowed: boolean; coinsDeducted: number; balanceAfter: number }> => {
      if (!profile || !firebaseUser) {
        return { allowed: false, coinsDeducted: 0, balanceAfter: 0 };
      }

      const canProceed = checkServiceAccessAndBalance({
        servicePerm: params.servicePerm,
        altServicePerm: params.altServicePerm,
        requireTinAccess: params.requireTinAccess,
        serviceName: params.serviceName,
        cost: params.spendKey ? params.cost : 0,
      });

      if (!canProceed) {
        return { allowed: false, coinsDeducted: 0, balanceAfter: profile.coins };
      }

      let coinsDeducted = 0;
      let balanceAfter = profile.coins;

      if (!isAdmin && params.spendKey && (params.cost ?? 0) > 0) {
        const required = params.cost ?? 0;
        balanceAfter = await spendUserCoins({
          uid: firebaseUser.uid,
          amount: required,
          service: params.spendKey,
          note: params.note,
        });
        coinsDeducted = required;
      }

      if (isAdmin && params.spendKey && params.spendKey !== 'saveRecord') {
        void logAdminActivity({
          actorUid: firebaseUser.uid,
          actorName: profile.fullName,
          actorEmail: firebaseUser.email || ADMIN_BOOTSTRAP_EMAIL,
          category: 'document_action',
          actionTitle: `Ametumia zana: ${params.serviceName}`,
          targetUid: firebaseUser.uid,
          targetLabel: `${profile.fullName} (Admin)`,
          documentPath: params.requireTinAccess
            ? 'tinCertificate (pdf/print)'
            : 'businessLicense (pdf/print)',
          details: params.note,
        }).catch(() => {});
      }

      return { allowed: true, coinsDeducted, balanceAfter };
    },
    [profile, firebaseUser, isAdmin, checkServiceAccessAndBalance]
  );

  const handleRequestQrMode = useCallback(
    (mode: QrMode) => {
      setNotice(null);
      setQrMode(mode);
    },
    []
  );

  const handleRequestTinQrMode = useCallback(
    (mode: QrMode) => {
      setNotice(null);
      setTinQrMode(mode);
    },
    []
  );

  const handlePrint = useCallback(async () => {
    setNotice(null);
    const isTinTab = activeTab === 'tin';
    try {
      const res = await ensureServiceAndSpendCoins({
        servicePerm: 'printPdf',
        requireTinAccess: isTinTab,
        serviceName: 'Chapisha / PDF',
        spendKey: 'printPdf',
        cost: coinCosts.printPdf,
        note: isTinTab
          ? `Print/PDF ya TIN ${tinData.tinNumber || 'Cheti'}`
          : `Print/PDF ya ${data.blNo || 'Leseni'}`,
      });
      if (res.allowed) {
        const previousTitle = document.title;
        document.title = buildChromeDocumentBaseName({
          personName: isTinTab ? tinData.taxpayerName : data.licensee,
          documentNumber: isTinTab ? tinData.tinNumber : data.blNo,
          fallbackPerson: isTinTab ? 'TAXPAYER' : 'LICENSEE',
          fallbackNumber: isTinTab ? 'TIN' : 'LICENSE',
        });
        if (!isAdmin && res.coinsDeducted > 0) {
          setNotice({
            type: 'ok',
            text: `Kichapishi kimefunguliwa · Umekatwa Coin ${res.coinsDeducted} · Salio lililobaki: ${res.balanceAfter.toLocaleString()} Coins.`,
          });
        }
        window.print();
        window.setTimeout(() => {
          document.title = previousTitle;
        }, 1000);
      }
    } catch (err) {
      setNotice({
        type: 'err',
        text: err instanceof Error ? err.message : 'Imeshindikana kuchapisha.',
      });
    }
  }, [
    activeTab,
    ensureServiceAndSpendCoins,
    coinCosts.printPdf,
    data.blNo,
    data.licensee,
    tinData.tinNumber,
    tinData.taxpayerName,
    isAdmin,
  ]);

  const handleDownloadPdf = useCallback(async () => {
    if (!profile) return;
    setNotice(null);
    setIsExporting(true);
    const isTinTab = activeTab === 'tin';
    const hasPrintPerm = Boolean(profile.services?.printPdf);
    const downloadPerm: keyof UserProfile['services'] = hasPrintPerm
      ? 'printPdf'
      : 'exportPng';
    const downloadSpendKey: 'printPdf' | 'exportPng' = hasPrintPerm
      ? 'printPdf'
      : 'exportPng';
    const downloadCost = hasPrintPerm ? coinCosts.printPdf : coinCosts.exportPng;

    try {
      const canStart = checkServiceAccessAndBalance({
        servicePerm: downloadPerm,
        altServicePerm: 'printPdf',
        requireTinAccess: isTinTab,
        serviceName: 'Download PDF',
        cost: downloadCost,
      });
      if (!canStart) return;

      const pdfResult = isTinTab
        ? await buildTinPdf({
            templateUrl:
              tinMaskMode === 'seamless' && cleanedTinTemplateUrl
                ? cleanedTinTemplateUrl
                : TIN_TEMPLATE_IMAGE_PATH,
            data: tinData,
            maskMode: tinMaskMode,
            qrMode: tinQrMode,
            qrDataUrl: tinQrDataUrl,
          })
        : await buildLicensePdf({
            templateUrl:
              maskMode === 'seamless' && cleanedTemplateUrl
                ? cleanedTemplateUrl
                : TEMPLATE_IMAGE_PATH,
            data,
            maskMode,
            qrMode,
            qrDataUrl,
          });

      const spendRes = await ensureServiceAndSpendCoins({
        servicePerm: downloadPerm,
        altServicePerm: 'printPdf',
        requireTinAccess: isTinTab,
        serviceName: 'Download PDF',
        spendKey: downloadSpendKey,
        cost: downloadCost,
        note: isTinTab
          ? `Download PDF ya TIN ${tinData.tinNumber || 'Cheti'} (${pdfResult.filename})`
          : `Download PDF ya Leseni ${data.blNo || 'Leseni'} (${pdfResult.filename})`,
      });
      if (!spendRes.allowed) return;

      triggerChromeBlobDownload(pdfResult.blob, pdfResult.filename);

      if (isAdmin) {
        setNotice({
          type: 'ok',
          text: `PDF imepakuliwa kupitia Chrome: ${pdfResult.filename} (Admin — Coin hazijakatwa).`,
        });
      } else {
        setNotice({
          type: 'ok',
          text: `PDF imepakuliwa kupitia Chrome: ${pdfResult.filename} · Umekatwa Coin ${spendRes.coinsDeducted} · Salio lililobaki: ${spendRes.balanceAfter.toLocaleString()} Coins.`,
        });
      }
    } catch (err) {
      setNotice({
        type: 'err',
        text: err instanceof Error ? err.message : 'Imeshindikana kupakua PDF.',
      });
    } finally {
      setIsExporting(false);
    }
  }, [
    profile,
    activeTab,
    coinCosts.printPdf,
    coinCosts.exportPng,
    checkServiceAccessAndBalance,
    ensureServiceAndSpendCoins,
    maskMode,
    cleanedTemplateUrl,
    data,
    qrMode,
    qrDataUrl,
    tinMaskMode,
    cleanedTinTemplateUrl,
    tinData,
    tinQrMode,
    tinQrDataUrl,
    isAdmin,
  ]);

  const handleSaveToCloud = useCallback(async () => {
    if (!firebaseUser) return;
    setNotice(null);
    setIsSavingRecord(true);
    try {
      const isUpdatingExisting = Boolean(editingLicenseId);
      const res = await ensureServiceAndSpendCoins({
        servicePerm: 'saveRecords',
        serviceName: 'Hifadhi Kumbukumbu',
        spendKey: isUpdatingExisting ? undefined : 'saveRecord',
        cost: isUpdatingExisting ? 0 : coinCosts.saveRecord,
        note: `Hifadhi leseni ${data.blNo || 'Mpya'}`,
      });
      if (!res.allowed) return;

      const docId = await saveLicenseToCloud({
        uid: firebaseUser.uid,
        data,
        maskMode,
        qrMode,
        existingId: editingLicenseId,
      });
      if (isAdmin && profile) {
        void logAdminActivity({
          actorUid: firebaseUser.uid,
          actorName: profile.fullName,
          actorEmail: firebaseUser.email || ADMIN_BOOTSTRAP_EMAIL,
          category: 'document_action',
          actionTitle: isUpdatingExisting
            ? `Amesasisha leseni ${data.blNo || docId}`
            : `Amehifadhi leseni mpya ${data.blNo || docId}`,
          targetUid: firebaseUser.uid,
          targetLabel: `${profile.fullName} (Admin)`,
          documentPath: `users/${firebaseUser.uid}/licenses/${docId}`,
          details: `${isUpdatingExisting ? 'Amesasisha' : 'Amehifadhi'} leseni "${data.licensee || data.blNo}" (${data.blNo || docId}).`,
        }).catch(() => {});
      }
      setEditingLicenseId(docId);
      setNotice({
        type: 'ok',
        text: isUpdatingExisting
          ? 'Kumbukumbu ya leseni imesasishwa kwenye wingu.'
          : !isAdmin && res.coinsDeducted > 0
            ? `Leseni imehifadhiwa kwenye wingu · Umekatwa Coin ${res.coinsDeducted} · Salio lililobaki: ${res.balanceAfter.toLocaleString()} Coins.`
            : 'Leseni imehifadhiwa kwenye wingu na itapatikana kwenye vifaa vyote.',
      });
    } catch (err) {
      setNotice({
        type: 'err',
        text:
          err instanceof Error
            ? err.message
            : 'Imeshindikana kuhifadhi kumbukumbu.',
      });
    } finally {
      setIsSavingRecord(false);
    }
  }, [
    firebaseUser,
    editingLicenseId,
    ensureServiceAndSpendCoins,
    coinCosts.saveRecord,
    data,
    maskMode,
    qrMode,
    isAdmin,
    profile,
  ]);

  const handleSaveTinToCloud = useCallback(async () => {
    if (!firebaseUser) return;
    setNotice(null);
    setIsSavingRecord(true);
    try {
      const isUpdatingExisting = Boolean(editingTinId);
      const res = await ensureServiceAndSpendCoins({
        servicePerm: 'saveRecords',
        requireTinAccess: true,
        serviceName: 'Hifadhi Kumbukumbu (TIN)',
        spendKey: isUpdatingExisting ? undefined : 'saveRecord',
        cost: isUpdatingExisting ? 0 : coinCosts.saveRecord,
        note: `Hifadhi TIN ${tinData.tinNumber || 'Mpya'}`,
      });
      if (!res.allowed) return;

      const docId = await saveTinToCloud({
        uid: firebaseUser.uid,
        data: tinData,
        maskMode: tinMaskMode,
        qrMode: tinQrMode,
        existingId: editingTinId,
      });
      if (isAdmin && profile) {
        void logAdminActivity({
          actorUid: firebaseUser.uid,
          actorName: profile.fullName,
          actorEmail: firebaseUser.email || ADMIN_BOOTSTRAP_EMAIL,
          category: 'document_action',
          actionTitle: isUpdatingExisting
            ? `Amesasisha cheti cha TIN ${tinData.tinNumber || docId}`
            : `Amehifadhi cheti kipya cha TIN ${tinData.tinNumber || docId}`,
          targetUid: firebaseUser.uid,
          targetLabel: `${profile.fullName} (Admin)`,
          documentPath: `users/${firebaseUser.uid}/tinCertificates/${docId}`,
          details: `${isUpdatingExisting ? 'Amesasisha' : 'Amehifadhi'} cheti cha TIN "${tinData.taxpayerName || tinData.tinNumber}" (${tinData.tinNumber || docId}).`,
        }).catch(() => {});
      }
      setEditingTinId(docId);
      setNotice({
        type: 'ok',
        text: isUpdatingExisting
          ? 'Cheti cha TIN kimesasishwa kwenye wingu.'
          : !isAdmin && res.coinsDeducted > 0
            ? `Cheti cha TIN kimehifadhiwa kwenye wingu · Umekatwa Coin ${res.coinsDeducted} · Salio lililobaki: ${res.balanceAfter.toLocaleString()} Coins.`
            : 'Cheti cha TIN kimehifadhiwa kwenye wingu na kitapatikana kwenye vifaa vyote.',
      });
    } catch (err) {
      setNotice({
        type: 'err',
        text:
          err instanceof Error
            ? err.message
            : 'Imeshindikana kuhifadhi cheti cha TIN.',
      });
    } finally {
      setIsSavingRecord(false);
    }
  }, [
    firebaseUser,
    editingTinId,
    ensureServiceAndSpendCoins,
    coinCosts.saveRecord,
    tinData,
    tinMaskMode,
    tinQrMode,
    isAdmin,
    profile,
  ]);

  const handleLoadRecord = useCallback((record: SavedLicenseRecord) => {
    setData({
      blNo: record.blNo,
      issuingOffice: record.issuingOffice,
      taxId: formatTinNumber(record.taxId || '') || record.taxId,
      licensee: (record.licensee || '').toUpperCase(),
      businessOf: record.businessOf,
      licensingType: record.licensingType,
      dateOfIssue: record.dateOfIssue,
      expiringDate: record.expiringDate,
      principalBranch: record.principalBranch,
      region: record.region,
      ward: record.ward,
      street: record.street,
      feePaid: record.feePaid,
    });
    setMaskMode(record.maskMode || 'seamless');
    setQrMode(record.qrMode || 'live');
    setEditingLicenseId(record.id);
    setActiveTab('editor');
    setNotice({
      type: 'ok',
      text: `Imefungua rekodi ${record.blNo}.`,
    });
  }, []);

  const handleDeleteRecord = useCallback(
    async (recordId: string) => {
      if (!firebaseUser) return;
      await deleteSavedLicense({ uid: firebaseUser.uid, licenseId: recordId });
      if (isAdmin && profile) {
        void logAdminActivity({
          actorUid: firebaseUser.uid,
          actorName: profile.fullName,
          actorEmail: firebaseUser.email || ADMIN_BOOTSTRAP_EMAIL,
          category: 'document_action',
          actionTitle: 'Amefuta kumbukumbu ya leseni',
          targetUid: firebaseUser.uid,
          targetLabel: `${profile.fullName} (Admin)`,
          documentPath: `users/${firebaseUser.uid}/licenses/${recordId}`,
          details: `Kumbukumbu ya leseni ID ${recordId} imefutwa na Admin.`,
        }).catch(() => {});
      }
      if (editingLicenseId === recordId) {
        setEditingLicenseId(null);
      }
    },
    [firebaseUser, editingLicenseId, isAdmin, profile]
  );

  const handleLoadTinRecord = useCallback((record: SavedTinRecord) => {
    setTinData({
      taxpayerName: (record.taxpayerName || '').toUpperCase(),
      tinNumber: formatTinNumber(record.tinNumber || '') || record.tinNumber,
      effectiveFrom: record.effectiveFrom,
      traLocation: record.traLocation,
      taxOffice: record.taxOffice,
      physicalLocation: record.physicalLocation,
      streetArea: record.streetArea,
    });
    setTinMaskMode(record.maskMode || 'seamless');
    setTinQrMode(record.qrMode || 'live');
    setEditingTinId(record.id);
    setActiveTab('tin');
    setNotice({
      type: 'ok',
      text: `Imefungua cheti cha TIN ${record.tinNumber}.`,
    });
  }, []);

  const handleDeleteTinRecord = useCallback(
    async (certId: string) => {
      if (!firebaseUser) return;
      await deleteSavedTin({ uid: firebaseUser.uid, certId });
      if (isAdmin && profile) {
        void logAdminActivity({
          actorUid: firebaseUser.uid,
          actorName: profile.fullName,
          actorEmail: firebaseUser.email || ADMIN_BOOTSTRAP_EMAIL,
          category: 'document_action',
          actionTitle: 'Amefuta cheti cha TIN',
          targetUid: firebaseUser.uid,
          targetLabel: `${profile.fullName} (Admin)`,
          documentPath: `users/${firebaseUser.uid}/tinCertificates/${certId}`,
          details: `Kumbukumbu ya cheti cha TIN ID ${certId} imefutwa na Admin.`,
        }).catch(() => {});
      }
      if (editingTinId === certId) {
        setEditingTinId(null);
      }
    },
    [firebaseUser, editingTinId, isAdmin, profile]
  );

  // Gate: require Google device verification + registration + PIN unlock
  if (
    loadingAuth ||
    loadingProfile ||
    bootstrappingAdmin ||
    !firebaseUser ||
    !profile ||
    !pinUnlocked
  ) {
    return (
      <AuthGate
        firebaseUser={firebaseUser}
        profile={profile}
        loadingAuth={
          loadingAuth ||
          bootstrappingAdmin ||
          (Boolean(firebaseUser) && loadingProfile)
        }
        onGoogleSignIn={handleGoogleSignIn}
        onSignOut={handleSignOut}
        onPinUnlocked={handlePinUnlocked}
      />
    );
  }

  const isDocumentEditorTab = activeTab === 'editor' || activeTab === 'tin';
  const canPrintPdf = isAdmin || Boolean(profile.services?.printPdf);
  const canDownloadPdf =
    isAdmin ||
    Boolean(profile.services?.printPdf) ||
    Boolean(profile.services?.exportPng);
  const downloadPdfCost = profile.services?.printPdf
    ? coinCosts.printPdf
    : coinCosts.exportPng;
  const totalSavedCount = savedLicenses.length + savedTins.length;
  const pendingPaymentsCount = paymentRequests.filter(
    (p) => p.status === 'pending'
  ).length;
  const activeToolTitle =
    activeTab === 'editor'
      ? 'Business License Generator'
      : activeTab === 'tin'
        ? 'TIN Certificate Generator'
        : activeTab === 'payment'
          ? 'Mfumo wa Malipo'
          : activeTab === 'records'
            ? 'Kumbukumbu Zilizohifadhiwa'
            : activeTab === 'admin'
              ? 'Admin Control Panel'
              : 'DIGITAL DOCUMENT POTAL';

  return (
    <div className="min-h-screen lg:h-screen flex flex-col bg-[#f4f6f8] text-slate-900 lg:overflow-hidden">
      {/* Top Workbench Header (3-zone contract) */}
      <header className="no-print h-14 px-4 sm:px-5 bg-white border-b border-slate-200 flex items-center justify-between gap-4 lg:gap-8 shrink-0">
        {/* Zone 1: Brand wordmark or Isolated Tool Back + Title */}
        <div className="flex items-center gap-3 min-w-0">
          {activeTab !== 'hub' && (
            <>
              <button
                type="button"
                onClick={() => openWorkspaceTab('hub')}
                className="inline-flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-md transition-colors whitespace-nowrap shrink-0"
              >
                <ArrowLeft className="w-3.5 h-3.5" aria-hidden="true" />
                <span>Rudi Tools</span>
              </button>
              <span className="h-4 w-px bg-slate-200 shrink-0" aria-hidden="true" />
            </>
          )}
          <h1 className="font-display text-sm sm:text-base font-semibold tracking-tight text-slate-900 whitespace-nowrap truncate">
            {activeToolTitle}
          </h1>
        </div>

        {/* Zone 2: Hub Navigation Links (shown only on Tools Hub so each tool stays isolated) */}
        {activeTab === 'hub' ? (
          <nav className="hidden md:flex items-center gap-5 text-sm font-medium">
            <button
              type="button"
              onClick={() => openWorkspaceTab('hub')}
              className="py-1 transition-colors whitespace-nowrap shrink-0 border-b-2 border-[#0f4c75] text-slate-900"
            >
              Tools
            </button>
            <button
              type="button"
              onClick={() => openWorkspaceTab('payment')}
              className="py-1 transition-colors whitespace-nowrap shrink-0 border-b-2 border-transparent text-slate-500 hover:text-slate-900"
            >
              Malipo
            </button>
            <button
              type="button"
              onClick={() => openWorkspaceTab('records')}
              className="py-1 transition-colors whitespace-nowrap shrink-0 border-b-2 border-transparent text-slate-500 hover:text-slate-900"
            >
              Kumbukumbu ({totalSavedCount})
            </button>
            {isAdmin && (
              <button
                type="button"
                onClick={() => openWorkspaceTab('admin')}
                className="py-1 transition-colors whitespace-nowrap shrink-0 border-b-2 border-transparent text-slate-500 hover:text-slate-900"
              >
                Admin Control Panel
              </button>
            )}
          </nav>
        ) : (
          <div className="hidden md:block" />
        )}

        {/* Zone 3: Coin balance (opens Payment Tool) + Actions */}
        <div className="flex items-center gap-2 sm:gap-2.5 shrink-0">
          <button
            type="button"
            onClick={() => openWorkspaceTab('payment')}
            title="Fungua Mfumo wa Malipo (Nunua Coin)"
            className="hidden md:flex items-center gap-1.5 px-3 py-1.5 bg-slate-50 hover:bg-slate-100 border border-slate-200 rounded-lg text-xs whitespace-nowrap shrink-0 transition-colors"
          >
            <Coins className="w-3.5 h-3.5 text-amber-600" aria-hidden="true" />
            <span className="font-semibold font-mono-tabular text-slate-900">
              {profile.coins.toLocaleString()}
            </span>
            <span className="text-slate-500">Coins</span>
          </button>

          {isDocumentEditorTab && (
            <>
              <div
                className="hidden xl:flex items-center gap-0.5 p-1 bg-slate-100 rounded-lg"
                role="group"
                aria-label="Preview zoom level"
              >
                {ZOOM_OPTIONS.map((opt) => (
                  <button
                    key={opt.value}
                    type="button"
                    onClick={() => setZoomMode(opt.value)}
                    className={`px-2 py-1 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 tabular-nums ${
                      zoomMode === opt.value
                        ? 'bg-white text-slate-900 shadow-xs'
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    {opt.label}
                  </button>
                ))}
              </div>

              <button
                type="button"
                onClick={handlePrint}
                className={`hidden sm:inline-flex items-center gap-1.5 px-3 py-2 text-xs font-medium border rounded-lg transition-colors whitespace-nowrap shrink-0 ${
                  canPrintPdf
                    ? 'text-slate-700 bg-white border-slate-200 hover:bg-slate-50 hover:border-slate-300'
                    : 'text-slate-400 bg-slate-50 border-slate-200'
                }`}
              >
                {canPrintPdf ? (
                  <Printer className="w-3.5 h-3.5" aria-hidden="true" />
                ) : (
                  <Lock className="w-3.5 h-3.5" aria-hidden="true" />
                )}
                Print / PDF
              </button>

              <button
                type="button"
                onClick={handleDownloadPdf}
                disabled={isExporting}
                className={`inline-flex items-center gap-1.5 px-3 sm:px-3.5 py-2 text-xs font-medium text-white rounded-lg transition-colors whitespace-nowrap shrink-0 ${
                  canDownloadPdf
                    ? activeTab === 'tin'
                      ? 'bg-[#2f6f3e] hover:bg-[#245630] disabled:opacity-60'
                      : 'bg-[#0f4c75] hover:bg-[#0b3a5b] disabled:opacity-60'
                    : 'bg-slate-400 hover:bg-slate-500'
                }`}
              >
                {canDownloadPdf ? (
                  <Download className="w-3.5 h-3.5" aria-hidden="true" />
                ) : (
                  <Lock className="w-3.5 h-3.5" aria-hidden="true" />
                )}
                <span>{isExporting ? 'Inapakua PDF...' : 'Download PDF'}</span>
                {!isAdmin && canDownloadPdf && (
                  <span className="hidden sm:inline font-mono-tabular text-white/85">
                    ({downloadPdfCost} Coins)
                  </span>
                )}
              </button>
            </>
          )}

          <button
            type="button"
            onClick={handleLockSession}
            title="Funga kwa PIN"
            aria-label="Funga kwa PIN"
            className="p-2 text-slate-500 hover:text-slate-900 hover:bg-slate-100 rounded-lg transition-colors shrink-0"
          >
            <Lock className="w-4 h-4" aria-hidden="true" />
          </button>

          <button
            type="button"
            onClick={handleSignOut}
            title="Toka kwenye akaunti"
            aria-label="Toka kwenye akaunti"
            className="p-2 text-slate-500 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors shrink-0"
          >
            <LogOut className="w-4 h-4" aria-hidden="true" />
          </button>
        </div>
      </header>

      {/* Mobile Navigation & Coin Strip */}
      <div className="no-print flex md:hidden items-center justify-between gap-2 px-4 py-2 bg-white border-b border-slate-200 overflow-x-auto">
        {activeTab === 'hub' ? (
          <div className="flex items-center gap-4 text-xs font-medium">
            <button
              type="button"
              onClick={() => openWorkspaceTab('hub')}
              className="py-1 whitespace-nowrap shrink-0 border-b-2 border-[#0f4c75] text-slate-900"
            >
              Tools
            </button>
            <button
              type="button"
              onClick={() => openWorkspaceTab('payment')}
              className="py-1 whitespace-nowrap shrink-0 border-b-2 border-transparent text-slate-500"
            >
              Malipo
            </button>
            <button
              type="button"
              onClick={() => openWorkspaceTab('records')}
              className="py-1 whitespace-nowrap shrink-0 border-b-2 border-transparent text-slate-500"
            >
              Kumbukumbu ({totalSavedCount})
            </button>
            {isAdmin && (
              <button
                type="button"
                onClick={() => openWorkspaceTab('admin')}
                className="py-1 whitespace-nowrap shrink-0 border-b-2 border-transparent text-slate-500"
              >
                Admin
              </button>
            )}
          </div>
        ) : (
          <div className="flex items-center gap-2 text-xs font-medium text-slate-700 whitespace-nowrap">
            <span>{activeToolTitle}</span>
          </div>
        )}
        <div className="flex items-center gap-2 shrink-0">
          {isDocumentEditorTab && (
            <button
              type="button"
              onClick={handlePrint}
              className="sm:hidden inline-flex items-center gap-1 px-2.5 py-1 text-xs font-medium text-slate-700 border border-slate-200 rounded-md whitespace-nowrap"
            >
              <Printer className="w-3 h-3" aria-hidden="true" />
              Print
            </button>
          )}
          <button
            type="button"
            onClick={() => openWorkspaceTab('payment')}
            className="flex items-center gap-1 px-2.5 py-1 bg-slate-50 border border-slate-200 rounded-md text-xs whitespace-nowrap"
          >
            <Coins className="w-3 h-3 text-amber-600" aria-hidden="true" />
            <span className="font-semibold font-mono-tabular text-slate-900">
              {profile.coins.toLocaleString()}
            </span>
          </button>
        </div>
      </div>

      {/* Notice Banner */}
      {notice && (
        <div
          role="status"
          aria-live="polite"
          className={`no-print sticky top-0 z-30 px-4 sm:px-5 py-2.5 text-xs font-medium flex items-center justify-between gap-4 border-b shadow-xs ${
            notice.type === 'ok'
              ? 'bg-emerald-50 border-emerald-200 text-emerald-900'
              : 'bg-red-50 border-red-200 text-red-800'
          }`}
        >
          <div className="flex items-center gap-2 min-w-0">
            {notice.type === 'ok' ? (
              <CheckCircle2
                className="w-4 h-4 text-emerald-600 shrink-0"
                aria-hidden="true"
              />
            ) : (
              <AlertCircle
                className="w-4 h-4 text-red-600 shrink-0"
                aria-hidden="true"
              />
            )}
            <span className="leading-snug">{notice.text}</span>
          </div>
          <div className="flex items-center gap-3 shrink-0">
            {notice.text.includes('Salio la coin') && (
              <button
                type="button"
                onClick={() => openWorkspaceTab('payment')}
                className="underline font-semibold whitespace-nowrap"
              >
                Nunua Coin
              </button>
            )}
            <button
              type="button"
              onClick={() => setNotice(null)}
              className="underline whitespace-nowrap"
            >
              Funga
            </button>
          </div>
        </div>
      )}

      {/* Active Workspace View */}
      {activeTab === 'admin' && isAdmin ? (
        <AdminControlPanel
          currentAdminUid={firebaseUser.uid}
          currentAdminName={profile.fullName}
          coinCosts={coinCosts}
          paymentConfig={paymentConfig}
          paymentRequests={paymentRequests}
          adminLogs={adminLogs}
        />
      ) : activeTab === 'payment' ? (
        <PaymentPanel
          profile={profile}
          paymentConfig={paymentConfig}
          paymentRequests={paymentRequests}
        />
      ) : activeTab === 'records' ? (
        <SavedRecordsPanel
          profile={profile}
          records={savedLicenses}
          tinRecords={savedTins}
          transactions={transactions}
          onLoadRecord={handleLoadRecord}
          onDeleteRecord={handleDeleteRecord}
          onLoadTinRecord={handleLoadTinRecord}
          onDeleteTinRecord={handleDeleteTinRecord}
        />
      ) : activeTab === 'tin' ? (
        <div className="flex-1 flex flex-col lg:flex-row min-h-0">
          <TinFormSidebar
            data={tinData}
            profile={profile}
            isAdmin={isAdmin}
            coinCosts={coinCosts}
            activeField={activeTinField}
            maskMode={tinMaskMode}
            qrMode={tinQrMode}
            editingTinId={editingTinId}
            isSavingRecord={isSavingRecord}
            isExporting={isExporting}
            onChangeField={handleChangeTinField}
            onFocusField={setActiveTinField}
            onChangeMaskMode={setTinMaskMode}
            onRequestQrMode={handleRequestTinQrMode}
            onSaveToCloud={handleSaveTinToCloud}
            onDownload={handleDownloadPdf}
            onResetDefaults={handleResetTinDefaults}
            onClearFields={handleClearTinFields}
            registerInputRef={registerTinInputRef}
          />

          <TinPreviewCanvas
            data={tinData}
            cleanedTemplateUrl={cleanedTinTemplateUrl}
            maskMode={tinMaskMode}
            qrMode={tinQrMode}
            qrDataUrl={tinQrDataUrl}
            zoomMode={zoomMode}
            activeField={activeTinField}
            onSelectField={handleSelectTinFieldOnPreview}
          />
        </div>
      ) : activeTab === 'editor' ? (
        <div className="flex-1 flex flex-col lg:flex-row min-h-0">
          <LicenseFormSidebar
            data={data}
            profile={profile}
            isAdmin={isAdmin}
            coinCosts={coinCosts}
            activeField={activeField}
            maskMode={maskMode}
            qrMode={qrMode}
            editingLicenseId={editingLicenseId}
            isSavingRecord={isSavingRecord}
            isExporting={isExporting}
            onChangeField={handleChangeField}
            onFocusField={setActiveField}
            onChangeMaskMode={setMaskMode}
            onRequestQrMode={handleRequestQrMode}
            onSaveToCloud={handleSaveToCloud}
            onDownload={handleDownloadPdf}
            onResetDefaults={handleResetDefaults}
            onClearFields={handleClearFields}
            registerInputRef={registerInputRef}
          />

          <LicensePreviewCanvas
            data={data}
            cleanedTemplateUrl={cleanedTemplateUrl}
            maskMode={maskMode}
            qrMode={qrMode}
            qrDataUrl={qrDataUrl}
            zoomMode={zoomMode}
            activeField={activeField}
            onSelectField={handleSelectFieldOnPreview}
          />
        </div>
      ) : (
        <ToolsHub
          profile={profile}
          isAdmin={isAdmin}
          coinCosts={coinCosts}
          paymentConfig={paymentConfig}
          pendingPaymentsCount={pendingPaymentsCount}
          licenseCount={savedLicenses.length}
          tinCount={savedTins.length}
          onOpenTool={openWorkspaceTab}
        />
      )}

      <footer className="no-print py-2 px-4 sm:px-5 bg-white border-t border-slate-200 flex flex-wrap items-center justify-center gap-2 text-center text-xs text-slate-500 shrink-0">
        <span>&copy; Digital sales. All rights reserved.</span>
        <span aria-hidden="true">&middot;</span>
        <button
          type="button"
          onClick={() => setShowTermsModal(true)}
          className="text-slate-600 hover:text-[#0f4c75] underline transition-colors whitespace-nowrap"
        >
          Terms &amp; Conditions
        </button>
      </footer>

      <TermsModal
        open={showTermsModal}
        onClose={() => setShowTermsModal(false)}
      />
    </div>
  );
}
