import React, { useState } from 'react';
import { FolderOpen, Trash2, Coins, FileText } from 'lucide-react';
import {
  CoinTransactionRecord,
  SavedLicenseRecord,
  UserProfile,
} from '../types/account';

interface SavedRecordsPanelProps {
  profile: UserProfile;
  records: SavedLicenseRecord[];
  transactions: CoinTransactionRecord[];
  onLoadRecord: (record: SavedLicenseRecord) => void;
  onDeleteRecord: (recordId: string) => Promise<void>;
}

export const SavedRecordsPanel: React.FC<SavedRecordsPanelProps> = ({
  profile,
  records,
  transactions,
  onLoadRecord,
  onDeleteRecord,
}) => {
  const [deletingId, setDeletingId] = useState<string | null>(null);

  const handleDelete = async (id: string) => {
    setDeletingId(id);
    try {
      await onDeleteRecord(id);
    } finally {
      setDeletingId(null);
    }
  };

  return (
    <div className="flex-1 overflow-y-auto bg-[#f4f6f8] p-6 lg:p-8">
      <div className="max-w-5xl mx-auto space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h2 className="font-display text-xl font-semibold text-slate-900">
              Kumbukumbu Zilizohifadhiwa &amp; Salio la Coin
            </h2>
            <p className="text-sm text-slate-600 mt-0.5">
              Leseni zote zilizohifadhiwa zinapatikana kwenye vifaa vyako vyote bila kufutika.
            </p>
          </div>
          <div className="px-4 py-2 bg-white border border-slate-200 rounded-lg flex items-center gap-2 self-start">
            <Coins className="w-4 h-4 text-amber-600" aria-hidden="true" />
            <span className="text-sm font-semibold font-mono-tabular text-slate-900">
              {profile.coins.toLocaleString()}
            </span>
            <span className="text-xs text-slate-500">Coins Zako</span>
          </div>
        </div>

        {/* Saved Licenses Table */}
        <section className="bg-white border border-slate-200 rounded-lg overflow-hidden">
          <div className="px-5 py-4 border-b border-slate-200 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <FileText className="w-4 h-4 text-[#0f4c75]" aria-hidden="true" />
              <h3 className="text-sm font-semibold text-slate-900">
                Leseni Zilizohifadhiwa ({records.length})
              </h3>
            </div>
          </div>

          {records.length === 0 ? (
            <div className="p-8 text-center text-sm text-slate-500">
              Bado hujahifadhi leseni yoyote kwenye wingu. Hariri leseni kisha
              bonyeza &ldquo;Hifadhi Kumbukumbu&rdquo; ili izipatikane kwenye
              vifaa vingine.
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-xs text-left">
                <thead>
                  <tr className="bg-slate-50 border-b border-slate-200 text-slate-600">
                    <th className="py-2.5 px-4 font-medium">B.L. NO</th>
                    <th className="py-2.5 px-4 font-medium">Mmiliki / Biashara</th>
                    <th className="py-2.5 px-4 font-medium">Halmashauri / Mahali</th>
                    <th className="py-2.5 px-4 font-medium">Tarehe</th>
                    <th className="py-2.5 px-4 font-medium text-right">Ada (TZS)</th>
                    <th className="py-2.5 px-4 font-medium text-right">Hatua</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {records.map((rec) => (
                    <tr key={rec.id} className="hover:bg-slate-50/60">
                      <td className="py-3 px-4 font-mono-tabular font-medium text-[#0f4c75] whitespace-nowrap">
                        {rec.blNo}
                      </td>
                      <td className="py-3 px-4">
                        <p className="font-medium text-slate-900">{rec.licensee}</p>
                        <p className="text-slate-500 truncate max-w-[220px]">
                          {rec.businessOf}
                        </p>
                      </td>
                      <td className="py-3 px-4 text-slate-600">
                        <p>{rec.issuingOffice}</p>
                        <p className="text-slate-400">
                          {rec.region} · {rec.ward} · {rec.street}
                        </p>
                      </td>
                      <td className="py-3 px-4 font-mono-tabular text-slate-600 whitespace-nowrap">
                        {rec.dateOfIssue} — {rec.expiringDate}
                      </td>
                      <td className="py-3 px-4 font-mono-tabular font-medium text-slate-900 text-right whitespace-nowrap">
                        {rec.feePaid}
                      </td>
                      <td className="py-3 px-4 text-right whitespace-nowrap">
                        <div className="inline-flex items-center gap-2">
                          <button
                            type="button"
                            onClick={() => onLoadRecord(rec)}
                            className="inline-flex items-center gap-1 px-2.5 py-1.5 text-xs font-medium text-white bg-[#0f4c75] hover:bg-[#0b3a5b] rounded-md transition-colors"
                          >
                            <FolderOpen className="w-3.5 h-3.5" aria-hidden="true" />
                            Fungua
                          </button>
                          <button
                            type="button"
                            disabled={deletingId === rec.id}
                            onClick={() => handleDelete(rec.id)}
                            aria-label={`Futa rekodi ${rec.blNo}`}
                            className="p-1.5 text-slate-400 hover:text-red-600 hover:bg-red-50 rounded-md transition-colors"
                          >
                            <Trash2 className="w-3.5 h-3.5" aria-hidden="true" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </section>

        {/* Coin Transaction History */}
        <section className="bg-white border border-slate-200 rounded-lg overflow-hidden">
          <div className="px-5 py-4 border-b border-slate-200">
            <h3 className="text-sm font-semibold text-slate-900">
              Historia ya Matumizi na Nyongeza za Coin
            </h3>
          </div>

          {transactions.length === 0 ? (
            <div className="p-8 text-center text-sm text-slate-500">
              Hakuna miamala ya coin bado.
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-xs text-left">
                <thead>
                  <tr className="bg-slate-50 border-b border-slate-200 text-slate-600">
                    <th className="py-2.5 px-4 font-medium">Aina</th>
                    <th className="py-2.5 px-4 font-medium">Huduma</th>
                    <th className="py-2.5 px-4 font-medium">Maelezo</th>
                    <th className="py-2.5 px-4 font-medium text-right">Kiasi</th>
                    <th className="py-2.5 px-4 font-medium text-right">Salio</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {transactions.map((tx) => (
                    <tr key={tx.id}>
                      <td className="py-2.5 px-4 font-medium text-slate-800">
                        {tx.type === 'topup'
                          ? 'Nyongeza'
                          : tx.type === 'deduct'
                            ? 'Punguzo'
                            : 'Matumizi'}
                      </td>
                      <td className="py-2.5 px-4 text-slate-600">{tx.service}</td>
                      <td className="py-2.5 px-4 text-slate-600">{tx.note}</td>
                      <td
                        className={`py-2.5 px-4 text-right font-mono-tabular font-medium ${
                          tx.type === 'topup' ? 'text-emerald-700' : 'text-red-600'
                        }`}
                      >
                        {tx.type === 'topup' ? '+' : '-'}
                        {tx.amount}
                      </td>
                      <td className="py-2.5 px-4 text-right font-mono-tabular text-slate-900">
                        {tx.balanceAfter}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </section>
      </div>
    </div>
  );
};
