import { useCallback, useEffect, useRef, useState } from 'react';
import {
  onAuthStateChanged,
  signInWithPopup,
  signOut,
  User,
} from 'firebase/auth';
import {
  collection,
  doc,
  limit,
  onSnapshot,
  orderBy,
  query,
} from 'firebase/firestore';
import QRCode from 'qrcode';
import { Coins, Download, Lock, LogOut, Printer } from 'lucide-react';
import {
  ADMIN_BOOTSTRAP_EMAIL,
  auth,
  db,
  googleProvider,
  handleFirestoreError,
  OperationType,
} from './firebase';
import {
  DEFAULT_LICENSE_DATA,
  LicenseData,
  LicenseFieldKey,
  MaskMode,
  QrMode,
  TEMPLATE_IMAGE_PATH,
  ZoomMode,
} from './types/license';
import {
  CoinCosts,
  CoinTransactionRecord,
  DEFAULT_COIN_COSTS,
  SavedLicenseRecord,
  UserProfile,
} from './types/account';
import {
  createCleanedTemplateDataUrl,
  exportLicensePng,
} from './utils/templateProcessor';
import {
  deleteSavedLicense,
  ensureAdminBootstrapProfile,
  saveLicenseToCloud,
  spendUserCoins,
} from './services/firestoreService';
import { AuthGate } from './components/AuthGate';
import { AdminControlPanel } from './components/AdminControlPanel';
import { SavedRecordsPanel } from './components/SavedRecordsPanel';
import { LicenseFormSidebar } from './components/LicenseFormSidebar';
import { LicensePreviewCanvas } from './components/LicensePreviewCanvas';

type WorkspaceTab = 'editor' | 'records' | 'admin';

const ZOOM_OPTIONS: { value: ZoomMode; label: string }[] = [
  { value: 'fit', label: 'Fit' },
  { value: '75', label: '75%' },
  { value: '100', label: '100%' },
  { value: '125', label: '125%' },
];

export default function App() {
  // Auth & Profile State
  const [firebaseUser, setFirebaseUser] = useState<User | null>(null);
  const [loadingAuth, setLoadingAuth] = useState(true);
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [loadingProfile, setLoadingProfile] = useState(false);
  const [bootstrappingAdmin, setBootstrappingAdmin] = useState(false);
  const [pinUnlocked, setPinUnlocked] = useState(false);

  // Global Coin Costs & User Cloud Data
  const [coinCosts, setCoinCosts] = useState<CoinCosts>(DEFAULT_COIN_COSTS);
  const [savedLicenses, setSavedLicenses] = useState<SavedLicenseRecord[]>([]);
  const [transactions, setTransactions] = useState<CoinTransactionRecord[]>([]);
  const [editingLicenseId, setEditingLicenseId] = useState<string | null>(null);

  // Workspace UI State
  const [activeTab, setActiveTab] = useState<WorkspaceTab>('editor');
  const [data, setData] = useState<LicenseData>(DEFAULT_LICENSE_DATA);
  const [maskMode, setMaskMode] = useState<MaskMode>('seamless');
  const [qrMode, setQrMode] = useState<QrMode>('template');
  const [zoomMode, setZoomMode] = useState<ZoomMode>('fit');
  const [activeField, setActiveField] = useState<LicenseFieldKey | null>(null);

  const [cleanedTemplateUrl, setCleanedTemplateUrl] = useState<string | null>(
    null
  );
  const [qrDataUrl, setQrDataUrl] = useState<string | null>(null);
  const [isExporting, setIsExporting] = useState(false);
  const [isSavingRecord, setIsSavingRecord] = useState(false);
  const [notice, setNotice] = useState<{
    type: 'ok' | 'err';
    text: string;
  } | null>(null);

  const inputRefs = useRef<
    Partial<Record<LicenseFieldKey, HTMLInputElement | null>>
  >({});

  // Subscribe to Firebase Auth state
  useEffect(() => {
    const unsub = onAuthStateChanged(auth, (user) => {
      setFirebaseUser(user);
      setLoadingAuth(false);
      if (user) {
        const unlocked =
          sessionStorage.getItem(`pin_unlocked_${user.uid}`) === '1';
        setPinUnlocked(unlocked);
      } else {
        setProfile(null);
        setPinUnlocked(false);
      }
    });
    return () => unsub();
  }, []);

  // Subscribe to current user's Firestore profile
  useEffect(() => {
    if (!firebaseUser) return;
    setLoadingProfile(true);
    const userPath = `users/${firebaseUser.uid}`;
    const isAdminEmail =
      firebaseUser.email?.toLowerCase() === ADMIN_BOOTSTRAP_EMAIL.toLowerCase();

    const unsub = onSnapshot(
      doc(db, 'users', firebaseUser.uid),
      (snap) => {
        const existingData = snap.exists() ? (snap.data() as UserProfile) : null;
        if (existingData) {
          setProfile(existingData);
        } else {
          setProfile(null);
        }
        setLoadingProfile(false);

        if (isAdminEmail) {
          setBootstrappingAdmin(true);
          void ensureAdminBootstrapProfile({
            uid: firebaseUser.uid,
            email: firebaseUser.email || ADMIN_BOOTSTRAP_EMAIL,
            existingProfile: existingData,
          }).finally(() => {
            setBootstrappingAdmin(false);
          });
        }
      },
      (err) => {
        setLoadingProfile(false);
        handleFirestoreError(err, OperationType.GET, userPath);
      }
    );
    return () => unsub();
  }, [firebaseUser]);

  // Subscribe to global coin pricing settings
  useEffect(() => {
    if (!firebaseUser) return;
    const unsub = onSnapshot(
      doc(db, 'settings', 'system'),
      (snap) => {
        if (snap.exists()) {
          const d = snap.data() as { coinCosts?: CoinCosts };
          if (d.coinCosts) {
            setCoinCosts(d.coinCosts);
          }
        }
      },
      (err) => {
        handleFirestoreError(err, OperationType.GET, 'settings/system');
      }
    );
    return () => unsub();
  }, [firebaseUser]);

  // Subscribe to user's saved licenses & coin transactions once unlocked
  useEffect(() => {
    if (!firebaseUser || !profile || !pinUnlocked) {
      setSavedLicenses([]);
      setTransactions([]);
      return;
    }

    const licensesPath = `users/${firebaseUser.uid}/licenses`;
    const licensesQ = query(
      collection(db, 'users', firebaseUser.uid, 'licenses'),
      orderBy('updatedAt', 'desc')
    );
    const unsubLicenses = onSnapshot(
      licensesQ,
      (snap) => {
        setSavedLicenses(
          snap.docs.map((d) => ({
            id: d.id,
            ...(d.data() as Omit<SavedLicenseRecord, 'id'>),
          }))
        );
      },
      (err) => {
        handleFirestoreError(err, OperationType.LIST, licensesPath);
      }
    );

    const txPath = `users/${firebaseUser.uid}/coinTransactions`;
    const txQ = query(
      collection(db, 'users', firebaseUser.uid, 'coinTransactions'),
      orderBy('createdAt', 'desc'),
      limit(30)
    );
    const unsubTx = onSnapshot(
      txQ,
      (snap) => {
        setTransactions(
          snap.docs.map((d) => ({
            id: d.id,
            ...(d.data() as Omit<CoinTransactionRecord, 'id'>),
          }))
        );
      },
      (err) => {
        handleFirestoreError(err, OperationType.LIST, txPath);
      }
    );

    return () => {
      unsubLicenses();
      unsubTx();
    };
  }, [firebaseUser, profile, pinUnlocked]);

  // Reconstruct watermark-preserving blank template once on mount
  useEffect(() => {
    let active = true;
    createCleanedTemplateDataUrl(TEMPLATE_IMAGE_PATH)
      .then((url) => {
        if (active) setCleanedTemplateUrl(url);
      })
      .catch(() => {
        if (active) setCleanedTemplateUrl(null);
      });
    return () => {
      active = false;
    };
  }, []);

  // Generate scannable QR code when live QR mode is active
  useEffect(() => {
    if (qrMode !== 'live') return;
    let active = true;

    const payload = [
      `B.L. NO: ${data.blNo}`,
      `OFFICE: ${data.issuingOffice}`,
      `TIN: ${data.taxId}`,
      `ISSUED TO: ${data.licensee}`,
      `BUSINESS: ${data.businessOf}`,
      `ISSUE: ${data.dateOfIssue}`,
      `EXPIRY: ${data.expiringDate}`,
      `LOCATION: ${data.region}, ${data.ward}, ${data.street}`,
      `FEE: ${data.feePaid}`,
    ].join('\n');

    QRCode.toDataURL(payload, {
      margin: 1,
      width: 320,
      color: {
        dark: '#111827',
        light: '#ffffff',
      },
      errorCorrectionLevel: 'M',
    })
      .then((url) => {
        if (active) setQrDataUrl(url);
      })
      .catch(() => {
        if (active) setQrDataUrl(null);
      });

    return () => {
      active = false;
    };
  }, [qrMode, data]);

  const isAdmin =
    Boolean(profile?.role === 'admin') ||
    firebaseUser?.email?.toLowerCase() === ADMIN_BOOTSTRAP_EMAIL.toLowerCase();

  const handleGoogleSignIn = useCallback(async () => {
    await signInWithPopup(auth, googleProvider);
  }, []);

  const handleSignOut = useCallback(async () => {
    if (firebaseUser) {
      sessionStorage.removeItem(`pin_unlocked_${firebaseUser.uid}`);
    }
    setPinUnlocked(false);
    setActiveTab('editor');
    await signOut(auth);
  }, [firebaseUser]);

  const handleLockSession = useCallback(() => {
    if (firebaseUser) {
      sessionStorage.removeItem(`pin_unlocked_${firebaseUser.uid}`);
    }
    setPinUnlocked(false);
  }, [firebaseUser]);

  const handlePinUnlocked = useCallback(() => {
    if (firebaseUser) {
      sessionStorage.setItem(`pin_unlocked_${firebaseUser.uid}`, '1');
    }
    setPinUnlocked(true);
  }, [firebaseUser]);

  const handleChangeField = useCallback(
    (key: LicenseFieldKey, value: string) => {
      setData((prev) => ({ ...prev, [key]: value }));
    },
    []
  );

  const handleSelectFieldOnPreview = useCallback((key: LicenseFieldKey) => {
    setActiveField(key);
    const input = inputRefs.current[key];
    if (input) {
      input.focus();
      input.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    }
  }, []);

  const registerInputRef = useCallback(
    (key: LicenseFieldKey, el: HTMLInputElement | null) => {
      inputRefs.current[key] = el;
    },
    []
  );

  const handleResetDefaults = useCallback(() => {
    setData(DEFAULT_LICENSE_DATA);
    setEditingLicenseId(null);
  }, []);

  const handleClearFields = useCallback(() => {
    setEditingLicenseId(null);
    setData({
      blNo: '',
      issuingOffice: '',
      taxId: '',
      licensee: '',
      businessOf: '',
      licensingType: '',
      dateOfIssue: '',
      expiringDate: '',
      principalBranch: '',
      region: '',
      ward: '',
      street: '',
      feePaid: '',
    });
  }, []);

  const ensureServiceAndSpendCoins = useCallback(
    async (params: {
      servicePerm: keyof UserProfile['services'];
      serviceName: string;
      spendKey?: 'exportPng' | 'printPdf' | 'liveQr' | 'saveRecord';
      cost?: number;
      note: string;
    }): Promise<boolean> => {
      if (!profile || !firebaseUser) return false;

      if (profile.accountStatus !== 'active') {
        setNotice({
          type: 'err',
          text: 'Akaunti yako imesimamishwa na Admin.',
        });
        return false;
      }

      if (!isAdmin && !profile.services?.[params.servicePerm]) {
        setNotice({
          type: 'err',
          text: `Huduma ya "${params.serviceName}" haijawashwa bado. Wasiliana na Admin kuwasha huduma hii.`,
        });
        return false;
      }

      if (!isAdmin && params.spendKey && (params.cost ?? 0) > 0) {
        const required = params.cost ?? 0;
        if (profile.coins < required) {
          setNotice({
            type: 'err',
            text: `Salio la coin halitoshi kwa "${params.serviceName}". Unahitaji coin ${required}, una coin ${profile.coins}.`,
          });
          return false;
        }
        await spendUserCoins({
          uid: firebaseUser.uid,
          amount: required,
          service: params.spendKey,
          note: params.note,
        });
      }

      return true;
    },
    [profile, firebaseUser, isAdmin]
  );

  const handleRequestQrMode = useCallback(
    async (mode: QrMode) => {
      setNotice(null);
      if (mode === 'template') {
        setQrMode('template');
        return;
      }
      if (qrMode === 'live') return;

      try {
        const allowed = await ensureServiceAndSpendCoins({
          servicePerm: 'liveQr',
          serviceName: 'Live Dynamic QR',
          spendKey: 'liveQr',
          cost: coinCosts.liveQr,
          note: `Live QR kwa ${data.blNo || 'Leseni'}`,
        });
        if (allowed) {
          setQrMode('live');
        }
      } catch (err) {
        setNotice({
          type: 'err',
          text: err instanceof Error ? err.message : 'Imeshindikana kuwasha QR.',
        });
      }
    },
    [qrMode, ensureServiceAndSpendCoins, coinCosts.liveQr, data.blNo]
  );

  const handlePrint = useCallback(async () => {
    setNotice(null);
    try {
      const allowed = await ensureServiceAndSpendCoins({
        servicePerm: 'printPdf',
        serviceName: 'Chapisha / PDF',
        spendKey: 'printPdf',
        cost: coinCosts.printPdf,
        note: `Print/PDF ya ${data.blNo || 'Leseni'}`,
      });
      if (allowed) {
        window.print();
      }
    } catch (err) {
      setNotice({
        type: 'err',
        text: err instanceof Error ? err.message : 'Imeshindikana kuchapisha.',
      });
    }
  }, [ensureServiceAndSpendCoins, coinCosts.printPdf, data.blNo]);

  const handleExportPng = useCallback(async () => {
    setNotice(null);
    setIsExporting(true);
    try {
      const allowed = await ensureServiceAndSpendCoins({
        servicePerm: 'exportPng',
        serviceName: 'Export PNG',
        spendKey: 'exportPng',
        cost: coinCosts.exportPng,
        note: `Export PNG ya ${data.blNo || 'Leseni'}`,
      });
      if (!allowed) return;

      const templateUrl =
        maskMode === 'seamless' && cleanedTemplateUrl
          ? cleanedTemplateUrl
          : TEMPLATE_IMAGE_PATH;
      await exportLicensePng({
        templateUrl,
        data,
        maskMode,
        qrMode,
        qrDataUrl,
      });
      setNotice({
        type: 'ok',
        text: 'Leseni imepakuliwa kwa mafanikio.',
      });
    } catch (err) {
      setNotice({
        type: 'err',
        text: err instanceof Error ? err.message : 'Imeshindikana kupakua PNG.',
      });
    } finally {
      setIsExporting(false);
    }
  }, [
    ensureServiceAndSpendCoins,
    coinCosts.exportPng,
    maskMode,
    cleanedTemplateUrl,
    data,
    qrMode,
    qrDataUrl,
  ]);

  const handleSaveToCloud = useCallback(async () => {
    if (!firebaseUser) return;
    setNotice(null);
    setIsSavingRecord(true);
    try {
      const isUpdatingExisting = Boolean(editingLicenseId);
      const allowed = await ensureServiceAndSpendCoins({
        servicePerm: 'saveRecords',
        serviceName: 'Hifadhi Kumbukumbu',
        spendKey: isUpdatingExisting ? undefined : 'saveRecord',
        cost: isUpdatingExisting ? 0 : coinCosts.saveRecord,
        note: `Hifadhi leseni ${data.blNo || 'Mpya'}`,
      });
      if (!allowed) return;

      const docId = await saveLicenseToCloud({
        uid: firebaseUser.uid,
        data,
        maskMode,
        qrMode,
        existingId: editingLicenseId,
      });
      setEditingLicenseId(docId);
      setNotice({
        type: 'ok',
        text: isUpdatingExisting
          ? 'Kumbukumbu ya leseni imesasishwa kwenye wingu.'
          : 'Leseni imehifadhiwa kwenye wingu na itapatikana kwenye vifaa vyote.',
      });
    } catch (err) {
      setNotice({
        type: 'err',
        text:
          err instanceof Error
            ? err.message
            : 'Imeshindikana kuhifadhi kumbukumbu.',
      });
    } finally {
      setIsSavingRecord(false);
    }
  }, [
    firebaseUser,
    editingLicenseId,
    ensureServiceAndSpendCoins,
    coinCosts.saveRecord,
    data,
    maskMode,
    qrMode,
  ]);

  const handleLoadRecord = useCallback((record: SavedLicenseRecord) => {
    setData({
      blNo: record.blNo,
      issuingOffice: record.issuingOffice,
      taxId: record.taxId,
      licensee: record.licensee,
      businessOf: record.businessOf,
      licensingType: record.licensingType,
      dateOfIssue: record.dateOfIssue,
      expiringDate: record.expiringDate,
      principalBranch: record.principalBranch,
      region: record.region,
      ward: record.ward,
      street: record.street,
      feePaid: record.feePaid,
    });
    setMaskMode(record.maskMode || 'seamless');
    setQrMode(record.qrMode || 'template');
    setEditingLicenseId(record.id);
    setActiveTab('editor');
    setNotice({
      type: 'ok',
      text: `Imefungua rekodi ${record.blNo}.`,
    });
  }, []);

  const handleDeleteRecord = useCallback(
    async (recordId: string) => {
      if (!firebaseUser) return;
      await deleteSavedLicense({ uid: firebaseUser.uid, licenseId: recordId });
      if (editingLicenseId === recordId) {
        setEditingLicenseId(null);
      }
    },
    [firebaseUser, editingLicenseId]
  );

  // Gate: require Google device verification + registration (3 names, phone, 4-digit PIN) + PIN unlock
  if (
    loadingAuth ||
    loadingProfile ||
    bootstrappingAdmin ||
    !firebaseUser ||
    !profile ||
    !pinUnlocked
  ) {
    return (
      <AuthGate
        firebaseUser={firebaseUser}
        profile={profile}
        loadingAuth={
          loadingAuth ||
          bootstrappingAdmin ||
          (Boolean(firebaseUser) && loadingProfile)
        }
        onGoogleSignIn={handleGoogleSignIn}
        onSignOut={handleSignOut}
        onPinUnlocked={handlePinUnlocked}
      />
    );
  }

  const canExportPng = isAdmin || Boolean(profile.services?.exportPng);
  const canPrintPdf = isAdmin || Boolean(profile.services?.printPdf);

  return (
    <div className="min-h-screen lg:h-screen flex flex-col bg-[#f4f6f8] text-slate-900 lg:overflow-hidden">
      {/* Top Workbench Header (3-zone contract) */}
      <header className="no-print h-14 px-4 sm:px-5 bg-white border-b border-slate-200 flex items-center justify-between gap-4 lg:gap-8 shrink-0">
        {/* Zone 1: Brand wordmark */}
        <h1 className="font-display text-sm sm:text-base font-semibold tracking-tight text-slate-900 whitespace-nowrap shrink-0">
          Tanzania Business License
        </h1>

        {/* Zone 2: Clean text navigation links (Desktop) */}
        <nav className="hidden md:flex items-center gap-6 text-sm font-medium">
          <button
            type="button"
            onClick={() => setActiveTab('editor')}
            className={`py-1 transition-colors whitespace-nowrap shrink-0 border-b-2 ${
              activeTab === 'editor'
                ? 'border-[#0f4c75] text-slate-900'
                : 'border-transparent text-slate-500 hover:text-slate-900'
            }`}
          >
            Mhariri wa Leseni
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('records')}
            className={`py-1 transition-colors whitespace-nowrap shrink-0 border-b-2 ${
              activeTab === 'records'
                ? 'border-[#0f4c75] text-slate-900'
                : 'border-transparent text-slate-500 hover:text-slate-900'
            }`}
          >
            Kumbukumbu ({savedLicenses.length})
          </button>
          {isAdmin && (
            <button
              type="button"
              onClick={() => setActiveTab('admin')}
              className={`py-1 transition-colors whitespace-nowrap shrink-0 border-b-2 ${
                activeTab === 'admin'
                  ? 'border-[#0f4c75] text-slate-900'
                  : 'border-transparent text-slate-500 hover:text-slate-900'
              }`}
            >
              Admin Control Panel
            </button>
          )}
        </nav>

        {/* Zone 3: Coin balance + Actions */}
        <div className="flex items-center gap-2 sm:gap-2.5 shrink-0">
          <div className="hidden md:flex items-center gap-1.5 px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-xs whitespace-nowrap shrink-0">
            <Coins className="w-3.5 h-3.5 text-amber-600" aria-hidden="true" />
            <span className="font-semibold font-mono-tabular text-slate-900">
              {profile.coins.toLocaleString()}
            </span>
            <span className="text-slate-500">Coins</span>
          </div>

          {activeTab === 'editor' && (
            <>
              <div
                className="hidden xl:flex items-center gap-0.5 p-1 bg-slate-100 rounded-lg"
                role="group"
                aria-label="Preview zoom level"
              >
                {ZOOM_OPTIONS.map((opt) => (
                  <button
                    key={opt.value}
                    type="button"
                    onClick={() => setZoomMode(opt.value)}
                    className={`px-2 py-1 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 tabular-nums ${
                      zoomMode === opt.value
                        ? 'bg-white text-slate-900 shadow-xs'
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    {opt.label}
                  </button>
                ))}
              </div>

              <button
                type="button"
                onClick={handlePrint}
                className={`hidden sm:inline-flex items-center gap-1.5 px-3 py-2 text-xs font-medium border rounded-lg transition-colors whitespace-nowrap shrink-0 ${
                  canPrintPdf
                    ? 'text-slate-700 bg-white border-slate-200 hover:bg-slate-50 hover:border-slate-300'
                    : 'text-slate-400 bg-slate-50 border-slate-200'
                }`}
              >
                {canPrintPdf ? (
                  <Printer className="w-3.5 h-3.5" aria-hidden="true" />
                ) : (
                  <Lock className="w-3.5 h-3.5" aria-hidden="true" />
                )}
                Print / PDF
              </button>

              <button
                type="button"
                onClick={handleExportPng}
                disabled={isExporting}
                className={`inline-flex items-center gap-1.5 px-3 sm:px-3.5 py-2 text-xs font-medium text-white rounded-lg transition-colors whitespace-nowrap shrink-0 ${
                  canExportPng
                    ? 'bg-[#0f4c75] hover:bg-[#0b3a5b] disabled:opacity-60'
                    : 'bg-slate-400 hover:bg-slate-500'
                }`}
              >
                {canExportPng ? (
                  <Download className="w-3.5 h-3.5" aria-hidden="true" />
                ) : (
                  <Lock className="w-3.5 h-3.5" aria-hidden="true" />
                )}
                {isExporting ? 'Exporting...' : 'Export PNG'}
              </button>
            </>
          )}

          <button
            type="button"
            onClick={handleLockSession}
            title="Funga kwa PIN"
            aria-label="Funga kwa PIN"
            className="p-2 text-slate-500 hover:text-slate-900 hover:bg-slate-100 rounded-lg transition-colors shrink-0"
          >
            <Lock className="w-4 h-4" aria-hidden="true" />
          </button>

          <button
            type="button"
            onClick={handleSignOut}
            title="Toka kwenye akaunti"
            aria-label="Toka kwenye akaunti"
            className="p-2 text-slate-500 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors shrink-0"
          >
            <LogOut className="w-4 h-4" aria-hidden="true" />
          </button>
        </div>
      </header>

      {/* Mobile Navigation & Coin Strip */}
      <div className="no-print flex md:hidden items-center justify-between gap-2 px-4 py-2 bg-white border-b border-slate-200 overflow-x-auto">
        <div className="flex items-center gap-4 text-xs font-medium">
          <button
            type="button"
            onClick={() => setActiveTab('editor')}
            className={`py-1 whitespace-nowrap shrink-0 border-b-2 ${
              activeTab === 'editor'
                ? 'border-[#0f4c75] text-slate-900'
                : 'border-transparent text-slate-500'
            }`}
          >
            Mhariri
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('records')}
            className={`py-1 whitespace-nowrap shrink-0 border-b-2 ${
              activeTab === 'records'
                ? 'border-[#0f4c75] text-slate-900'
                : 'border-transparent text-slate-500'
            }`}
          >
            Kumbukumbu ({savedLicenses.length})
          </button>
          {isAdmin && (
            <button
              type="button"
              onClick={() => setActiveTab('admin')}
              className={`py-1 whitespace-nowrap shrink-0 border-b-2 ${
                activeTab === 'admin'
                  ? 'border-[#0f4c75] text-slate-900'
                  : 'border-transparent text-slate-500'
              }`}
            >
              Admin
            </button>
          )}
        </div>
        <div className="flex items-center gap-2 shrink-0">
          {activeTab === 'editor' && (
            <button
              type="button"
              onClick={handlePrint}
              className="sm:hidden inline-flex items-center gap-1 px-2.5 py-1 text-xs font-medium text-slate-700 border border-slate-200 rounded-md whitespace-nowrap"
            >
              <Printer className="w-3 h-3" aria-hidden="true" />
              Print
            </button>
          )}
          <div className="flex items-center gap-1 px-2.5 py-1 bg-slate-50 border border-slate-200 rounded-md text-xs whitespace-nowrap">
            <Coins className="w-3 h-3 text-amber-600" aria-hidden="true" />
            <span className="font-semibold font-mono-tabular text-slate-900">
              {profile.coins.toLocaleString()}
            </span>
          </div>
        </div>
      </div>

      {/* Notice Banner */}
      {notice && (
        <div
          role="status"
          className={`no-print px-5 py-2 text-xs font-medium flex items-center justify-between border-b ${
            notice.type === 'ok'
              ? 'bg-emerald-50 border-emerald-200 text-emerald-800'
              : 'bg-red-50 border-red-200 text-red-700'
          }`}
        >
          <span>{notice.text}</span>
          <button
            type="button"
            onClick={() => setNotice(null)}
            className="underline ml-4 whitespace-nowrap"
          >
            Funga
          </button>
        </div>
      )}

      {/* Active Workspace View */}
      {activeTab === 'admin' && isAdmin ? (
        <AdminControlPanel
          currentAdminUid={firebaseUser.uid}
          coinCosts={coinCosts}
        />
      ) : activeTab === 'records' ? (
        <SavedRecordsPanel
          profile={profile}
          records={savedLicenses}
          transactions={transactions}
          onLoadRecord={handleLoadRecord}
          onDeleteRecord={handleDeleteRecord}
        />
      ) : (
        <div className="flex-1 flex flex-col lg:flex-row min-h-0">
          <LicenseFormSidebar
            data={data}
            profile={profile}
            isAdmin={isAdmin}
            coinCosts={coinCosts}
            activeField={activeField}
            maskMode={maskMode}
            qrMode={qrMode}
            editingLicenseId={editingLicenseId}
            isSavingRecord={isSavingRecord}
            onChangeField={handleChangeField}
            onFocusField={setActiveField}
            onChangeMaskMode={setMaskMode}
            onRequestQrMode={handleRequestQrMode}
            onSaveToCloud={handleSaveToCloud}
            onResetDefaults={handleResetDefaults}
            onClearFields={handleClearFields}
            registerInputRef={registerInputRef}
          />

          <LicensePreviewCanvas
            data={data}
            cleanedTemplateUrl={cleanedTemplateUrl}
            maskMode={maskMode}
            qrMode={qrMode}
            qrDataUrl={qrDataUrl}
            zoomMode={zoomMode}
            activeField={activeField}
            onSelectField={handleSelectFieldOnPreview}
          />
        </div>
      )}
    </div>
  );
}
