import React, { useEffect, useRef, useState } from 'react';
import {
  FIELD_OVERLAYS,
  LicenseData,
  LicenseFieldKey,
  MaskMode,
  QR_BOX,
  QrMode,
  TEMPLATE_HEIGHT,
  TEMPLATE_IMAGE_PATH,
  TEMPLATE_WIDTH,
} from '../types/license';

interface LicensePreviewCanvasProps {
  data: LicenseData;
  cleanedTemplateUrl: string | null;
  maskMode: MaskMode;
  qrMode: QrMode;
  qrDataUrl: string | null;
  zoomMode: 'fit' | '75' | '100' | '125';
  activeField: LicenseFieldKey | null;
  onSelectField: (key: LicenseFieldKey) => void;
}

export const LicensePreviewCanvas: React.FC<LicensePreviewCanvasProps> = ({
  data,
  cleanedTemplateUrl,
  maskMode,
  qrMode,
  qrDataUrl,
  zoomMode,
  activeField,
  onSelectField,
}) => {
  const stageRef = useRef<HTMLDivElement | null>(null);
  const [fitWidth, setFitWidth] = useState<number>(680);
  const [imageError, setImageError] = useState(false);

  useEffect(() => {
    const updateFitWidth = () => {
      if (!stageRef.current) return;
      const rect = stageRef.current.getBoundingClientRect();
      // Leave comfortable drafting margins around the A4 document
      const availW = Math.max(280, rect.width - 64);
      const availH = Math.max(380, rect.height - 64);
      const widthByHeight = availH * (TEMPLATE_WIDTH / TEMPLATE_HEIGHT);
      const computed = Math.min(availW, widthByHeight, 760);
      setFitWidth(Math.round(computed));
    };

    updateFitWidth();
    const observer = new ResizeObserver(updateFitWidth);
    if (stageRef.current) {
      observer.observe(stageRef.current);
    }
    window.addEventListener('resize', updateFitWidth);
    return () => {
      observer.disconnect();
      window.removeEventListener('resize', updateFitWidth);
    };
  }, []);

  const displayWidth =
    zoomMode === 'fit'
      ? fitWidth
      : Math.round(TEMPLATE_WIDTH * (Number(zoomMode) / 100));

  const backgroundSrc =
    maskMode === 'seamless' && cleanedTemplateUrl
      ? cleanedTemplateUrl
      : TEMPLATE_IMAGE_PATH;

  return (
    <main
      ref={stageRef}
      className="print-stage flex-1 overflow-auto bg-[#e6eaf0] p-6 lg:p-8 flex justify-center items-start min-h-[540px]"
    >
      <div
        className="print-doc-frame relative bg-white shadow-[0_18px_45px_rgba(15,23,42,0.16)] border border-slate-300/70 shrink-0 select-none"
        style={{
          width: `${displayWidth}px`,
          aspectRatio: `${TEMPLATE_WIDTH} / ${TEMPLATE_HEIGHT}`,
          containerType: 'inline-size',
        }}
      >
        {!imageError ? (
          <img
            src={backgroundSrc}
            alt="United Republic of Tanzania Business License Template"
            referrerPolicy="no-referrer"
            onError={() => setImageError(true)}
            className="block w-full h-full object-cover pointer-events-none"
          />
        ) : (
          <div className="w-full h-full flex flex-col items-center justify-center bg-slate-50 text-slate-500 p-8 text-center">
            <p className="text-sm font-medium text-slate-700">
              Template background could not be loaded
            </p>
            <p className="text-xs text-slate-500 mt-1">
              Verify the template asset exists in public/assets/aistudio.
            </p>
          </div>
        )}

        {/* Dynamic Field Overlays */}
        {FIELD_OVERLAYS.map((field) => {
          const isActive = activeField === field.key;
          const rawValue = data[field.key] ?? '';
          const displayText =
            field.key === 'blNo'
              ? `B.L. NO : ${rawValue}`
              : field.key === 'licensee'
                ? rawValue.toUpperCase()
                : rawValue;

          const topPct = (field.y / TEMPLATE_HEIGHT) * 100;
          const leftPct = (field.x / TEMPLATE_WIDTH) * 100;
          const widthPct = (field.w / TEMPLATE_WIDTH) * 100;
          const heightPct = (field.h / TEMPLATE_HEIGHT) * 100;
          const fontSizeCqw = (field.fontSizePx / TEMPLATE_WIDTH) * 100;

          return (
            <button
              key={field.key}
              type="button"
              onClick={() => onSelectField(field.key)}
              title={`Edit ${field.label}`}
              className={`license-doc-font absolute z-10 flex items-center whitespace-nowrap overflow-hidden text-ellipsis cursor-text transition-shadow focus:outline-none ${
                field.align === 'center'
                  ? 'justify-center text-center'
                  : 'justify-start text-left'
              } ${
                isActive
                  ? 'ring-2 ring-[#0f4c75]/50 rounded-[2px] bg-[#0f4c75]/5'
                  : 'hover:ring-1 hover:ring-[#0f4c75]/30 rounded-[2px]'
              }`}
              style={{
                top: `${topPct}%`,
                left: `${leftPct}%`,
                width: `${widthPct}%`,
                height: `${heightPct}%`,
                fontSize: `${fontSizeCqw}cqw`,
                fontWeight: field.fontWeight,
                color: field.color,
                lineHeight: 1.15,
                backgroundColor:
                  maskMode === 'opaque'
                    ? '#f5fcfd'
                    : isActive
                      ? 'rgba(15, 76, 117, 0.05)'
                      : 'transparent',
              }}
            >
              {displayText}
            </button>
          );
        })}

        {/* Optional Live Dynamic QR Code Overlay */}
        {qrMode === 'live' && qrDataUrl && (
          <div
            className="absolute z-10 bg-white flex items-center justify-center p-[0.5%]"
            style={{
              top: `${(QR_BOX.y / TEMPLATE_HEIGHT) * 100}%`,
              left: `${(QR_BOX.x / TEMPLATE_WIDTH) * 100}%`,
              width: `${(QR_BOX.w / TEMPLATE_WIDTH) * 100}%`,
              height: `${(QR_BOX.h / TEMPLATE_HEIGHT) * 100}%`,
            }}
          >
            <img
              src={qrDataUrl}
              alt={`Verification QR code for ${data.blNo}`}
              className="w-full h-full object-contain [image-rendering:pixelated]"
            />
          </div>
        )}
      </div>
    </main>
  );
};
