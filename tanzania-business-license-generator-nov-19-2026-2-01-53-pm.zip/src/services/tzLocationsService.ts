export type RegionSlug =
  | 'arusha'
  | 'dar-es-salaam'
  | 'dodoma'
  | 'geita'
  | 'iringa'
  | 'kagera'
  | 'kaskazini-pemba'
  | 'kaskazini-unguja'
  | 'katavi'
  | 'kigoma'
  | 'kilimanjaro'
  | 'kusini-pemba'
  | 'kusini-unguja'
  | 'lindi'
  | 'manyara'
  | 'mara'
  | 'mbeya'
  | 'mjini-magharibi'
  | 'morogoro'
  | 'mtwara'
  | 'mwanza'
  | 'njombe'
  | 'pwani'
  | 'rukwa'
  | 'ruvuma'
  | 'shinyanga'
  | 'simiyu'
  | 'singida'
  | 'songwe'
  | 'tabora'
  | 'tanga';

export interface RegionInfo {
  slug: RegionSlug;
  name: string;
  upperName: string;
}

export const TANZANIA_REGIONS: RegionInfo[] = [
  { slug: 'arusha', name: 'Arusha', upperName: 'ARUSHA' },
  { slug: 'dar-es-salaam', name: 'Dar es Salaam', upperName: 'DAR ES SALAAM' },
  { slug: 'dodoma', name: 'Dodoma', upperName: 'DODOMA' },
  { slug: 'geita', name: 'Geita', upperName: 'GEITA' },
  { slug: 'iringa', name: 'Iringa', upperName: 'IRINGA' },
  { slug: 'kagera', name: 'Kagera', upperName: 'KAGERA' },
  { slug: 'kaskazini-pemba', name: 'Kaskazini Pemba', upperName: 'KASKAZINI PEMBA' },
  { slug: 'kaskazini-unguja', name: 'Kaskazini Unguja', upperName: 'KASKAZINI UNGUJA' },
  { slug: 'katavi', name: 'Katavi', upperName: 'KATAVI' },
  { slug: 'kigoma', name: 'Kigoma', upperName: 'KIGOMA' },
  { slug: 'kilimanjaro', name: 'Kilimanjaro', upperName: 'KILIMANJARO' },
  { slug: 'kusini-pemba', name: 'Kusini Pemba', upperName: 'KUSINI PEMBA' },
  { slug: 'kusini-unguja', name: 'Kusini Unguja', upperName: 'KUSINI UNGUJA' },
  { slug: 'lindi', name: 'Lindi', upperName: 'LINDI' },
  { slug: 'manyara', name: 'Manyara', upperName: 'MANYARA' },
  { slug: 'mara', name: 'Mara', upperName: 'MARA' },
  { slug: 'mbeya', name: 'Mbeya', upperName: 'MBEYA' },
  { slug: 'mjini-magharibi', name: 'Mjini Magharibi', upperName: 'MJINI MAGHARIBI' },
  { slug: 'morogoro', name: 'Morogoro', upperName: 'MOROGORO' },
  { slug: 'mtwara', name: 'Mtwara', upperName: 'MTWARA' },
  { slug: 'mwanza', name: 'Mwanza', upperName: 'MWANZA' },
  { slug: 'njombe', name: 'Njombe', upperName: 'NJOMBE' },
  { slug: 'pwani', name: 'Pwani', upperName: 'PWANI' },
  { slug: 'rukwa', name: 'Rukwa', upperName: 'RUKWA' },
  { slug: 'ruvuma', name: 'Ruvuma', upperName: 'RUVUMA' },
  { slug: 'shinyanga', name: 'Shinyanga', upperName: 'SHINYANGA' },
  { slug: 'simiyu', name: 'Simiyu', upperName: 'SIMIYU' },
  { slug: 'singida', name: 'Singida', upperName: 'SINGIDA' },
  { slug: 'songwe', name: 'Songwe', upperName: 'SONGWE' },
  { slug: 'tabora', name: 'Tabora', upperName: 'TABORA' },
  { slug: 'tanga', name: 'Tanga', upperName: 'TANGA' },
];

interface RawStreetEntry {
  NAME?: string;
  PLACES?: string[];
}

interface RawWardEntry {
  NAME?: string;
  POSTCODE?: number;
  STREETS?: RawStreetEntry[];
}

interface RawDistrictEntry {
  NAME?: string;
  POSTCODE?: number;
  WARD?: RawWardEntry[];
}

interface RawRegionFileEntry {
  REGION?: string;
  POSTCODE?: number;
  DISTRIC?: RawDistrictEntry[];
}

export interface WardHierarchy {
  name: string;
  postcode?: number;
  /** Combined deduplicated streets, villages, and places inside this ward */
  streetsAndVillages: string[];
  /** Primary street/village names */
  streetsOnly: string[];
}

export interface DistrictHierarchy {
  name: string;
  postcode?: number;
  wards: WardHierarchy[];
}

export interface RegionHierarchy {
  slug: RegionSlug;
  regionName: string;
  districts: DistrictHierarchy[];
}

function cleanLabel(raw: string | undefined | null): string {
  if (!raw) return '';
  return raw.replace(/\s+/g, ' ').trim();
}

export function toTitleCase(value: string): string {
  return value
    .toLowerCase()
    .replace(/\b([a-z])/g, (m) => m.toUpperCase());
}

const TRA_ALIAS_TO_REGION_SLUGS: Record<string, { slugs: RegionSlug[]; defaultDistrict?: string }> = {
  ILALA: { slugs: ['dar-es-salaam'], defaultDistrict: 'ILALA' },
  KARIAKOO: { slugs: ['dar-es-salaam'], defaultDistrict: 'ILALA CBD' },
  KINONDONI: { slugs: ['dar-es-salaam'], defaultDistrict: 'KINONDONI' },
  TEMEKE: { slugs: ['dar-es-salaam'], defaultDistrict: 'TEMEKE' },
  UBUNGO: { slugs: ['dar-es-salaam'], defaultDistrict: 'UBUNGO' },
  KIGAMBONI: { slugs: ['dar-es-salaam'], defaultDistrict: 'KIGAMBONI' },
  TEGETA: { slugs: ['dar-es-salaam'], defaultDistrict: 'KINONDONI' },
  'DAR ES SALAAM': { slugs: ['dar-es-salaam'] },
  ZANZIBAR: {
    slugs: ['mjini-magharibi', 'kaskazini-unguja', 'kusini-unguja'],
  },
  PEMBA: { slugs: ['kaskazini-pemba', 'kusini-pemba'] },
};

export function resolveRegionFromInput(input: string): {
  slugs: RegionSlug[];
  defaultDistrict?: string;
} | null {
  const norm = cleanLabel(input).toUpperCase();
  if (!norm) return null;

  if (TRA_ALIAS_TO_REGION_SLUGS[norm]) {
    return TRA_ALIAS_TO_REGION_SLUGS[norm];
  }

  const exact = TANZANIA_REGIONS.find(
    (r) =>
      r.upperName === norm ||
      r.slug.toUpperCase() === norm ||
      r.name.toUpperCase() === norm
  );
  if (exact) {
    return { slugs: [exact.slug] };
  }

  const partial = TANZANIA_REGIONS.find(
    (r) => norm.includes(r.upperName) || r.upperName.includes(norm)
  );
  if (partial) {
    return { slugs: [partial.slug] };
  }

  return null;
}

const REGION_LOADERS: Record<
  RegionSlug,
  () => Promise<{ default: RawRegionFileEntry[] }>
> = {
  arusha: () => import('tz-geo-data/regions/arusha.json'),
  'dar-es-salaam': () => import('tz-geo-data/regions/dar-es-salaam.json'),
  dodoma: () => import('tz-geo-data/regions/dodoma.json'),
  geita: () => import('tz-geo-data/regions/geita.json'),
  iringa: () => import('tz-geo-data/regions/iringa.json'),
  kagera: () => import('tz-geo-data/regions/kagera.json'),
  'kaskazini-pemba': () => import('tz-geo-data/regions/kaskazini-pemba.json'),
  'kaskazini-unguja': () => import('tz-geo-data/regions/kaskazini-unguja.json'),
  katavi: () => import('tz-geo-data/regions/katavi.json'),
  kigoma: () => import('tz-geo-data/regions/kigoma.json'),
  kilimanjaro: () => import('tz-geo-data/regions/kilimanjaro.json'),
  'kusini-pemba': () => import('tz-geo-data/regions/kusini-pemba.json'),
  'kusini-unguja': () => import('tz-geo-data/regions/kusini-unguja.json'),
  lindi: () => import('tz-geo-data/regions/lindi.json'),
  manyara: () => import('tz-geo-data/regions/manyara.json'),
  mara: () => import('tz-geo-data/regions/mara.json'),
  mbeya: () => import('tz-geo-data/regions/mbeya.json'),
  'mjini-magharibi': () => import('tz-geo-data/regions/mjini-magharibi.json'),
  morogoro: () => import('tz-geo-data/regions/morogoro.json'),
  mtwara: () => import('tz-geo-data/regions/mtwara.json'),
  mwanza: () => import('tz-geo-data/regions/mwanza.json'),
  njombe: () => import('tz-geo-data/regions/njombe.json'),
  pwani: () => import('tz-geo-data/regions/pwani.json'),
  rukwa: () => import('tz-geo-data/regions/rukwa.json'),
  ruvuma: () => import('tz-geo-data/regions/ruvuma.json'),
  shinyanga: () => import('tz-geo-data/regions/shinyanga.json'),
  simiyu: () => import('tz-geo-data/regions/simiyu.json'),
  singida: () => import('tz-geo-data/regions/singida.json'),
  songwe: () => import('tz-geo-data/regions/songwe.json'),
  tabora: () => import('tz-geo-data/regions/tabora.json'),
  tanga: () => import('tz-geo-data/regions/tanga.json'),
};

const regionCache = new Map<RegionSlug, RegionHierarchy>();

function parseRegionPayload(
  slug: RegionSlug,
  rawList: RawRegionFileEntry[]
): RegionHierarchy {
  const entry = rawList[0] || {};
  const regionMeta = TANZANIA_REGIONS.find((r) => r.slug === slug);
  const regionName = cleanLabel(entry.REGION) || regionMeta?.upperName || slug.toUpperCase();

  const districtMap = new Map<string, DistrictHierarchy>();

  for (const rawDist of entry.DISTRIC || []) {
    const distName = cleanLabel(rawDist.NAME).toUpperCase();
    if (!distName) continue;

    let dist = districtMap.get(distName);
    if (!dist) {
      dist = {
        name: distName,
        postcode: rawDist.POSTCODE,
        wards: [],
      };
      districtMap.set(distName, dist);
    }

    const wardMap = new Map<string, Set<string>>();
    const wardStreetOnlyMap = new Map<string, Set<string>>();
    const wardPostcodeMap = new Map<string, number | undefined>();

    for (const existing of dist.wards) {
      wardMap.set(existing.name, new Set(existing.streetsAndVillages));
      wardStreetOnlyMap.set(existing.name, new Set(existing.streetsOnly));
      wardPostcodeMap.set(existing.name, existing.postcode);
    }

    for (const rawWard of rawDist.WARD || []) {
      const wardName = cleanLabel(rawWard.NAME).toUpperCase();
      if (!wardName) continue;

      if (!wardMap.has(wardName)) {
        wardMap.set(wardName, new Set());
        wardStreetOnlyMap.set(wardName, new Set());
        wardPostcodeMap.set(wardName, rawWard.POSTCODE);
      }

      const allPlacesSet = wardMap.get(wardName)!;
      const streetsOnlySet = wardStreetOnlyMap.get(wardName)!;

      for (const rawStreet of rawWard.STREETS || []) {
        const streetName = cleanLabel(rawStreet.NAME).toUpperCase();
        if (streetName) {
          allPlacesSet.add(streetName);
          streetsOnlySet.add(streetName);
        }
        for (const rawPlace of rawStreet.PLACES || []) {
          const placeName = cleanLabel(rawPlace).toUpperCase();
          if (placeName) {
            allPlacesSet.add(placeName);
          }
        }
      }
    }

    dist.wards = Array.from(wardMap.entries())
      .map(([wName, allSet]) => ({
        name: wName,
        postcode: wardPostcodeMap.get(wName),
        streetsAndVillages: Array.from(allSet).sort((a, b) =>
          a.localeCompare(b)
        ),
        streetsOnly: Array.from(wardStreetOnlyMap.get(wName) || []).sort(
          (a, b) => a.localeCompare(b)
        ),
      }))
      .sort((a, b) => a.name.localeCompare(b.name));
  }

  return {
    slug,
    regionName,
    districts: Array.from(districtMap.values()).sort((a, b) =>
      a.name.localeCompare(b.name)
    ),
  };
}

export async function loadRegionHierarchy(
  slug: RegionSlug
): Promise<RegionHierarchy> {
  const cached = regionCache.get(slug);
  if (cached) return cached;

  const loader = REGION_LOADERS[slug];
  const mod = await loader();
  const parsed = parseRegionPayload(slug, mod.default || []);
  regionCache.set(slug, parsed);
  return parsed;
}

export async function loadCombinedRegionHierarchy(
  slugs: RegionSlug[]
): Promise<RegionHierarchy | null> {
  if (slugs.length === 0) return null;
  if (slugs.length === 1) return loadRegionHierarchy(slugs[0]);

  const loaded = await Promise.all(slugs.map((s) => loadRegionHierarchy(s)));
  return {
    slug: loaded[0].slug,
    regionName: loaded.map((r) => r.regionName).join(' / '),
    districts: loaded.flatMap((r) => r.districts),
  };
}
