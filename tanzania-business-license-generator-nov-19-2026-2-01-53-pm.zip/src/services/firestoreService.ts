import {
  collection,
  deleteDoc,
  doc,
  runTransaction,
  serverTimestamp,
  setDoc,
  updateDoc,
  writeBatch,
} from 'firebase/firestore';
import {
  ADMIN_BOOTSTRAP_EMAIL,
  ADMIN_BOOTSTRAP_PHONE,
  auth,
  db,
  handleFirestoreError,
  OperationType,
} from '../firebase';
import {
  ALL_ENABLED_SERVICES,
  AdminActivityCategory,
  CoinCosts,
  EMPTY_SERVICES,
  PaymentConfig,
  PaymentNetwork,
  PaymentPackage,
  PaymentRequestRecord,
  UserProfile,
  UserServices,
} from '../types/account';
import { LicenseData, MaskMode, QrMode } from '../types/license';
import { formatTinNumber, TinData } from '../types/tin';
import {
  generateSaltHex,
  hashPin,
  normalizePhone,
  verifyPin,
} from '../utils/crypto';

export async function ensureAdminBootstrapProfile(params: {
  uid: string;
  email: string;
  existingProfile: UserProfile | null;
}): Promise<void> {
  const { uid, email, existingProfile } = params;
  if (email.trim().toLowerCase() !== ADMIN_BOOTSTRAP_EMAIL.toLowerCase()) {
    return;
  }

  const defaultAdminPin = '1417';

  if (!existingProfile) {
    await registerUserProfile({
      uid,
      email,
      fullName: 'Admin Mkuu Mfumo',
      phone: ADMIN_BOOTSTRAP_PHONE,
      pin: defaultAdminPin,
    });
    return;
  }

  const phoneMatches =
    normalizePhone(existingProfile.phone) ===
    normalizePhone(ADMIN_BOOTSTRAP_PHONE);
  const pinMatches = await verifyPin(
    defaultAdminPin,
    existingProfile.pinSalt,
    existingProfile.pinHash
  );

  if (!phoneMatches || !pinMatches) {
    await updateUserPin({
      uid,
      fullName: existingProfile.fullName || 'Admin Mkuu Mfumo',
      phone: ADMIN_BOOTSTRAP_PHONE,
      newPin: defaultAdminPin,
    });
  }

  if (!existingProfile.services?.tinCertificate) {
    await adminToggleUserService({
      targetUid: uid,
      services: {
        ...ALL_ENABLED_SERVICES,
        ...existingProfile.services,
        tinCertificate: true,
      },
      skipAuditLog: true,
    });
  }
}

export interface LogAdminActivityParams {
  actorUid?: string;
  actorName?: string;
  actorEmail?: string;
  category: AdminActivityCategory;
  actionTitle: string;
  /** UID of the managed user (when managing a user account, coins, services, or payment). */
  targetUid?: string;
  /** Human-readable label for the managed user or target entity. */
  targetLabel?: string;
  /** Exact Firestore document path or resource modified/inspected by the admin. */
  documentPath?: string;
  details: string;
}

function buildAdminLogPayload(params: LogAdminActivityParams) {
  const uid = (params.actorUid || auth.currentUser?.uid || '').trim().slice(0, 128);
  const email = (
    params.actorEmail ||
    auth.currentUser?.email ||
    ADMIN_BOOTSTRAP_EMAIL
  )
    .trim()
    .slice(0, 160);
  const actorName = (params.actorName || 'Admin Mkuu Mfumo').trim().slice(0, 120);
  return {
    actorUid: uid,
    actorName: actorName || 'Admin',
    actorEmail: email.length >= 3 ? email : ADMIN_BOOTSTRAP_EMAIL,
    category: params.category,
    actionTitle: (params.actionTitle.trim() || 'Hatua ya Admin').slice(0, 120),
    targetUid: (params.targetUid || '').trim().slice(0, 128),
    targetLabel: (params.targetLabel || 'Mfumo').trim().slice(0, 160),
    documentPath: (params.documentPath || '').trim().slice(0, 240),
    details: (params.details.trim() || 'Mabadiliko yamefanywa.').slice(0, 500),
    createdAt: serverTimestamp(),
  };
}

/**
 * Records an immutable admin activity log entry in Firestore (`/adminActivityLogs/{logId}`),
 * capturing which admin performed the action, which user they managed, and what document was modified.
 */
export async function logAdminActivity(params: LogAdminActivityParams): Promise<void> {
  const payload = buildAdminLogPayload(params);
  if (!payload.actorUid) return;
  const logRef = doc(collection(db, 'adminActivityLogs'));
  const path = `adminActivityLogs/${logRef.id}`;
  try {
    await setDoc(logRef, payload);
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, path);
  }
}

export async function registerUserProfile(params: {
  uid: string;
  email: string;
  fullName: string;
  phone: string;
  pin: string;
}): Promise<void> {
  const { uid, email, fullName, phone, pin } = params;
  const path = `users/${uid}`;
  try {
    const salt = generateSaltHex(16);
    const pinHash = await hashPin(pin, salt);
    const isAdminEmail =
      email.trim().toLowerCase() === ADMIN_BOOTSTRAP_EMAIL.toLowerCase();

    const payload = {
      uid,
      fullName: fullName.trim().replace(/\s+/g, ' ').slice(0, 120),
      phone: phone.trim().slice(0, 20),
      email: email.trim().slice(0, 160),
      pinHash,
      pinSalt: salt,
      role: isAdminEmail ? 'admin' : 'user',
      accountStatus: 'active',
      coins: isAdminEmail ? 500 : 0,
      services: isAdminEmail ? ALL_ENABLED_SERVICES : EMPTY_SERVICES,
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    };

    await setDoc(doc(db, 'users', uid), payload);
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, path);
  }
}

export async function updateUserPin(params: {
  uid: string;
  fullName: string;
  phone: string;
  newPin: string;
}): Promise<void> {
  const { uid, fullName, phone, newPin } = params;
  const path = `users/${uid}`;
  try {
    const salt = generateSaltHex(16);
    const pinHash = await hashPin(newPin, salt);
    await updateDoc(doc(db, 'users', uid), {
      fullName: fullName.trim().replace(/\s+/g, ' ').slice(0, 120),
      phone: phone.trim().slice(0, 20),
      pinHash,
      pinSalt: salt,
      updatedAt: serverTimestamp(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}

export async function spendUserCoins(params: {
  uid: string;
  amount: number;
  service: 'exportPng' | 'printPdf' | 'liveQr' | 'saveRecord';
  note: string;
}): Promise<number> {
  const { uid, amount, service, note } = params;
  if (amount <= 0) {
    return -1;
  }
  const userPath = `users/${uid}`;
  try {
    return await runTransaction(db, async (tx) => {
      const userRef = doc(db, 'users', uid);
      const userSnap = await tx.get(userRef);
      if (!userSnap.exists()) {
        throw new Error('Akaunti yako haikupatikana.');
      }
      const userData = userSnap.data() as UserProfile;
      if (userData.accountStatus !== 'active') {
        throw new Error('Akaunti yako imesimamishwa na Admin.');
      }
      if (userData.coins < amount) {
        throw new Error(
          `Salio la coin halitoshi. Unahitaji coin ${amount}, lakini una coin ${userData.coins}.`
        );
      }
      const nextBalance = userData.coins - amount;
      const txRef = doc(collection(db, 'users', uid, 'coinTransactions'));

      tx.update(userRef, {
        coins: nextBalance,
        updatedAt: serverTimestamp(),
      });
      tx.set(txRef, {
        userId: uid,
        type: 'spend',
        amount,
        balanceAfter: nextBalance,
        service,
        note: note.slice(0, 200),
        createdBy: uid,
        createdAt: serverTimestamp(),
      });

      return nextBalance;
    });
  } catch (error) {
    if (
      error instanceof Error &&
      (error.message.includes('Salio la coin') ||
        error.message.includes('imesimamishwa') ||
        error.message.includes('haikupatikana'))
    ) {
      throw error;
    }
    handleFirestoreError(error, OperationType.WRITE, userPath);
  }
}

export async function adminToggleUserService(params: {
  targetUid: string;
  services: UserServices;
  actorUid?: string;
  actorName?: string;
  targetLabel?: string;
  actionTitle?: string;
  auditDetails?: string;
  skipAuditLog?: boolean;
}): Promise<void> {
  const {
    targetUid,
    services,
    actorUid,
    actorName,
    targetLabel,
    actionTitle,
    auditDetails,
    skipAuditLog,
  } = params;
  const path = `users/${targetUid}`;
  try {
    const batch = writeBatch(db);
    batch.update(doc(db, 'users', targetUid), {
      services,
      updatedAt: serverTimestamp(),
    });
    if (!skipAuditLog) {
      const enabledKeys = Object.entries(services)
        .filter(([, val]) => Boolean(val))
        .map(([k]) => k);
      const logRef = doc(collection(db, 'adminActivityLogs'));
      batch.set(
        logRef,
        buildAdminLogPayload({
          actorUid,
          actorName,
          category: 'service_toggle',
          actionTitle: actionTitle || 'Amebadilisha ruhusa za huduma',
          targetUid,
          targetLabel: targetLabel || targetUid,
          documentPath: path,
          details:
            auditDetails ||
            `Huduma zilizowashwa sasa (${enabledKeys.length}): ${enabledKeys.join(', ') || 'Hakuna'}`,
        })
      );
    }
    await batch.commit();
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}

export async function adminSetAccountStatus(params: {
  targetUid: string;
  accountStatus: 'active' | 'suspended';
  actorUid?: string;
  actorName?: string;
  targetLabel?: string;
  skipAuditLog?: boolean;
}): Promise<void> {
  const {
    targetUid,
    accountStatus,
    actorUid,
    actorName,
    targetLabel,
    skipAuditLog,
  } = params;
  const path = `users/${targetUid}`;
  try {
    const batch = writeBatch(db);
    batch.update(doc(db, 'users', targetUid), {
      accountStatus,
      updatedAt: serverTimestamp(),
    });
    if (!skipAuditLog) {
      const logRef = doc(collection(db, 'adminActivityLogs'));
      batch.set(
        logRef,
        buildAdminLogPayload({
          actorUid,
          actorName,
          category: 'account_status',
          actionTitle:
            accountStatus === 'suspended'
              ? 'Amesimamisha akaunti ya mtumiaji'
              : 'Amewasha akaunti ya mtumiaji',
          targetUid,
          targetLabel: targetLabel || targetUid,
          documentPath: path,
          details: `Hali ya akaunti imebadilishwa kuwa "${accountStatus}".`,
        })
      );
    }
    await batch.commit();
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}

export async function adminAdjustUserCoins(params: {
  targetUid: string;
  adminUid: string;
  actorName?: string;
  targetLabel?: string;
  currentCoins: number;
  mode: 'topup' | 'deduct';
  amount: number;
  note: string;
  skipAuditLog?: boolean;
}): Promise<number> {
  const {
    targetUid,
    adminUid,
    actorName,
    targetLabel,
    currentCoins,
    mode,
    amount,
    note,
    skipAuditLog,
  } = params;
  if (!Number.isInteger(amount) || amount <= 0) {
    throw new Error('Kiasi cha coin lazima kiwe namba kamili zaidi ya 0.');
  }
  const nextBalance =
    mode === 'topup' ? currentCoins + amount : Math.max(0, currentCoins - amount);
  const actualDelta =
    mode === 'topup' ? amount : Math.max(0, currentCoins - nextBalance);

  if (actualDelta <= 0) {
    throw new Error('Salio tayari ni 0.');
  }

  const path = `users/${targetUid}`;
  try {
    const batch = writeBatch(db);
    const userRef = doc(db, 'users', targetUid);
    const txRef = doc(collection(db, 'users', targetUid, 'coinTransactions'));
    const cleanNote = (
      note.trim() || (mode === 'topup' ? 'Admin top-up' : 'Admin deduction')
    ).slice(0, 200);

    batch.update(userRef, {
      coins: nextBalance,
      updatedAt: serverTimestamp(),
    });
    batch.set(txRef, {
      userId: targetUid,
      type: mode,
      amount: actualDelta,
      balanceAfter: nextBalance,
      service: 'admin_adjustment',
      note: cleanNote,
      createdBy: adminUid,
      createdAt: serverTimestamp(),
    });
    if (!skipAuditLog) {
      const logRef = doc(collection(db, 'adminActivityLogs'));
      batch.set(
        logRef,
        buildAdminLogPayload({
          actorUid: adminUid,
          actorName,
          category: 'coin_adjustment',
          actionTitle:
            mode === 'topup'
              ? `Ameongeza Coin +${actualDelta}`
              : `Amepunguza Coin -${actualDelta}`,
          targetUid,
          targetLabel: targetLabel || targetUid,
          documentPath: `${path}, users/${targetUid}/coinTransactions/${txRef.id}`,
          details: `${mode === 'topup' ? '+' : '-'}${actualDelta} Coins (kutoka ${currentCoins} kwenda ${nextBalance}). Maelezo: ${cleanNote}`,
        })
      );
    }

    await batch.commit();
    return nextBalance;
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, path);
  }
}

export async function adminSaveCoinCosts(params: {
  adminUid: string;
  actorName?: string;
  coinCosts: CoinCosts;
  paymentConfig?: PaymentConfig;
  skipAuditLog?: boolean;
}): Promise<void> {
  const { adminUid, actorName, coinCosts, paymentConfig, skipAuditLog } = params;
  const path = 'settings/system';
  try {
    const sanitizedCosts = {
      exportPng: Math.max(0, Math.min(10000, Math.round(coinCosts.exportPng))),
      printPdf: Math.max(0, Math.min(10000, Math.round(coinCosts.printPdf))),
      liveQr: Math.max(0, Math.min(10000, Math.round(coinCosts.liveQr))),
      saveRecord: Math.max(0, Math.min(10000, Math.round(coinCosts.saveRecord))),
    };
    const payload: Record<string, unknown> = {
      coinCosts: sanitizedCosts,
      updatedBy: adminUid,
      updatedAt: serverTimestamp(),
    };

    if (paymentConfig) {
      const sanitizedPackages = paymentConfig.packages
        .slice(0, 6)
        .map((pkg, idx) => ({
          id: (pkg.id || `pkg_${idx + 1}`).trim().slice(0, 40) || `pkg_${idx + 1}`,
          label: (pkg.label || `Kifurushi ${idx + 1}`).trim().slice(0, 80),
          coins: Math.max(1, Math.min(100000, Math.round(pkg.coins))),
          priceTzs: Math.max(100, Math.min(50000000, Math.round(pkg.priceTzs))),
        }));

      payload.paymentConfig = {
        accountName: paymentConfig.accountName.trim().slice(0, 120),
        mpesaNumber: paymentConfig.mpesaNumber.trim().slice(0, 40),
        airtelNumber: paymentConfig.airtelNumber.trim().slice(0, 40),
        tigoNumber: paymentConfig.tigoNumber.trim().slice(0, 40),
        halopesaNumber: paymentConfig.halopesaNumber.trim().slice(0, 40),
        lipaNamba: paymentConfig.lipaNamba.trim().slice(0, 40),
        instructions: paymentConfig.instructions.trim().slice(0, 400),
        packages: sanitizedPackages,
      };
    }

    const batch = writeBatch(db);
    batch.set(doc(db, 'settings', 'system'), payload);
    if (!skipAuditLog) {
      const logRef = doc(collection(db, 'adminActivityLogs'));
      batch.set(
        logRef,
        buildAdminLogPayload({
          actorUid: adminUid,
          actorName,
          category: 'settings_update',
          actionTitle: 'Amebadilisha bei za Coin na mipangilio ya malipo',
          targetUid: '',
          targetLabel: 'Mipangilio ya Mfumo',
          documentPath: path,
          details: `PNG: ${sanitizedCosts.exportPng}, PDF: ${sanitizedCosts.printPdf}, QR: ${sanitizedCosts.liveQr}, Hifadhi: ${sanitizedCosts.saveRecord} Coins${paymentConfig ? ` · Vifurushi ${paymentConfig.packages.length} (${paymentConfig.accountName})` : ''}`,
        })
      );
    }
    await batch.commit();
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, path);
  }
}

export async function submitPaymentRequest(params: {
  profile: UserProfile;
  selectedPackage: PaymentPackage;
  network: PaymentNetwork;
  payerPhone: string;
  payerName: string;
  transactionRef: string;
  userNote: string;
}): Promise<string> {
  const {
    profile,
    selectedPackage,
    network,
    payerPhone,
    payerName,
    transactionRef,
    userNote,
  } = params;

  const cleanRef = transactionRef.trim().toUpperCase().slice(0, 64);
  if (cleanRef.length < 4) {
    throw new Error('Weka namba ya muamala (Transaction ID) yenye herufi/tarakimu angalau 4.');
  }
  const cleanPayerPhone = payerPhone.trim().slice(0, 20);
  if (cleanPayerPhone.length < 9) {
    throw new Error('Weka namba halali ya simu uliyotumia kufanya malipo.');
  }
  const cleanPayerName = payerName.trim().slice(0, 120);
  if (cleanPayerName.length < 2) {
    throw new Error('Weka jina la mlipaji.');
  }

  const colRef = collection(db, 'paymentRequests');
  const docRef = doc(colRef);
  const path = `paymentRequests/${docRef.id}`;

  try {
    await setDoc(docRef, {
      userId: profile.uid,
      userFullName: (profile.fullName || 'Mtumiaji').trim().slice(0, 120),
      userPhone: (profile.phone || cleanPayerPhone).trim().slice(0, 20),
      packageId: selectedPackage.id.slice(0, 40),
      packageLabel: selectedPackage.label.slice(0, 80),
      coins: Math.max(1, Math.min(100000, Math.round(selectedPackage.coins))),
      amountTzs: Math.max(100, Math.min(50000000, Math.round(selectedPackage.priceTzs))),
      network,
      payerPhone: cleanPayerPhone,
      payerName: cleanPayerName,
      transactionRef: cleanRef,
      userNote: userNote.trim().slice(0, 200),
      status: 'pending',
      adminNote: '',
      reviewedBy: '',
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    });
    return docRef.id;
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, path);
  }
}

export async function cancelPendingPaymentRequest(paymentId: string): Promise<void> {
  const path = `paymentRequests/${paymentId}`;
  try {
    await deleteDoc(doc(db, 'paymentRequests', paymentId));
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, path);
  }
}

export async function adminApprovePaymentRequest(params: {
  payment: PaymentRequestRecord;
  adminUid: string;
  actorName?: string;
  adminNote?: string;
  skipAuditLog?: boolean;
}): Promise<number> {
  const { payment, adminUid, actorName, adminNote = '', skipAuditLog } = params;
  const path = `paymentRequests/${payment.id}`;

  try {
    return await runTransaction(db, async (tx) => {
      const paymentRef = doc(db, 'paymentRequests', payment.id);
      const userRef = doc(db, 'users', payment.userId);
      const txRef = doc(collection(db, 'users', payment.userId, 'coinTransactions'));

      const paymentSnap = await tx.get(paymentRef);
      if (!paymentSnap.exists()) {
        throw new Error('Ombi hili la malipo halikupatikana.');
      }
      const currentPayment = paymentSnap.data() as Omit<PaymentRequestRecord, 'id'>;
      if (currentPayment.status !== 'pending') {
        throw new Error('Ombi hili tayari limeshashughulikiwa.');
      }

      const userSnap = await tx.get(userRef);
      if (!userSnap.exists()) {
        throw new Error('Akaunti ya mtumiaji huyu haikupatikana.');
      }
      const userData = userSnap.data() as UserProfile;
      const nextBalance = userData.coins + currentPayment.coins;
      const resolvedAdminNote = (
        adminNote.trim() || 'Malipo yamehakikiwa na coin zimeongezwa.'
      ).slice(0, 200);

      tx.update(paymentRef, {
        status: 'approved',
        adminNote: resolvedAdminNote,
        reviewedBy: adminUid,
        updatedAt: serverTimestamp(),
      });

      tx.update(userRef, {
        coins: nextBalance,
        updatedAt: serverTimestamp(),
      });

      tx.set(txRef, {
        userId: payment.userId,
        type: 'topup',
        amount: currentPayment.coins,
        balanceAfter: nextBalance,
        service: 'payment_topup',
        note: `Malipo ${currentPayment.transactionRef} (${currentPayment.amountTzs.toLocaleString()} TZS)`.slice(0, 200),
        createdBy: adminUid,
        createdAt: serverTimestamp(),
      });

      if (!skipAuditLog) {
        const logRef = doc(collection(db, 'adminActivityLogs'));
        tx.set(
          logRef,
          buildAdminLogPayload({
            actorUid: adminUid,
            actorName,
            category: 'payment_approve',
            actionTitle: `Amekubali malipo ${currentPayment.transactionRef} (+${currentPayment.coins} Coins)`,
            targetUid: payment.userId,
            targetLabel: `${currentPayment.userFullName} (${currentPayment.userPhone})`,
            documentPath: `${path}, users/${payment.userId}, users/${payment.userId}/coinTransactions/${txRef.id}`,
            details: `Kiasi: ${currentPayment.amountTzs.toLocaleString()} TZS · Salio la Coin: ${userData.coins} → ${nextBalance}. ${resolvedAdminNote}`,
          })
        );
      }

      return nextBalance;
    });
  } catch (error) {
    if (
      error instanceof Error &&
      (error.message.includes('limeshashughulikiwa') ||
        error.message.includes('haikupatikana') ||
        error.message.includes('halikupatikana'))
    ) {
      throw error;
    }
    handleFirestoreError(error, OperationType.WRITE, path);
  }
}

export async function adminRejectPaymentRequest(params: {
  paymentId: string;
  adminUid: string;
  actorName?: string;
  transactionRef?: string;
  targetUid?: string;
  targetLabel?: string;
  adminNote?: string;
  skipAuditLog?: boolean;
}): Promise<void> {
  const {
    paymentId,
    adminUid,
    actorName,
    transactionRef,
    targetUid,
    targetLabel,
    adminNote = '',
    skipAuditLog,
  } = params;
  const path = `paymentRequests/${paymentId}`;
  try {
    const resolvedNote = (
      adminNote.trim() || 'Kumbukumbu ya muamala haijathibitishwa.'
    ).slice(0, 200);
    const batch = writeBatch(db);
    batch.update(doc(db, 'paymentRequests', paymentId), {
      status: 'rejected',
      adminNote: resolvedNote,
      reviewedBy: adminUid,
      updatedAt: serverTimestamp(),
    });
    if (!skipAuditLog) {
      const logRef = doc(collection(db, 'adminActivityLogs'));
      batch.set(
        logRef,
        buildAdminLogPayload({
          actorUid: adminUid,
          actorName,
          category: 'payment_reject',
          actionTitle: `Amekataa ombi la malipo ${transactionRef || paymentId}`,
          targetUid: targetUid || '',
          targetLabel: targetLabel || 'Ombi la Malipo',
          documentPath: path,
          details: `Sababu: ${resolvedNote}`,
        })
      );
    }
    await batch.commit();
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}

export async function saveLicenseToCloud(params: {
  uid: string;
  data: LicenseData;
  maskMode: MaskMode;
  qrMode: QrMode;
  existingId?: string | null;
}): Promise<string> {
  const { uid, data, maskMode, qrMode, existingId } = params;
  const colRef = collection(db, 'users', uid, 'licenses');
  const docRef = existingId ? doc(colRef, existingId) : doc(colRef);
  const path = `users/${uid}/licenses/${docRef.id}`;

  const payload = {
    ownerId: uid,
    blNo: (data.blNo || 'UNTITLED').slice(0, 80),
    issuingOffice: data.issuingOffice.slice(0, 140),
    taxId: (formatTinNumber(data.taxId) || data.taxId).slice(0, 60),
    licensee: data.licensee.toUpperCase().slice(0, 140),
    businessOf: data.businessOf.slice(0, 200),
    licensingType: data.licensingType.slice(0, 80),
    dateOfIssue: data.dateOfIssue.slice(0, 32),
    expiringDate: data.expiringDate.slice(0, 32),
    principalBranch: data.principalBranch.slice(0, 60),
    region: data.region.slice(0, 80),
    ward: data.ward.slice(0, 80),
    street: data.street.slice(0, 100),
    feePaid: data.feePaid.slice(0, 40),
    maskMode,
    qrMode,
    updatedAt: serverTimestamp(),
  };

  try {
    if (existingId) {
      await updateDoc(docRef, payload);
    } else {
      await setDoc(docRef, {
        ...payload,
        createdAt: serverTimestamp(),
      });
    }
    return docRef.id;
  } catch (error) {
    handleFirestoreError(
      error,
      existingId ? OperationType.UPDATE : OperationType.CREATE,
      path
    );
  }
}

export async function deleteSavedLicense(params: {
  uid: string;
  licenseId: string;
}): Promise<void> {
  const { uid, licenseId } = params;
  const path = `users/${uid}/licenses/${licenseId}`;
  try {
    await deleteDoc(doc(db, 'users', uid, 'licenses', licenseId));
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, path);
  }
}

export async function saveTinToCloud(params: {
  uid: string;
  data: TinData;
  maskMode: MaskMode;
  qrMode: QrMode;
  existingId?: string | null;
}): Promise<string> {
  const { uid, data, maskMode, qrMode, existingId } = params;
  const colRef = collection(db, 'users', uid, 'tinCertificates');
  const docRef = existingId ? doc(colRef, existingId) : doc(colRef);
  const path = `users/${uid}/tinCertificates/${docRef.id}`;

  const payload = {
    ownerId: uid,
    taxpayerName: (data.taxpayerName.toUpperCase() || 'UNTITLED').slice(0, 140),
    tinNumber: (formatTinNumber(data.tinNumber) || data.tinNumber || '000-000-000').slice(0, 60),
    effectiveFrom: data.effectiveFrom.slice(0, 60),
    traLocation: data.traLocation.slice(0, 100),
    taxOffice: data.taxOffice.slice(0, 120),
    physicalLocation: data.physicalLocation.slice(0, 100),
    streetArea: data.streetArea.slice(0, 100),
    maskMode,
    qrMode,
    updatedAt: serverTimestamp(),
  };

  try {
    if (existingId) {
      await updateDoc(docRef, payload);
    } else {
      await setDoc(docRef, {
        ...payload,
        createdAt: serverTimestamp(),
      });
    }
    return docRef.id;
  } catch (error) {
    handleFirestoreError(
      error,
      existingId ? OperationType.UPDATE : OperationType.CREATE,
      path
    );
  }
}

export async function deleteSavedTin(params: {
  uid: string;
  certId: string;
}): Promise<void> {
  const { uid, certId } = params;
  const path = `users/${uid}/tinCertificates/${certId}`;
  try {
    await deleteDoc(doc(db, 'users', uid, 'tinCertificates', certId));
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, path);
  }
}
