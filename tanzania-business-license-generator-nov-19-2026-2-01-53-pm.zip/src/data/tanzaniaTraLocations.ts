export interface TinSelectOption {
  value: string;
  label: string;
}

export interface TinSelectGroup {
  group: string;
  options: TinSelectOption[];
}

const makeOptions = (items: string[]): TinSelectOption[] =>
  items.map((item) => ({ value: item, label: item }));

const MONTHS_EN = [
  'January',
  'February',
  'March',
  'April',
  'May',
  'June',
  'July',
  'August',
  'September',
  'October',
  'November',
  'December',
];

function getOrdinalSuffix(day: number): string {
  const mod100 = day % 100;
  if (mod100 >= 11 && mod100 <= 13) return 'th';
  switch (day % 10) {
    case 1:
      return 'st';
    case 2:
      return 'nd';
    case 3:
      return 'rd';
    default:
      return 'th';
  }
}

export function isoToOrdinalDate(iso: string): string {
  const match = /^(\d{4})-(\d{2})-(\d{2})$/.exec(iso.trim());
  if (!match) return iso;
  const year = Number(match[1]);
  const monthIdx = Number(match[2]) - 1;
  const day = Number(match[3]);
  const monthName = MONTHS_EN[monthIdx];
  if (!monthName || day < 1 || day > 31) return iso;
  return `${day}${getOrdinalSuffix(day)} ${monthName} ${year}`;
}

export function ordinalToIsoDate(val: string): string {
  const trimmed = val.trim();
  if (/^\d{4}-\d{2}-\d{2}$/.test(trimmed)) return trimmed;
  const match = /^(\d{1,2})(?:st|nd|rd|th)?\s+([A-Za-z]+)\s+(\d{4})$/.exec(
    trimmed
  );
  if (!match) return '';
  const day = Number(match[1]);
  const monthIdx = MONTHS_EN.findIndex(
    (m) => m.toLowerCase() === match[2].toLowerCase()
  );
  const year = Number(match[3]);
  if (monthIdx === -1 || day < 1 || day > 31 || year < 1900) return '';
  return `${year}-${String(monthIdx + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
}

export function getTodayOrdinalDate(): string {
  const now = new Date();
  const iso = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')}`;
  return isoToOrdinalDate(iso);
}

export const TRA_LOCATION_GROUPS: TinSelectGroup[] = [
  {
    group: 'Dar es Salaam Tax Regions',
    options: makeOptions([
      'DAR ES SALAAM',
      'ILALA',
      'KARIAKOO',
      'KIGAMBONI',
      'KINONDONI',
      'TEGETA',
      'TEMEKE',
      'UBUNGO',
    ]),
  },
  {
    group: 'Mikoa Mingine (Tanzania Bara & Zanzibar)',
    options: makeOptions([
      'GEITA',
      'ARUSHA',
      'DODOMA',
      'IRINGA',
      'KAGERA',
      'KATAVI',
      'KIGOMA',
      'KILIMANJARO',
      'LINDI',
      'MANYARA',
      'MARA',
      'MBEYA',
      'MOROGORO',
      'MTWARA',
      'MWANZA',
      'NJOMBE',
      'PWANI',
      'RUKWA',
      'RUVUMA',
      'SHINYANGA',
      'SIMIYU',
      'SINGIDA',
      'SONGWE',
      'TABORA',
      'TANGA',
      'ZANZIBAR',
      'MJINI MAGHARIBI',
      'PEMBA',
    ]),
  },
];

export const ALL_TRA_LOCATIONS: TinSelectOption[] =
  TRA_LOCATION_GROUPS.flatMap((g) => g.options);

export const TAX_OFFICE_GROUPS: TinSelectGroup[] = [
  {
    group: 'Geita & Kanda ya Ziwa',
    options: makeOptions([
      'RUZENWE TAX CENTRE',
      'GEITA TAX REGION',
      'KATORO TAX CENTRE',
      'CHATO TAX CENTRE',
      'BUKOMBE TAX CENTRE',
      'MWANZA TAX REGION',
      'NYAMAGANA TAX CENTRE',
      'ILEMELA TAX CENTRE',
      'MAGU TAX SERVICE CENTRE',
      'SENGEREMA TAX CENTRE',
      'MISUNGWI TAX CENTRE',
      'KWIMBA TAX CENTRE',
      'UKEREWE TAX CENTRE',
      'SHINYANGA TAX REGION',
      'KAHAMA TAX REGION',
      'BARIADI TAX REGION',
      'MASWA TAX CENTRE',
      'BUKOBA TAX REGION',
      'KARAGWE TAX CENTRE',
      'BIHARAMULO TAX CENTRE',
      'NGARA TAX CENTRE',
      'MUSOMA TAX REGION',
      'TARIME TAX CENTRE',
      'BUNDA TAX CENTRE',
    ]),
  },
  {
    group: 'Dar es Salaam & Pwani',
    options: makeOptions([
      'ILALA TAX REGION',
      'KARIAKOO TAX REGION',
      'KINONDONI TAX REGION',
      'TEMEKE TAX REGION',
      'TEGETA TAX REGION',
      'UBUNGO TAX SERVICE CENTRE',
      'KIGAMBONI TAX SERVICE CENTRE',
      'MWENGE TAX CENTRE',
      'BUGURUNI TAX CENTRE',
      'MBAGALA TAX CENTRE',
      'LARGE TAXPAYERS DEPARTMENT',
      'KIBAHA TAX REGION',
      'BAGAMOYO TAX CENTRE',
      'MKURANGA TAX CENTRE',
    ]),
  },
  {
    group: 'Kaskazini & Kati',
    options: makeOptions([
      'ARUSHA TAX REGION',
      'MOSHI TAX REGION',
      'BABATI TAX REGION',
      'DODOMA TAX REGION',
      'SINGIDA TAX REGION',
      'TABORA TAX REGION',
      'NZEGA TAX CENTRE',
      'KIGOMA TAX REGION',
      'KASULU TAX CENTRE',
      'TANGA TAX REGION',
      'KOROGWE TAX CENTRE',
      'MOROGORO TAX REGION',
      'IFAKARA TAX CENTRE',
    ]),
  },
  {
    group: 'Nyanda za Juu Kusini, Kusini & Zanzibar',
    options: makeOptions([
      'MBEYA TAX REGION',
      'TUNDUMA TAX CENTRE',
      'KYELA TAX CENTRE',
      'IRINGA TAX REGION',
      'MAFINGA TAX CENTRE',
      'NJOMBE TAX REGION',
      'MAKAMBAKO TAX CENTRE',
      'SONGEA TAX REGION',
      'SUMBAWANGA TAX REGION',
      'MPANDA TAX REGION',
      'MTWARA TAX REGION',
      'MASASI TAX CENTRE',
      'LINDI TAX REGION',
      'ZANZIBAR TAX REGION',
    ]),
  },
];

export const ALL_TAX_OFFICES: TinSelectOption[] =
  TAX_OFFICE_GROUPS.flatMap((g) => g.options);

export const PHYSICAL_LOCATION_GROUPS: TinSelectGroup[] = [
  {
    group: 'Geita, Mwanza & Kanda ya Ziwa',
    options: makeOptions([
      'NAMONGE',
      'GEITA MJINI',
      'KATORO',
      'BUKOMBE',
      'USHIROMBO',
      'CHATO',
      'MAGU',
      'KISESA',
      'NYAMAGANA',
      'IGOMA',
      'BUZURUGA',
      'ILEMELA',
      'NYAMHONGOLO',
      'PASIANSI',
      'SENGEREMA',
      'MISUNGWI',
      'NGUDU',
      'NANSIO',
      'KAHAMA MJINI',
      'SHINYANGA MJINI',
      'BARIADI',
      'MASWA',
      'LAMADI',
      'BUKOBA MJINI',
      'MUSOMA MJINI',
      'TARIME',
      'BUNDA',
    ]),
  },
  {
    group: 'Dar es Salaam & Pwani',
    options: makeOptions([
      'KARIAKOO',
      'POSTA / KIVUKONI',
      'ILALA',
      'BUGURUNI',
      'TABATA',
      'KINONDONI',
      'SINZA',
      'MWENGE',
      'MIKOCHENI',
      'MSASANI',
      'KAWE',
      'TEGETA',
      'BUNJU',
      'UBUNGO',
      'KIMARA',
      'MBEZI LUIS',
      'MANZESE',
      'TEMEKE',
      'CHANGOMBE',
      'KURASINI',
      'MBAGALA',
      'KIGAMBONI',
      'KIBAHA',
      'BAGAMOYO',
      'MKURANGA',
    ]),
  },
  {
    group: 'Mikoa Mingine (Tanzania Bara & Zanzibar)',
    options: makeOptions([
      'ARUSHA MJINI',
      'TENGERU',
      'MOSHI MJINI',
      'DODOMA MJINI',
      'MOROGORO MJINI',
      'IFAKARA',
      'TANGA MJINI',
      'MBEYA MJINI',
      'TUNDUMA',
      'IRINGA MJINI',
      'MAFINGA',
      'NJOMBE MJINI',
      'MAKAMBAKO',
      'SONGEA MJINI',
      'TABORA MJINI',
      'NZEGA',
      'KIGOMA UJIJI',
      'KASULU',
      'SINGIDA MJINI',
      'SUMBAWANGA MJINI',
      'MPANDA MJINI',
      'BABATI',
      'MTWARA MJINI',
      'MASASI',
      'LINDI MJINI',
      'MJINI ZANZIBAR',
      'CHAKE CHAKE',
    ]),
  },
];

export const ALL_PHYSICAL_LOCATIONS: TinSelectOption[] =
  PHYSICAL_LOCATION_GROUPS.flatMap((g) => g.options);

export const STREET_AREA_GROUPS: TinSelectGroup[] = [
  {
    group: 'Maeneo / Mitaa Maarufu (Kanda ya Ziwa & Mikoani)',
    options: makeOptions([
      'MUHAMA',
      'KISESA',
      'CENTRE',
      'MJINI KATI',
      'SOKONI',
      'STENDI KUU',
      'MJI MWEMA',
      'BUZURUGA',
      'IGOMA',
      'NYERERE ROAD',
      'KENYATTA ROAD',
      'MAKONGORO ROAD',
      'UHURU STREET',
      'JAMHURI STREET',
      'LUMUMBA STREET',
      'SOKOINE ROAD',
      'KILIMANI',
      'MAJENGO',
      'CHANGOMBE',
      'BOMA ROAD',
    ]),
  },
  {
    group: 'Mitaa / Barabara Kuu (Dar es Salaam & Miji Mikubwa)',
    options: makeOptions([
      'SAMORA AVENUE',
      'MOROGORO ROAD',
      'BAGAMOYO ROAD',
      'ALI HASSAN MWINYI ROAD',
      'MANDELA ROAD',
      'KILWA ROAD',
      'NYERERE ROAD / PUGU',
      'KAWAWA ROAD',
      'MSIMBAZI STREET',
      'UHURU / KARIAKOO',
      'AGGREY STREET',
      'NKURUMAH STREET',
      'BIBI TITI MOHAMED',
      'OHIO STREET',
      'AZIKIWE STREET',
      'SHEKILANGO ROAD',
      'MWAI KIBAKI ROAD',
      'OLD BAGAMOYO ROAD',
      'GOBA',
      'MBEZI BEACH',
    ]),
  },
];

export const ALL_STREET_AREAS: TinSelectOption[] =
  STREET_AREA_GROUPS.flatMap((g) => g.options);
