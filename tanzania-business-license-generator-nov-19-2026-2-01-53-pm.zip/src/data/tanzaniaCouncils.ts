export interface IssuingOfficeOption {
  value: string;
  label: string;
}

export interface IssuingOfficeGroup {
  group: string;
  options: IssuingOfficeOption[];
}

const makeOptions = (names: string[]): IssuingOfficeOption[] =>
  names.map((name) => ({ value: name, label: name }));

export const TANZANIA_COUNCIL_GROUPS: IssuingOfficeGroup[] = [
  {
    group: 'Mamlaka ya Usajili wa Biashara (Taifa)',
    options: makeOptions(['BRELA (MINISTRY OF INDUSTRY AND TRADE)']),
  },
  {
    group: 'Mkoa wa Arusha (7)',
    options: makeOptions([
      'ARUSHA CITY COUNCIL',
      'ARUSHA DISTRICT COUNCIL',
      'KARATU DISTRICT COUNCIL',
      'LONGIDO DISTRICT COUNCIL',
      'MERU DISTRICT COUNCIL',
      'MONDULI DISTRICT COUNCIL',
      'NGORONGORO DISTRICT COUNCIL',
    ]),
  },
  {
    group: 'Mkoa wa Dar es Salaam (6)',
    options: makeOptions([
      'DAR ES SALAAM CITY COUNCIL',
      'ILALA MUNICIPAL COUNCIL',
      'KIGAMBONI MUNICIPAL COUNCIL',
      'KINONDONI MUNICIPAL COUNCIL',
      'TEMEKE MUNICIPAL COUNCIL',
      'UBUNGO MUNICIPAL COUNCIL',
    ]),
  },
  {
    group: 'Mkoa wa Dodoma (8)',
    options: makeOptions([
      'DODOMA CITY COUNCIL',
      'BAHI DISTRICT COUNCIL',
      'CHAMWINO DISTRICT COUNCIL',
      'CHEMBA DISTRICT COUNCIL',
      'KONDOA TOWN COUNCIL',
      'KONDOA DISTRICT COUNCIL',
      'KONGWA DISTRICT COUNCIL',
      'MPWAPWA DISTRICT COUNCIL',
    ]),
  },
  {
    group: 'Mkoa wa Geita (6)',
    options: makeOptions([
      'GEITA TOWN COUNCIL',
      'GEITA DISTRICT COUNCIL',
      'BUKOMBE DISTRICT COUNCIL',
      'CHATO DISTRICT COUNCIL',
      'MBOGWE DISTRICT COUNCIL',
      "NYANG'HWALE DISTRICT COUNCIL",
    ]),
  },
  {
    group: 'Mkoa wa Iringa (5)',
    options: makeOptions([
      'IRINGA MUNICIPAL COUNCIL',
      'IRINGA DISTRICT COUNCIL',
      'MAFINGA TOWN COUNCIL',
      'KILOLO DISTRICT COUNCIL',
      'MUFINDI DISTRICT COUNCIL',
    ]),
  },
  {
    group: 'Mkoa wa Kagera (8)',
    options: makeOptions([
      'BUKOBA MUNICIPAL COUNCIL',
      'BUKOBA DISTRICT COUNCIL',
      'BIHARAMULO DISTRICT COUNCIL',
      'KARAGWE DISTRICT COUNCIL',
      'KYERWA DISTRICT COUNCIL',
      'MISSENYI DISTRICT COUNCIL',
      'MULEBA DISTRICT COUNCIL',
      'NGARA DISTRICT COUNCIL',
    ]),
  },
  {
    group: 'Mkoa wa Katavi (6)',
    options: makeOptions([
      'MPANDA MUNICIPAL COUNCIL',
      'TANGANYIKA DISTRICT COUNCIL',
      'MPANDA DISTRICT COUNCIL',
      'MLELE DISTRICT COUNCIL',
      'MPIMBWE DISTRICT COUNCIL',
      'NSIMBO DISTRICT COUNCIL',
    ]),
  },
  {
    group: 'Mkoa wa Kigoma (8)',
    options: makeOptions([
      'KIGOMA UJIJI MUNICIPAL COUNCIL',
      'KIGOMA DISTRICT COUNCIL',
      'BUHIGWE DISTRICT COUNCIL',
      'KAKONKO DISTRICT COUNCIL',
      'KASULU TOWN COUNCIL',
      'KASULU DISTRICT COUNCIL',
      'KIBONDO DISTRICT COUNCIL',
      'UVINZA DISTRICT COUNCIL',
    ]),
  },
  {
    group: 'Mkoa wa Kilimanjaro (7)',
    options: makeOptions([
      'MOSHI MUNICIPAL COUNCIL',
      'MOSHI DISTRICT COUNCIL',
      'HAI DISTRICT COUNCIL',
      'MWANGA DISTRICT COUNCIL',
      'ROMBO DISTRICT COUNCIL',
      'SAME DISTRICT COUNCIL',
      'SIHA DISTRICT COUNCIL',
    ]),
  },
  {
    group: 'Mkoa wa Lindi (7)',
    options: makeOptions([
      'LINDI MUNICIPAL COUNCIL',
      'MTAMA DISTRICT COUNCIL',
      'LINDI DISTRICT COUNCIL',
      'KILWA DISTRICT COUNCIL',
      'LIWALE DISTRICT COUNCIL',
      'NACHINGWEA DISTRICT COUNCIL',
      'RUANGWA DISTRICT COUNCIL',
    ]),
  },
  {
    group: 'Mkoa wa Manyara (7)',
    options: makeOptions([
      'BABATI TOWN COUNCIL',
      'BABATI DISTRICT COUNCIL',
      'HANANG DISTRICT COUNCIL',
      'KITETO DISTRICT COUNCIL',
      'MBULU TOWN COUNCIL',
      'MBULU DISTRICT COUNCIL',
      'SIMANJIRO DISTRICT COUNCIL',
    ]),
  },
  {
    group: 'Mkoa wa Mara (9)',
    options: makeOptions([
      'MUSOMA MUNICIPAL COUNCIL',
      'MUSOMA DISTRICT COUNCIL',
      'BUNDA TOWN COUNCIL',
      'BUNDA DISTRICT COUNCIL',
      'BUTIAMA DISTRICT COUNCIL',
      'RORYA DISTRICT COUNCIL',
      'SERENGETI DISTRICT COUNCIL',
      'TARIME TOWN COUNCIL',
      'TARIME DISTRICT COUNCIL',
    ]),
  },
  {
    group: 'Mkoa wa Mbeya (7)',
    options: makeOptions([
      'MBEYA CITY COUNCIL',
      'MBEYA DISTRICT COUNCIL',
      'BUSOKELO DISTRICT COUNCIL',
      'CHUNYA DISTRICT COUNCIL',
      'KYELA DISTRICT COUNCIL',
      'MBARALI DISTRICT COUNCIL',
      'RUNGWE DISTRICT COUNCIL',
    ]),
  },
  {
    group: 'Mkoa wa Morogoro (9)',
    options: makeOptions([
      'MOROGORO MUNICIPAL COUNCIL',
      'MOROGORO DISTRICT COUNCIL',
      'GAIRO DISTRICT COUNCIL',
      'IFAKARA TOWN COUNCIL',
      'KILOSA DISTRICT COUNCIL',
      'MALINYI DISTRICT COUNCIL',
      'MLIMBA DISTRICT COUNCIL',
      'MVOMERO DISTRICT COUNCIL',
      'ULANGA DISTRICT COUNCIL',
    ]),
  },
  {
    group: 'Mkoa wa Mtwara (9)',
    options: makeOptions([
      'MTWARA MIKINDANI MUNICIPAL COUNCIL',
      'MTWARA DISTRICT COUNCIL',
      'MASASI TOWN COUNCIL',
      'MASASI DISTRICT COUNCIL',
      'NANYAMBA TOWN COUNCIL',
      'NANYUMBU DISTRICT COUNCIL',
      'NEWALA TOWN COUNCIL',
      'NEWALA DISTRICT COUNCIL',
      'TANDAHIMBA DISTRICT COUNCIL',
    ]),
  },
  {
    group: 'Mkoa wa Mwanza (8)',
    options: makeOptions([
      'MAGU DISTRICT COUNCIL',
      'MWANZA CITY COUNCIL',
      'ILEMELA MUNICIPAL COUNCIL',
      'BUCHOSA DISTRICT COUNCIL',
      'KWIMBA DISTRICT COUNCIL',
      'MISUNGWI DISTRICT COUNCIL',
      'SENGEREMA DISTRICT COUNCIL',
      'UKEREWE DISTRICT COUNCIL',
    ]),
  },
  {
    group: 'Mkoa wa Njombe (6)',
    options: makeOptions([
      'NJOMBE TOWN COUNCIL',
      'NJOMBE DISTRICT COUNCIL',
      'LUDEWA DISTRICT COUNCIL',
      'MAKAMBAKO TOWN COUNCIL',
      'MAKETE DISTRICT COUNCIL',
      "WANGING'OMBE DISTRICT COUNCIL",
    ]),
  },
  {
    group: 'Mkoa wa Pwani (9)',
    options: makeOptions([
      'KIBAHA TOWN COUNCIL',
      'KIBAHA DISTRICT COUNCIL',
      'BAGAMOYO DISTRICT COUNCIL',
      'CHALINZE DISTRICT COUNCIL',
      'KIBITI DISTRICT COUNCIL',
      'KISARAWE DISTRICT COUNCIL',
      'MAFIA DISTRICT COUNCIL',
      'MKURANGA DISTRICT COUNCIL',
      'RUFIJI DISTRICT COUNCIL',
    ]),
  },
  {
    group: 'Mkoa wa Rukwa (4)',
    options: makeOptions([
      'SUMBAWANGA MUNICIPAL COUNCIL',
      'SUMBAWANGA DISTRICT COUNCIL',
      'KALAMBO DISTRICT COUNCIL',
      'NKASI DISTRICT COUNCIL',
    ]),
  },
  {
    group: 'Mkoa wa Ruvuma (8)',
    options: makeOptions([
      'SONGEA MUNICIPAL COUNCIL',
      'SONGEA DISTRICT COUNCIL',
      'MADABA DISTRICT COUNCIL',
      'MBINGA TOWN COUNCIL',
      'MBINGA DISTRICT COUNCIL',
      'NAMTUMBO DISTRICT COUNCIL',
      'NYASA DISTRICT COUNCIL',
      'TUNDURU DISTRICT COUNCIL',
    ]),
  },
  {
    group: 'Mkoa wa Shinyanga (6)',
    options: makeOptions([
      'SHINYANGA MUNICIPAL COUNCIL',
      'SHINYANGA DISTRICT COUNCIL',
      'KAHAMA MUNICIPAL COUNCIL',
      'KISHAPU DISTRICT COUNCIL',
      'MSALALA DISTRICT COUNCIL',
      'USHETU DISTRICT COUNCIL',
    ]),
  },
  {
    group: 'Mkoa wa Simiyu (6)',
    options: makeOptions([
      'BARIADI TOWN COUNCIL',
      'BARIADI DISTRICT COUNCIL',
      'BUSEGA DISTRICT COUNCIL',
      'ITILIMA DISTRICT COUNCIL',
      'MASWA DISTRICT COUNCIL',
      'MEATU DISTRICT COUNCIL',
    ]),
  },
  {
    group: 'Mkoa wa Singida (7)',
    options: makeOptions([
      'SINGIDA MUNICIPAL COUNCIL',
      'SINGIDA DISTRICT COUNCIL',
      'IKUNGI DISTRICT COUNCIL',
      'IRAMBA DISTRICT COUNCIL',
      'ITIGI DISTRICT COUNCIL',
      'MANYONI DISTRICT COUNCIL',
      'MKALAMA DISTRICT COUNCIL',
    ]),
  },
  {
    group: 'Mkoa wa Songwe (6)',
    options: makeOptions([
      'TUNDUMA TOWN COUNCIL',
      'VWAWA TOWN COUNCIL',
      'ILEJE DISTRICT COUNCIL',
      'MBOZI DISTRICT COUNCIL',
      'MOMBA DISTRICT COUNCIL',
      'SONGWE DISTRICT COUNCIL',
    ]),
  },
  {
    group: 'Mkoa wa Tabora (8)',
    options: makeOptions([
      'TABORA MUNICIPAL COUNCIL',
      'IGUNGA DISTRICT COUNCIL',
      'KALIUA DISTRICT COUNCIL',
      'NZEGA TOWN COUNCIL',
      'NZEGA DISTRICT COUNCIL',
      'SIKONGE DISTRICT COUNCIL',
      'URAMBO DISTRICT COUNCIL',
      'UYUI DISTRICT COUNCIL',
    ]),
  },
  {
    group: 'Mkoa wa Tanga (11)',
    options: makeOptions([
      'TANGA CITY COUNCIL',
      'BUMBULI DISTRICT COUNCIL',
      'HANDENI TOWN COUNCIL',
      'HANDENI DISTRICT COUNCIL',
      'KILINDI DISTRICT COUNCIL',
      'KOROGWE TOWN COUNCIL',
      'KOROGWE DISTRICT COUNCIL',
      'LUSHOTO DISTRICT COUNCIL',
      'MKINGA DISTRICT COUNCIL',
      'MUHEZA DISTRICT COUNCIL',
      'PANGANI DISTRICT COUNCIL',
    ]),
  },
  {
    group: 'Zanzibar (Unguja na Pemba)',
    options: makeOptions([
      'ZANZIBAR CITY COUNCIL',
      'MJINI MUNICIPAL COUNCIL',
      'MAGHARIBI A MUNICIPAL COUNCIL',
      'MAGHARIBI B MUNICIPAL COUNCIL',
      'KASKAZINI A DISTRICT COUNCIL',
      'KASKAZINI B DISTRICT COUNCIL',
      'KATI DISTRICT COUNCIL',
      'KUSINI DISTRICT COUNCIL',
      'CHAKE CHAKE TOWN COUNCIL',
      'CHAKE CHAKE DISTRICT COUNCIL',
      'WETE TOWN COUNCIL',
      'WETE DISTRICT COUNCIL',
      'MICHEWENI DISTRICT COUNCIL',
      'MKOANI DISTRICT COUNCIL',
    ]),
  },
];

export const ALL_ISSUING_OFFICE_OPTIONS: IssuingOfficeOption[] =
  TANZANIA_COUNCIL_GROUPS.flatMap((group) => group.options);
