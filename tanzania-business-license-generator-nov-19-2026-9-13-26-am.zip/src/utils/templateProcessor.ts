import {
  FIELD_OVERLAYS,
  LicenseData,
  MaskMode,
  QR_BOX,
  QrMode,
  TEMPLATE_HEIGHT,
  TEMPLATE_WIDTH,
} from '../types/license';
import {
  TIN_FIELD_OVERLAYS,
  TIN_QR_BOX,
  TIN_TEMPLATE_HEIGHT,
  TIN_TEMPLATE_WIDTH,
  TinData,
} from '../types/tin';

export interface EraseBoxSpec {
  eraseX: number;
  eraseY: number;
  eraseW: number;
  eraseH: number;
  eraseKind: 'dark' | 'teal';
}

function loadImage(src: string): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => resolve(img);
    img.onerror = (err) => reject(err);
    img.src = src;
  });
}

/**
 * Creates a watermark-preserving blank template by removing only the original
 * sample text pixels inside each known field box and interpolating smoothly
 * across the surrounding watermark and background pattern.
 */
export async function createCleanedTemplateDataUrl(
  imagePath: string,
  targetWidth: number = TEMPLATE_WIDTH,
  targetHeight: number = TEMPLATE_HEIGHT,
  boxes: EraseBoxSpec[] = FIELD_OVERLAYS
): Promise<string> {
  const img = await loadImage(imagePath);
  const canvas = document.createElement('canvas');
  canvas.width = targetWidth;
  canvas.height = targetHeight;

  const ctx = canvas.getContext('2d');
  if (!ctx) {
    throw new Error('Could not initialize 2D canvas context');
  }

  ctx.drawImage(img, 0, 0, targetWidth, targetHeight);
  const imageData = ctx.getImageData(0, 0, targetWidth, targetHeight);
  const { data, width, height } = imageData;

  for (const box of boxes) {
    const x0 = Math.max(0, box.eraseX);
    const y0 = Math.max(0, box.eraseY);
    const x1 = Math.min(width - 1, box.eraseX + box.eraseW);
    const y1 = Math.min(height - 1, box.eraseY + box.eraseH);
    const bw = x1 - x0 + 1;
    const bh = y1 - y0 + 1;

    const isText = new Uint8Array(bw * bh);

    for (let dy = 0; dy < bh; dy++) {
      const y = y0 + dy;
      for (let dx = 0; dx < bw; dx++) {
        const x = x0 + dx;
        const idx = (y * width + x) * 4;
        const r = data[idx];
        const g = data[idx + 1];
        const b = data[idx + 2];
        const luma = 0.299 * r + 0.587 * g + 0.114 * b;

        if (box.eraseKind === 'teal') {
          const isTealText = (b - r > 18 && r < 185) || luma < 205;
          if (isTealText) {
            isText[dy * bw + dx] = 1;
          }
        } else {
          if (luma < 205) {
            isText[dy * bw + dx] = 1;
          }
        }
      }
    }

    const dilated = new Uint8Array(bw * bh);
    for (let dy = 0; dy < bh; dy++) {
      for (let dx = 0; dx < bw; dx++) {
        if (!isText[dy * bw + dx]) continue;
        for (let oy = -2; oy <= 2; oy++) {
          for (let ox = -2; ox <= 2; ox++) {
            const ny = dy + oy;
            const nx = dx + ox;
            if (ny >= 0 && ny < bh && nx >= 0 && nx < bw) {
              dilated[ny * bw + nx] = 1;
            }
          }
        }
      }
    }

    for (let dx = 0; dx < bw; dx++) {
      const x = x0 + dx;
      for (let dy = 0; dy < bh; dy++) {
        if (!dilated[dy * bw + dx]) continue;

        let topY = dy - 1;
        while (topY >= 0 && dilated[topY * bw + dx]) {
          topY--;
        }
        const sampleTopY = topY >= 0 ? y0 + topY : Math.max(0, y0 - 2);

        let botY = dy + 1;
        while (botY < bh && dilated[botY * bw + dx]) {
          botY++;
        }
        const sampleBotY = botY < bh ? y0 + botY : Math.min(height - 1, y1 + 2);

        const topIdx = (sampleTopY * width + x) * 4;
        const botIdx = (sampleBotY * width + x) * 4;

        const span = Math.max(1, sampleBotY - sampleTopY);
        const t = (y0 + dy - sampleTopY) / span;

        const outIdx = ((y0 + dy) * width + x) * 4;
        data[outIdx] = Math.round(data[topIdx] * (1 - t) + data[botIdx] * t);
        data[outIdx + 1] = Math.round(
          data[topIdx + 1] * (1 - t) + data[botIdx + 1] * t
        );
        data[outIdx + 2] = Math.round(
          data[topIdx + 2] * (1 - t) + data[botIdx + 2] * t
        );
      }
    }
  }

  ctx.putImageData(imageData, 0, 0);
  return canvas.toDataURL('image/png');
}

/**
 * Exports a crisp 2x (1440x2024) PNG of the edited business license.
 */
export async function exportLicensePng(params: {
  templateUrl: string;
  data: LicenseData;
  maskMode: MaskMode;
  qrMode: QrMode;
  qrDataUrl: string | null;
}): Promise<void> {
  const { templateUrl, data, maskMode, qrMode, qrDataUrl } = params;
  const scale = 2;

  const canvas = document.createElement('canvas');
  canvas.width = TEMPLATE_WIDTH * scale;
  canvas.height = TEMPLATE_HEIGHT * scale;

  const ctx = canvas.getContext('2d');
  if (!ctx) {
    throw new Error('Could not initialize export canvas');
  }

  ctx.scale(scale, scale);
  const bgImg = await loadImage(templateUrl);
  ctx.drawImage(bgImg, 0, 0, TEMPLATE_WIDTH, TEMPLATE_HEIGHT);

  for (const field of FIELD_OVERLAYS) {
    if (maskMode === 'opaque') {
      ctx.fillStyle = '#f5fcfd';
      ctx.fillRect(field.eraseX, field.eraseY, field.eraseW, field.eraseH);
    }

    const rawValue = data[field.key] ?? '';
    const displayText =
      field.key === 'blNo' ? `B.L. NO : ${rawValue}` : rawValue;

    ctx.fillStyle = field.color;
    ctx.font = `${field.fontWeight} ${field.fontSizePx}px "DM Sans", Arial, Helvetica, sans-serif`;
    ctx.textBaseline = 'middle';

    const centerY = field.y + field.h / 2 + 0.5;
    if (field.align === 'center') {
      ctx.textAlign = 'center';
      ctx.fillText(displayText, field.x + field.w / 2, centerY, field.w);
    } else {
      ctx.textAlign = 'left';
      ctx.fillText(displayText, field.x, centerY, field.w);
    }
  }

  if (qrMode === 'live' && qrDataUrl) {
    const qrImg = await loadImage(qrDataUrl);
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(QR_BOX.x, QR_BOX.y, QR_BOX.w, QR_BOX.h);
    const pad = 4;
    const size = Math.min(QR_BOX.w, QR_BOX.h) - pad * 2;
    const drawX = QR_BOX.x + (QR_BOX.w - size) / 2;
    const drawY = QR_BOX.y + (QR_BOX.h - size) / 2;
    ctx.drawImage(qrImg, drawX, drawY, size, size);
  }

  const sanitizedBl = (data.blNo || 'license')
    .trim()
    .replace(/[^a-zA-Z0-9_-]+/g, '_');

  const dataUrl = canvas.toDataURL('image/png');
  const link = document.createElement('a');
  link.download = `business-license-${sanitizedBl}.png`;
  link.href = dataUrl;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}

/**
 * Exports a crisp 2x (1440x2004) PNG of the edited Tanzania TIN Certificate.
 */
export async function exportTinPng(params: {
  templateUrl: string;
  data: TinData;
  maskMode: MaskMode;
  qrMode: QrMode;
  qrDataUrl: string | null;
}): Promise<void> {
  const { templateUrl, data, maskMode, qrMode, qrDataUrl } = params;
  const scale = 2;

  const canvas = document.createElement('canvas');
  canvas.width = TIN_TEMPLATE_WIDTH * scale;
  canvas.height = TIN_TEMPLATE_HEIGHT * scale;

  const ctx = canvas.getContext('2d');
  if (!ctx) {
    throw new Error('Could not initialize export canvas');
  }

  ctx.scale(scale, scale);
  const bgImg = await loadImage(templateUrl);
  ctx.drawImage(bgImg, 0, 0, TIN_TEMPLATE_WIDTH, TIN_TEMPLATE_HEIGHT);

  for (const field of TIN_FIELD_OVERLAYS) {
    if (maskMode === 'opaque') {
      ctx.fillStyle = '#fdfdfd';
      ctx.fillRect(field.eraseX, field.eraseY, field.eraseW, field.eraseH);
    }

    const displayText = data[field.key] ?? '';

    ctx.fillStyle = field.color;
    ctx.font = `${field.fontWeight} ${field.fontSizePx}px "DM Sans", Arial, Helvetica, sans-serif`;
    ctx.textBaseline = 'middle';

    const centerY = field.y + field.h / 2 + 0.5;
    if (field.align === 'center') {
      ctx.textAlign = 'center';
      ctx.fillText(displayText, field.x + field.w / 2, centerY, field.w);
    } else {
      ctx.textAlign = 'left';
      ctx.fillText(displayText, field.x, centerY, field.w);
    }
  }

  if (qrMode === 'live' && qrDataUrl) {
    const qrImg = await loadImage(qrDataUrl);
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(TIN_QR_BOX.x, TIN_QR_BOX.y, TIN_QR_BOX.w, TIN_QR_BOX.h);
    const pad = 2;
    const size = Math.min(TIN_QR_BOX.w, TIN_QR_BOX.h) - pad * 2;
    const drawX = TIN_QR_BOX.x + (TIN_QR_BOX.w - size) / 2;
    const drawY = TIN_QR_BOX.y + (TIN_QR_BOX.h - size) / 2;
    ctx.drawImage(qrImg, drawX, drawY, size, size);
  }

  const sanitizedTin = (data.tinNumber || 'tin')
    .trim()
    .replace(/[^a-zA-Z0-9_-]+/g, '_');

  const dataUrl = canvas.toDataURL('image/png');
  const link = document.createElement('a');
  link.download = `tin-certificate-${sanitizedTin}.png`;
  link.href = dataUrl;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}
