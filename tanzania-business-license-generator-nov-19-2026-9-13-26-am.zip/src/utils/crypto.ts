export function generateSaltHex(byteLength = 16): string {
  const bytes = new Uint8Array(byteLength);
  crypto.getRandomValues(bytes);
  return Array.from(bytes, (b) => b.toString(16).padStart(2, '0')).join('');
}

export async function hashPin(pin: string, salt: string): Promise<string> {
  const encoder = new TextEncoder();
  const payload = encoder.encode(`${salt}:${pin}`);
  const digest = await crypto.subtle.digest('SHA-256', payload);
  return Array.from(new Uint8Array(digest), (b) =>
    b.toString(16).padStart(2, '0')
  ).join('');
}

export async function verifyPin(
  pin: string,
  salt: string,
  expectedHash: string
): Promise<boolean> {
  const computed = await hashPin(pin, salt);
  return computed === expectedHash;
}

export function normalizePhone(phone: string): string {
  return phone.replace(/[\s\-()]/g, '').trim();
}

export function validateThreeNames(name: string): string | null {
  const cleaned = name.trim().replace(/\s+/g, ' ');
  if (cleaned.length < 5 || cleaned.length > 120) {
    return 'Majina yanapaswa kuwa na herufi kati ya 5 na 120.';
  }
  const parts = cleaned.split(' ').filter(Boolean);
  if (parts.length < 3) {
    return 'Tafadhali weka majina matatu kamili (mfano: Juma Hassan Mwinyi).';
  }
  return null;
}

export function validatePhone(phone: string): string | null {
  const trimmed = phone.trim();
  if (!/^[+0-9][0-9\s\-]{8,19}$/.test(trimmed)) {
    return 'Weka namba ya simu sahihi yenye tarakimu 9 hadi 15 (mfano: 0712345678).';
  }
  const digits = trimmed.replace(/\D/g, '');
  if (digits.length < 9 || digits.length > 15) {
    return 'Namba ya simu lazima iwe na tarakimu 9 hadi 15.';
  }
  return null;
}

export function validateFourDigitPin(pin: string): string | null {
  if (!/^\d{4}$/.test(pin)) {
    return 'Password (PIN) lazima iwe na tarakimu 4 pekee (mfano: 4829).';
  }
  return null;
}

export function maskPhone(phone: string): string {
  const clean = phone.trim();
  if (clean.length <= 4) return clean;
  return `${'*'.repeat(Math.max(3, clean.length - 4))}${clean.slice(-4)}`;
}
