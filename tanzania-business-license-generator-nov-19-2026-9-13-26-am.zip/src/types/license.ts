export interface LicenseData {
  blNo: string;
  issuingOffice: string;
  taxId: string;
  licensee: string;
  businessOf: string;
  licensingType: string;
  dateOfIssue: string;
  expiringDate: string;
  principalBranch: string;
  region: string;
  ward: string;
  street: string;
  feePaid: string;
}

export type LicenseFieldKey = keyof LicenseData;

export type MaskMode = 'seamless' | 'opaque';
export type QrMode = 'template' | 'live';
export type ZoomMode = 'fit' | '75' | '100' | '125';

export const TEMPLATE_WIDTH = 720;
export const TEMPLATE_HEIGHT = 1012;

export const TEMPLATE_IMAGE_PATH =
  '/assets/aistudio/Screenshot_20261118_224410_Files_by_Google__1__0e1821cd.jpg';

export const DEFAULT_LICENSE_DATA: LicenseData = {
  blNo: 'BL56027452026-2700002745',
  issuingOffice: 'MAGU DISTRICT COUNCIL',
  taxId: '855-588-555',
  licensee: 'HHG',
  businessOf: 'Electonic money transfer(UWAKALA)',
  licensingType: 'NEW LICENSE',
  dateOfIssue: '2026-11-08',
  expiringDate: '2027-11-07',
  principalBranch: 'BRANCH',
  region: 'Njij',
  ward: 'Magu',
  street: 'Kisesa',
  feePaid: '80,000.00',
};

export interface FieldOverlayBox {
  key: LicenseFieldKey;
  label: string;
  /** Native pixel coordinates in the 720x1012 template */
  x: number;
  y: number;
  w: number;
  h: number;
  /** Erase region (tightly around the original sample text) */
  eraseX: number;
  eraseY: number;
  eraseW: number;
  eraseH: number;
  eraseKind: 'dark' | 'teal';
  align: 'left' | 'center';
  color: string;
  fontSizePx: number;
  fontWeight: number;
}

export const FIELD_OVERLAYS: FieldOverlayBox[] = [
  {
    key: 'blNo',
    label: 'B.L. NO',
    x: 108,
    y: 211,
    w: 504,
    h: 22,
    eraseX: 206,
    eraseY: 211,
    eraseW: 308,
    eraseH: 22,
    eraseKind: 'teal',
    align: 'center',
    color: '#1e7395',
    fontSizePx: 14.5,
    fontWeight: 600,
  },
  {
    key: 'issuingOffice',
    label: 'Issuing Office',
    x: 263,
    y: 342,
    w: 395,
    h: 18,
    eraseX: 259,
    eraseY: 343,
    eraseW: 235,
    eraseH: 17,
    eraseKind: 'dark',
    align: 'left',
    color: '#182026',
    fontSizePx: 11.4,
    fontWeight: 500,
  },
  {
    key: 'taxId',
    label: 'Tax Identification No',
    x: 263,
    y: 372,
    w: 395,
    h: 18,
    eraseX: 259,
    eraseY: 373,
    eraseW: 235,
    eraseH: 17,
    eraseKind: 'dark',
    align: 'left',
    color: '#182026',
    fontSizePx: 11.4,
    fontWeight: 500,
  },
  {
    key: 'licensee',
    label: 'License Issued To',
    x: 263,
    y: 402,
    w: 395,
    h: 18,
    eraseX: 259,
    eraseY: 403,
    eraseW: 250,
    eraseH: 17,
    eraseKind: 'dark',
    align: 'left',
    color: '#182026',
    fontSizePx: 11.4,
    fontWeight: 500,
  },
  {
    key: 'businessOf',
    label: 'For the Business of',
    x: 263,
    y: 432,
    w: 395,
    h: 21,
    eraseX: 259,
    eraseY: 433,
    eraseW: 250,
    eraseH: 20,
    eraseKind: 'dark',
    align: 'left',
    color: '#182026',
    fontSizePx: 11.4,
    fontWeight: 500,
  },
  {
    key: 'licensingType',
    label: 'Business Licensing',
    x: 263,
    y: 463,
    w: 395,
    h: 18,
    eraseX: 259,
    eraseY: 464,
    eraseW: 235,
    eraseH: 17,
    eraseKind: 'dark',
    align: 'left',
    color: '#182026',
    fontSizePx: 11.4,
    fontWeight: 500,
  },
  {
    key: 'dateOfIssue',
    label: 'Date of Issue',
    x: 263,
    y: 493,
    w: 395,
    h: 18,
    eraseX: 259,
    eraseY: 494,
    eraseW: 235,
    eraseH: 17,
    eraseKind: 'dark',
    align: 'left',
    color: '#182026',
    fontSizePx: 11.4,
    fontWeight: 500,
  },
  {
    key: 'expiringDate',
    label: 'Expiring Date',
    x: 263,
    y: 523,
    w: 395,
    h: 18,
    eraseX: 259,
    eraseY: 524,
    eraseW: 235,
    eraseH: 17,
    eraseKind: 'dark',
    align: 'left',
    color: '#182026',
    fontSizePx: 11.4,
    fontWeight: 500,
  },
  {
    key: 'principalBranch',
    label: 'Principal/Branch',
    x: 263,
    y: 553,
    w: 395,
    h: 18,
    eraseX: 259,
    eraseY: 554,
    eraseW: 235,
    eraseH: 17,
    eraseKind: 'dark',
    align: 'left',
    color: '#182026',
    fontSizePx: 11.4,
    fontWeight: 500,
  },
  {
    key: 'region',
    label: 'Region',
    x: 256,
    y: 639,
    w: 202,
    h: 19,
    eraseX: 252,
    eraseY: 640,
    eraseW: 206,
    eraseH: 19,
    eraseKind: 'dark',
    align: 'left',
    color: '#182026',
    fontSizePx: 11.4,
    fontWeight: 500,
  },
  {
    key: 'ward',
    label: 'Ward',
    x: 256,
    y: 669,
    w: 202,
    h: 19,
    eraseX: 252,
    eraseY: 670,
    eraseW: 206,
    eraseH: 19,
    eraseKind: 'dark',
    align: 'left',
    color: '#182026',
    fontSizePx: 11.4,
    fontWeight: 500,
  },
  {
    key: 'street',
    label: 'Street',
    x: 256,
    y: 699,
    w: 202,
    h: 18,
    eraseX: 252,
    eraseY: 700,
    eraseW: 206,
    eraseH: 17,
    eraseKind: 'dark',
    align: 'left',
    color: '#182026',
    fontSizePx: 11.4,
    fontWeight: 500,
  },
  {
    key: 'feePaid',
    label: 'Amount of Fee Paid',
    x: 256,
    y: 788,
    w: 320,
    h: 19,
    eraseX: 252,
    eraseY: 789,
    eraseW: 206,
    eraseH: 18,
    eraseKind: 'dark',
    align: 'left',
    color: '#161f26',
    fontSizePx: 11.6,
    fontWeight: 700,
  },
];

export const QR_BOX = {
  x: 468,
  y: 609,
  w: 160,
  h: 169,
};
