export interface TinData {
  taxpayerName: string;
  tinNumber: string;
  effectiveFrom: string;
  traLocation: string;
  taxOffice: string;
  physicalLocation: string;
  streetArea: string;
}

export type TinFieldKey = keyof TinData;

export const TIN_TEMPLATE_WIDTH = 720;
export const TIN_TEMPLATE_HEIGHT = 1002;

export const TIN_TEMPLATE_IMAGE_PATH =
  '/assets/aistudio/Screenshot_20261109_194804_Files_by_Google__2__a9a1539b.jpg';

export const DEFAULT_TIN_DATA: TinData = {
  taxpayerName: 'MERANIA JUMA MABIHO',
  tinNumber: '212-534-307',
  effectiveFrom: '9th November 2026',
  traLocation: 'GEITA',
  taxOffice: 'RUZENWE TAX CENTRE',
  physicalLocation: 'NAMONGE',
  streetArea: 'MUHAMA',
};

export interface TinOverlayBox {
  key: TinFieldKey;
  label: string;
  x: number;
  y: number;
  w: number;
  h: number;
  eraseX: number;
  eraseY: number;
  eraseW: number;
  eraseH: number;
  eraseKind: 'dark' | 'teal';
  align: 'left' | 'center';
  color: string;
  fontSizePx: number;
  fontWeight: number;
  letterSpacing?: string;
}

export const TIN_FIELD_OVERLAYS: TinOverlayBox[] = [
  {
    key: 'taxpayerName',
    label: 'Taxpayer Name',
    x: 96,
    y: 446,
    w: 528,
    h: 22,
    eraseX: 140,
    eraseY: 447,
    eraseW: 440,
    eraseH: 19,
    eraseKind: 'dark',
    align: 'center',
    color: '#111827',
    fontSizePx: 12.5,
    fontWeight: 700,
  },
  {
    key: 'tinNumber',
    label: 'TIN Number',
    x: 180,
    y: 578,
    w: 360,
    h: 22,
    eraseX: 240,
    eraseY: 579,
    eraseW: 240,
    eraseH: 19,
    eraseKind: 'dark',
    align: 'center',
    color: '#111827',
    fontSizePx: 13.5,
    fontWeight: 700,
    letterSpacing: '0.4px',
  },
  {
    key: 'effectiveFrom',
    label: 'Effective From',
    x: 267,
    y: 622,
    w: 310,
    h: 21,
    eraseX: 260,
    eraseY: 620,
    eraseW: 280,
    eraseH: 23,
    eraseKind: 'dark',
    align: 'left',
    color: '#111827',
    fontSizePx: 11.6,
    fontWeight: 700,
  },
  {
    key: 'traLocation',
    label: 'TRA Location',
    x: 231,
    y: 662,
    w: 150,
    h: 19,
    eraseX: 226,
    eraseY: 662,
    eraseW: 155,
    eraseH: 18,
    eraseKind: 'dark',
    align: 'left',
    color: '#111827',
    fontSizePx: 11.3,
    fontWeight: 700,
  },
  {
    key: 'taxOffice',
    label: 'Tax Office',
    x: 476,
    y: 662,
    w: 148,
    h: 19,
    eraseX: 471,
    eraseY: 662,
    eraseW: 151,
    eraseH: 18,
    eraseKind: 'dark',
    align: 'left',
    color: '#111827',
    fontSizePx: 11.1,
    fontWeight: 700,
  },
  {
    key: 'physicalLocation',
    label: 'Physical Location',
    x: 276,
    y: 692,
    w: 225,
    h: 19,
    eraseX: 270,
    eraseY: 692,
    eraseW: 230,
    eraseH: 18,
    eraseKind: 'dark',
    align: 'left',
    color: '#111827',
    fontSizePx: 11.3,
    fontWeight: 700,
  },
  {
    key: 'streetArea',
    label: 'Street / Area',
    x: 239,
    y: 722,
    w: 245,
    h: 19,
    eraseX: 233,
    eraseY: 722,
    eraseW: 250,
    eraseH: 18,
    eraseKind: 'dark',
    align: 'left',
    color: '#111827',
    fontSizePx: 11.3,
    fontWeight: 700,
  },
];

export const TIN_QR_BOX = {
  x: 536,
  y: 93,
  w: 64,
  h: 64,
};
