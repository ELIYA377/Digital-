import { Timestamp } from 'firebase/firestore';
import { LicenseData, MaskMode, QrMode } from './license';
import { TinData } from './tin';

export type ServiceKey =
  | 'editor'
  | 'exportPng'
  | 'printPdf'
  | 'liveQr'
  | 'saveRecords'
  | 'tinCertificate';

export interface UserServices {
  editor: boolean;
  exportPng: boolean;
  printPdf: boolean;
  liveQr: boolean;
  saveRecords: boolean;
  tinCertificate?: boolean;
}

export interface UserProfile {
  uid: string;
  fullName: string;
  phone: string;
  email: string;
  pinHash: string;
  pinSalt: string;
  role: 'user' | 'admin';
  accountStatus: 'active' | 'suspended';
  coins: number;
  services: UserServices;
  createdAt?: Timestamp;
  updatedAt?: Timestamp;
}

export interface CoinCosts {
  exportPng: number;
  printPdf: number;
  liveQr: number;
  saveRecord: number;
}

export const DEFAULT_COIN_COSTS: CoinCosts = {
  exportPng: 10,
  printPdf: 10,
  liveQr: 5,
  saveRecord: 2,
};

export interface SavedLicenseRecord extends LicenseData {
  id: string;
  ownerId: string;
  maskMode: MaskMode;
  qrMode: QrMode;
  createdAt?: Timestamp;
  updatedAt?: Timestamp;
}

export interface SavedTinRecord extends TinData {
  id: string;
  ownerId: string;
  maskMode: MaskMode;
  qrMode: QrMode;
  createdAt?: Timestamp;
  updatedAt?: Timestamp;
}

export interface CoinTransactionRecord {
  id: string;
  userId: string;
  type: 'topup' | 'deduct' | 'spend';
  amount: number;
  balanceAfter: number;
  service:
    | 'admin_adjustment'
    | 'exportPng'
    | 'printPdf'
    | 'liveQr'
    | 'saveRecord';
  note: string;
  createdBy: string;
  createdAt?: Timestamp;
}

export interface ServiceDefinition {
  key: ServiceKey;
  label: string;
  subtitle: string;
  costKey?: keyof CoinCosts;
}

export const SERVICE_DEFINITIONS: ServiceDefinition[] = [
  {
    key: 'editor',
    label: 'Hariri Leseni (License Editor)',
    subtitle: 'Ruhusa ya kujaza na kubadilisha taarifa kwenye fomu ya leseni.',
  },
  {
    key: 'tinCertificate',
    label: 'Cheti cha TIN (TIN Certificate)',
    subtitle: 'Ruhusa ya kutumia na kuhariri mfumo wa Cheti cha TIN (TRA).',
  },
  {
    key: 'exportPng',
    label: 'Pakua PNG (Export PNG)',
    subtitle: 'Ruhusa ya kupakua picha ya nyaraka yenye ubora wa juu.',
    costKey: 'exportPng',
  },
  {
    key: 'printPdf',
    label: 'Chapisha / PDF (Print A4)',
    subtitle: 'Ruhusa ya kuchapisha au kuhifadhi nakala ya A4 PDF.',
    costKey: 'printPdf',
  },
  {
    key: 'liveQr',
    label: 'QR Code Hai (Live Dynamic QR)',
    subtitle: 'Ruhusa ya kuzalisha QR code mpya yenye taarifa za nyaraka.',
    costKey: 'liveQr',
  },
  {
    key: 'saveRecords',
    label: 'Hifadhi Kumbukumbu (Cloud Records)',
    subtitle: 'Ruhusa ya kuhifadhi na kufungua nyaraka kwenye vifaa vingine.',
    costKey: 'saveRecord',
  },
];

export const EMPTY_SERVICES: UserServices = {
  editor: false,
  exportPng: false,
  printPdf: false,
  liveQr: false,
  saveRecords: false,
  tinCertificate: false,
};

export const ALL_ENABLED_SERVICES: UserServices = {
  editor: true,
  exportPng: true,
  printPdf: true,
  liveQr: true,
  saveRecords: true,
  tinCertificate: true,
};
