import React from 'react';
import {
  ArrowRight,
  BadgeCheck,
  Coins,
  FileText,
  FolderOpen,
  Lock,
  ShieldCheck,
} from 'lucide-react';
import { CoinCosts, UserProfile } from '../types/account';

interface ToolsHubProps {
  profile: UserProfile;
  isAdmin: boolean;
  coinCosts: CoinCosts;
  licenseCount: number;
  tinCount: number;
  onOpenTool: (tab: 'editor' | 'tin' | 'records' | 'admin') => void;
}

export const ToolsHub: React.FC<ToolsHubProps> = ({
  profile,
  isAdmin,
  coinCosts,
  licenseCount,
  tinCount,
  onOpenTool,
}) => {
  const canLicense = isAdmin || Boolean(profile.services?.editor);
  const canTin = isAdmin || Boolean(profile.services?.tinCertificate);
  const canSave = isAdmin || Boolean(profile.services?.saveRecords);

  return (
    <main className="flex-1 overflow-y-auto bg-[#f4f6f8] p-6 lg:p-10">
      <div className="max-w-5xl mx-auto space-y-8">
        {/* Welcome & Account Summary */}
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 border-b border-slate-200 pb-6">
          <div className="space-y-1">
            <p className="text-xs font-medium text-[#0f4c75]">
              Mfumo wa Nyaraka · Tanzania
            </p>
            <h2 className="font-display text-2xl font-semibold text-slate-900 tracking-tight">
              Chagua Tool ya Kutumia
            </h2>
            <div className="flex flex-wrap items-center gap-2 text-xs text-slate-500 pt-0.5">
              <span className="font-medium text-slate-700">
                {profile.fullName}
              </span>
              <span aria-hidden="true">·</span>
              <span className="font-mono-tabular">{profile.phone}</span>
              <span aria-hidden="true">·</span>
              <span>{isAdmin ? 'Admin' : 'Mtumiaji'}</span>
            </div>
          </div>

          <div className="bg-white border border-slate-200 rounded-lg px-4 py-2.5 flex items-center gap-2.5 self-start sm:self-auto">
            <Coins className="w-4 h-4 text-amber-600" aria-hidden="true" />
            <div>
              <p className="text-[11px] text-slate-500 leading-none">
                Salio Lako
              </p>
              <p className="text-base font-semibold font-mono-tabular text-slate-900 mt-0.5">
                {profile.coins.toLocaleString()} Coins
              </p>
            </div>
          </div>
        </div>

        {/* Separated Primary Document Tools */}
        <section aria-labelledby="heading-document-tools" className="space-y-4">
          <h3
            id="heading-document-tools"
            className="text-sm font-semibold text-slate-800"
          >
            Tools za Nyaraka
          </h3>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Tool 1: Tanzania Business License Generator */}
            <div className="bg-white border border-slate-200 rounded-xl p-6 flex flex-col justify-between gap-6">
              <div className="space-y-3">
                <div className="flex items-center justify-between gap-3">
                  <div className="w-10 h-10 rounded-lg bg-[#0f4c75]/10 text-[#0f4c75] flex items-center justify-center shrink-0">
                    <FileText className="w-5 h-5" aria-hidden="true" />
                  </div>
                  <span
                    className={`text-xs font-medium ${
                      canLicense ? 'text-emerald-700' : 'text-amber-700'
                    }`}
                  >
                    {canLicense ? 'Imewashwa' : 'Imefungwa na Admin'}
                  </span>
                </div>

                <div className="space-y-1">
                  <h4 className="font-display text-lg font-semibold text-slate-900">
                    Business License Generator
                  </h4>
                  <p className="text-sm text-slate-600 leading-relaxed">
                    Andaa, hariri, na uchapishe Leseni ya Biashara ya Tanzania
                    yenye QR code na watermark asilia.
                  </p>
                </div>

                <div className="flex flex-wrap items-center gap-2 text-xs text-slate-500 pt-1">
                  <span className="font-mono-tabular">
                    PNG: {coinCosts.exportPng} Coins
                  </span>
                  <span aria-hidden="true">·</span>
                  <span className="font-mono-tabular">
                    Print: {coinCosts.printPdf} Coins
                  </span>
                  <span aria-hidden="true">·</span>
                  <span className="font-mono-tabular">
                    Zilizohifadhiwa: {licenseCount}
                  </span>
                </div>
              </div>

              <button
                type="button"
                onClick={() => onOpenTool('editor')}
                className={`w-full inline-flex items-center justify-center gap-2 px-4 py-2.5 text-sm font-medium rounded-lg transition-colors ${
                  canLicense
                    ? 'text-white bg-[#0f4c75] hover:bg-[#0b3a5b]'
                    : 'text-slate-700 bg-slate-100 hover:bg-slate-200'
                }`}
              >
                {!canLicense && <Lock className="w-4 h-4" aria-hidden="true" />}
                Fungua Business License
                <ArrowRight className="w-4 h-4" aria-hidden="true" />
              </button>
            </div>

            {/* Tool 2: Tanzania TIN Certificate Generator */}
            <div className="bg-white border border-slate-200 rounded-xl p-6 flex flex-col justify-between gap-6">
              <div className="space-y-3">
                <div className="flex items-center justify-between gap-3">
                  <div className="w-10 h-10 rounded-lg bg-[#2f6f3e]/10 text-[#2f6f3e] flex items-center justify-center shrink-0">
                    <BadgeCheck className="w-5 h-5" aria-hidden="true" />
                  </div>
                  <span
                    className={`text-xs font-medium ${
                      canTin ? 'text-emerald-700' : 'text-amber-700'
                    }`}
                  >
                    {canTin ? 'Imewashwa' : 'Imefungwa na Admin'}
                  </span>
                </div>

                <div className="space-y-1">
                  <h4 className="font-display text-lg font-semibold text-slate-900">
                    TIN Certificate Generator
                  </h4>
                  <p className="text-sm text-slate-600 leading-relaxed">
                    Tengeneza, hariri, na pakua Cheti cha Usajili wa Mlipakodi
                    (TIN - TRA) kikiwa na mpangilio halisi.
                  </p>
                </div>

                <div className="flex flex-wrap items-center gap-2 text-xs text-slate-500 pt-1">
                  <span className="font-mono-tabular">
                    PNG: {coinCosts.exportPng} Coins
                  </span>
                  <span aria-hidden="true">·</span>
                  <span className="font-mono-tabular">
                    Print: {coinCosts.printPdf} Coins
                  </span>
                  <span aria-hidden="true">·</span>
                  <span className="font-mono-tabular">
                    Zilizohifadhiwa: {tinCount}
                  </span>
                </div>
              </div>

              <button
                type="button"
                onClick={() => onOpenTool('tin')}
                className={`w-full inline-flex items-center justify-center gap-2 px-4 py-2.5 text-sm font-medium rounded-lg transition-colors ${
                  canTin
                    ? 'text-white bg-[#2f6f3e] hover:bg-[#245630]'
                    : 'text-slate-700 bg-slate-100 hover:bg-slate-200'
                }`}
              >
                {!canTin && <Lock className="w-4 h-4" aria-hidden="true" />}
                Fungua TIN Certificate
                <ArrowRight className="w-4 h-4" aria-hidden="true" />
              </button>
            </div>
          </div>
        </section>

        {/* Management & Records Tools */}
        <section aria-labelledby="heading-system-tools" className="space-y-4">
          <h3
            id="heading-system-tools"
            className="text-sm font-semibold text-slate-800"
          >
            Kumbukumbu na Usimamizi
          </h3>

          <div
            className={`grid grid-cols-1 ${
              isAdmin ? 'md:grid-cols-2' : ''
            } gap-6`}
          >
            {/* Saved Records & Coin History */}
            <div className="bg-white border border-slate-200 rounded-xl p-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div className="flex items-start gap-3.5">
                <div className="w-10 h-10 rounded-lg bg-slate-100 text-slate-700 flex items-center justify-center shrink-0">
                  <FolderOpen className="w-5 h-5" aria-hidden="true" />
                </div>
                <div className="space-y-1">
                  <h4 className="font-display text-base font-semibold text-slate-900">
                    Kumbukumbu Zilizohifadhiwa
                  </h4>
                  <p className="text-xs text-slate-600">
                    Leseni {licenseCount} · Vyeti vya TIN {tinCount} ·{' '}
                    {canSave ? 'Cloud Sync Hai' : 'Cloud Sync Imefungwa'}
                  </p>
                </div>
              </div>

              <button
                type="button"
                onClick={() => onOpenTool('records')}
                className="inline-flex items-center justify-center gap-1.5 px-4 py-2 text-xs font-medium text-slate-800 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors whitespace-nowrap shrink-0"
              >
                Fungua Kumbukumbu
                <ArrowRight className="w-3.5 h-3.5" aria-hidden="true" />
              </button>
            </div>

            {/* Admin Control Panel (Admin only) */}
            {isAdmin && (
              <div className="bg-white border border-slate-200 rounded-xl p-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div className="flex items-start gap-3.5">
                  <div className="w-10 h-10 rounded-lg bg-[#0f4c75]/10 text-[#0f4c75] flex items-center justify-center shrink-0">
                    <ShieldCheck className="w-5 h-5" aria-hidden="true" />
                  </div>
                  <div className="space-y-1">
                    <h4 className="font-display text-base font-semibold text-slate-900">
                      Admin Control Panel
                    </h4>
                    <p className="text-xs text-slate-600">
                      Washa huduma moja moja kwa kila user na dhibiti coin.
                    </p>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={() => onOpenTool('admin')}
                  className="inline-flex items-center justify-center gap-1.5 px-4 py-2 text-xs font-medium text-white bg-[#0f4c75] hover:bg-[#0b3a5b] rounded-lg transition-colors whitespace-nowrap shrink-0"
                >
                  Fungua Admin Panel
                  <ArrowRight className="w-3.5 h-3.5" aria-hidden="true" />
                </button>
              </div>
            )}
          </div>
        </section>
      </div>
    </main>
  );
};
