# Security Specification & Dirty Dozen Payloads

## Data Invariants
1. A `UserProfile` at `/users/{userId}` can only be created by the authenticated, email-verified owner (`request.auth.uid == userId`), and MUST initialize with `role: 'user'`, `coins: 0`, `accountStatus: 'active'`, and all five `services` flags set to `false` (unless created by a verified Admin).
2. A regular user can NEVER read or list another user's `UserProfile` (protecting PII such as `phone`, `email`, `pinHash`, and `pinSalt`). Only `isOwner(userId)` or `isAdmin()` may read `/users/{userId}`, and only `isAdmin()` may `list` `/users`.
3. A regular user can NEVER increase their own `coins`, toggle their own `services`, change `role`, or reactivate a `suspended` account. User updates are strictly split into Profile Update (`fullName`, `phone`, `pinHash`, `pinSalt`, `updatedAt`) and Coin Spend (`coins < existing().coins` and `coins >= 0`).
4. Every write to `/users/{userId}/licenses/{licenseId}` enforces the Master Gate on `/users/{userId}`: the parent user must be `active` and have `services.saveRecords == true` (unless `isAdmin()`).
5. Every `spend` entry in `/users/{userId}/coinTransactions/{txId}` enforces `getAfter()` atomicity against `/users/{userId}` so the logged `amount` equals the exact coin balance reduction.
6. `createdAt` and `updatedAt` timestamps must match `request.time`.

## The "Dirty Dozen" Payloads (Expected: PERMISSION_DENIED)
1. **Self-Assigned Admin Role on Registration**: Create `/users/userA` with `role: 'admin'`.
2. **Free Coin Minting on Registration**: Create `/users/userA` with `coins: 5000`.
3. **Self-Enabling Services on Registration**: Create `/users/userA` with `services.exportPng: true`.
4. **Coin Balance Inflation via Update**: Update `/users/userA` setting `coins: existing.coins + 100` as `userA`.
5. **Service Flag Escalation via Update**: Update `/users/userA` setting `services.printPdf: true` as `userA`.
6. **Shadow Ghost Field Injection**: Create or update `/users/userA` with extra key `isSuperUser: true`.
7. **Cross-User PII Read / List Scraping**: `get` `/users/userB` or `list` `/users` as non-admin `userA`.
8. **Unverified Email Spoof**: Attempt write with `token.email = 'salesdigital181@gmail.com'` and `token.email_verified = false`.
9. **Path ID Poisoning**: Create `/users/userA/licenses/bad$id` or 200-char ID string.
10. **Bypassing Disabled `saveRecords` Permission**: Create `/users/userA/licenses/lic1` when `services.saveRecords == false`.
11. **Forged Coin Spend Transaction Without Balance Deduction**: Create `/users/userA/coinTransactions/tx1` with `type: 'spend'` without atomically decrementing `/users/userA.coins`.
12. **Client Timestamp Forgery**: Create `/users/userA/licenses/lic1` with `createdAt` set to a past timestamp instead of `request.time`.
