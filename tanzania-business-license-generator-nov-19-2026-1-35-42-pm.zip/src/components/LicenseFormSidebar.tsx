import React, { useState } from 'react';
import { CloudUpload, Download, Eraser, Lock, RotateCcw } from 'lucide-react';
import {
  LicenseData,
  LicenseFieldKey,
  MaskMode,
  QrMode,
} from '../types/license';
import { CoinCosts, UserProfile } from '../types/account';

interface LicenseFormSidebarProps {
  data: LicenseData;
  profile: UserProfile;
  isAdmin: boolean;
  coinCosts: CoinCosts;
  activeField: LicenseFieldKey | null;
  maskMode: MaskMode;
  qrMode: QrMode;
  editingLicenseId: string | null;
  isSavingRecord: boolean;
  isExporting: boolean;
  onChangeField: (key: LicenseFieldKey, value: string) => void;
  onFocusField: (key: LicenseFieldKey | null) => void;
  onChangeMaskMode: (mode: MaskMode) => void;
  onRequestQrMode: (mode: QrMode) => void;
  onSaveToCloud: () => void;
  onDownload: () => void;
  onResetDefaults: () => void;
  onClearFields: () => void;
  registerInputRef: (
    key: LicenseFieldKey,
    el: HTMLInputElement | HTMLSelectElement | null
  ) => void;
}

interface FieldInputConfig {
  key: LicenseFieldKey;
  label: string;
  placeholder: string;
  mono?: boolean;
  kind?: 'text' | 'select' | 'date';
  options?: { value: string; label: string }[];
}

const BUSINESS_ACTIVITY_OPTIONS: { value: string; label: string }[] = [
  {
    value: 'Electonic money transfer(UWAKALA)',
    label: 'Electonic money transfer(UWAKALA)',
  },
  {
    value: 'Electronic money transfer (UWAKALA)',
    label: 'Electronic money transfer (UWAKALA)',
  },
  {
    value: 'Mobile Money & Banking Agent (Wakala wa Fedha)',
    label: 'Mobile Money & Banking Agent (Wakala wa Fedha)',
  },
  {
    value: 'Retail Shop (Duka la Rejareja)',
    label: 'Retail Shop (Duka la Rejareja)',
  },
  {
    value: 'Wholesale Trade (Biashara ya Jumla)',
    label: 'Wholesale Trade (Biashara ya Jumla)',
  },
  {
    value: 'Mini Supermarket & General Merchandise',
    label: 'Mini Supermarket & General Merchandise',
  },
  {
    value: 'Pharmacy / Medical Store (Duka la Dawa)',
    label: 'Pharmacy / Medical Store (Duka la Dawa)',
  },
  {
    value: 'Hardware & Building Materials (Vifaa vya Ujenzi)',
    label: 'Hardware & Building Materials (Vifaa vya Ujenzi)',
  },
  {
    value: 'Electronics & Phone Accessories (Vifaa vya Simu na Umeme)',
    label: 'Electronics & Phone Accessories (Vifaa vya Simu na Umeme)',
  },
  {
    value: 'Stationery & Secretarial Services',
    label: 'Stationery & Secretarial Services',
  },
  {
    value: 'Boutique & Clothing Shop (Duka la Nguo)',
    label: 'Boutique & Clothing Shop (Duka la Nguo)',
  },
  {
    value: 'Cosmetics & Salon (Vipodozi na Saluni)',
    label: 'Cosmetics & Salon (Vipodozi na Saluni)',
  },
  {
    value: 'Restaurant & Food Vendor (Mgahawa)',
    label: 'Restaurant & Food Vendor (Mgahawa)',
  },
  {
    value: 'Agrovet & Agricultural Inputs (Pembejeo za Kilimo)',
    label: 'Agrovet & Agricultural Inputs (Pembejeo za Kilimo)',
  },
  {
    value: 'Spare Parts & Garage (Vipuri na Matengenezo)',
    label: 'Spare Parts & Garage (Vipuri na Matengenezo)',
  },
  {
    value: 'Transport & Logistics (Usafirishaji)',
    label: 'Transport & Logistics (Usafirishaji)',
  },
  {
    value: 'Consultancy & Professional Services',
    label: 'Consultancy & Professional Services',
  },
];

const LICENSING_TYPE_OPTIONS: { value: string; label: string }[] = [
  { value: 'NEW LICENSE', label: 'NEW LICENSE' },
  { value: 'RENEWAL', label: 'RENEWAL' },
  { value: 'DUPLICATE', label: 'DUPLICATE' },
  { value: 'CHANGE OF NAME', label: 'CHANGE OF NAME' },
  { value: 'CHANGE OF LOCATION', label: 'CHANGE OF LOCATION' },
  { value: 'TRANSFER OF LICENSE', label: 'TRANSFER OF LICENSE' },
];

const PRINCIPAL_BRANCH_OPTIONS: { value: string; label: string }[] = [
  { value: 'BRANCH', label: 'BRANCH' },
  { value: 'PRINCIPAL', label: 'PRINCIPAL' },
  { value: 'HEAD OFFICE', label: 'HEAD OFFICE' },
];

const ISSUING_OFFICE_OPTIONS: { value: string; label: string }[] = [
  { value: 'MAGU DISTRICT COUNCIL', label: 'MAGU DISTRICT COUNCIL' },
  { value: 'BRELA (MINISTRY OF INDUSTRY AND TRADE)', label: 'BRELA (MINISTRY OF INDUSTRY AND TRADE)' },
  { value: 'DAR ES SALAAM CITY COUNCIL', label: 'DAR ES SALAAM CITY COUNCIL' },
  { value: 'ILALA MUNICIPAL COUNCIL', label: 'ILALA MUNICIPAL COUNCIL' },
  { value: 'KINONDONI MUNICIPAL COUNCIL', label: 'KINONDONI MUNICIPAL COUNCIL' },
  { value: 'TEMEKE MUNICIPAL COUNCIL', label: 'TEMEKE MUNICIPAL COUNCIL' },
  { value: 'UBUNGO MUNICIPAL COUNCIL', label: 'UBUNGO MUNICIPAL COUNCIL' },
  { value: 'KIGAMBONI MUNICIPAL COUNCIL', label: 'KIGAMBONI MUNICIPAL COUNCIL' },
  { value: 'MWANZA CITY COUNCIL', label: 'MWANZA CITY COUNCIL' },
  { value: 'ILEMELA MUNICIPAL COUNCIL', label: 'ILEMELA MUNICIPAL COUNCIL' },
  { value: 'SENGEREMA DISTRICT COUNCIL', label: 'SENGEREMA DISTRICT COUNCIL' },
  { value: 'MISUNGWI DISTRICT COUNCIL', label: 'MISUNGWI DISTRICT COUNCIL' },
  { value: 'KWIMBA DISTRICT COUNCIL', label: 'KWIMBA DISTRICT COUNCIL' },
  { value: 'UKEREWE DISTRICT COUNCIL', label: 'UKEREWE DISTRICT COUNCIL' },
  { value: 'BUCHOSA DISTRICT COUNCIL', label: 'BUCHOSA DISTRICT COUNCIL' },
  { value: 'ARUSHA CITY COUNCIL', label: 'ARUSHA CITY COUNCIL' },
  { value: 'ARUSHA DISTRICT COUNCIL', label: 'ARUSHA DISTRICT COUNCIL' },
  { value: 'MERU DISTRICT COUNCIL', label: 'MERU DISTRICT COUNCIL' },
  { value: 'DODOMA CITY COUNCIL', label: 'DODOMA CITY COUNCIL' },
  { value: 'MBEYA CITY COUNCIL', label: 'MBEYA CITY COUNCIL' },
  { value: 'TANGA CITY COUNCIL', label: 'TANGA CITY COUNCIL' },
  { value: 'MOROGORO MUNICIPAL COUNCIL', label: 'MOROGORO MUNICIPAL COUNCIL' },
  { value: 'MOSHI MUNICIPAL COUNCIL', label: 'MOSHI MUNICIPAL COUNCIL' },
  { value: 'KAHAMA MUNICIPAL COUNCIL', label: 'KAHAMA MUNICIPAL COUNCIL' },
  { value: 'SHINYANGA MUNICIPAL COUNCIL', label: 'SHINYANGA MUNICIPAL COUNCIL' },
  { value: 'GEITA TOWN COUNCIL', label: 'GEITA TOWN COUNCIL' },
  { value: 'GEITA DISTRICT COUNCIL', label: 'GEITA DISTRICT COUNCIL' },
  { value: 'CHATO DISTRICT COUNCIL', label: 'CHATO DISTRICT COUNCIL' },
  { value: 'BUKOBA MUNICIPAL COUNCIL', label: 'BUKOBA MUNICIPAL COUNCIL' },
  { value: 'MUSOMA MUNICIPAL COUNCIL', label: 'MUSOMA MUNICIPAL COUNCIL' },
  { value: 'TARIME TOWN COUNCIL', label: 'TARIME TOWN COUNCIL' },
  { value: 'BARIADI TOWN COUNCIL', label: 'BARIADI TOWN COUNCIL' },
  { value: 'TABORA MUNICIPAL COUNCIL', label: 'TABORA MUNICIPAL COUNCIL' },
  { value: 'KIGOMA UJIJI MUNICIPAL COUNCIL', label: 'KIGOMA UJIJI MUNICIPAL COUNCIL' },
  { value: 'IRINGA MUNICIPAL COUNCIL', label: 'IRINGA MUNICIPAL COUNCIL' },
  { value: 'SINGIDA MUNICIPAL COUNCIL', label: 'SINGIDA MUNICIPAL COUNCIL' },
  { value: 'SONGEA MUNICIPAL COUNCIL', label: 'SONGEA MUNICIPAL COUNCIL' },
  { value: 'MTWARA MIKINDANI MUNICIPAL COUNCIL', label: 'MTWARA MIKINDANI MUNICIPAL COUNCIL' },
  { value: 'LINDI MUNICIPAL COUNCIL', label: 'LINDI MUNICIPAL COUNCIL' },
  { value: 'SUMBAWANGA MUNICIPAL COUNCIL', label: 'SUMBAWANGA MUNICIPAL COUNCIL' },
  { value: 'NJOMBE TOWN COUNCIL', label: 'NJOMBE TOWN COUNCIL' },
  { value: 'MPANDA MUNICIPAL COUNCIL', label: 'MPANDA MUNICIPAL COUNCIL' },
  { value: 'BABATI TOWN COUNCIL', label: 'BABATI TOWN COUNCIL' },
  { value: 'KIBAHA TOWN COUNCIL', label: 'KIBAHA TOWN COUNCIL' },
];

const FEE_PAID_OPTIONS: { value: string; label: string }[] = [
  { value: '20,000.00', label: '20,000.00 TZS' },
  { value: '30,000.00', label: '30,000.00 TZS' },
  { value: '50,000.00', label: '50,000.00 TZS' },
  { value: '60,000.00', label: '60,000.00 TZS' },
  { value: '80,000.00', label: '80,000.00 TZS' },
  { value: '100,000.00', label: '100,000.00 TZS' },
  { value: '120,000.00', label: '120,000.00 TZS' },
  { value: '150,000.00', label: '150,000.00 TZS' },
  { value: '200,000.00', label: '200,000.00 TZS' },
  { value: '250,000.00', label: '250,000.00 TZS' },
  { value: '300,000.00', label: '300,000.00 TZS' },
  { value: '500,000.00', label: '500,000.00 TZS' },
  { value: '1,000,000.00', label: '1,000,000.00 TZS' },
];

function getTodayIso(): string {
  const d = new Date();
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${y}-${m}-${day}`;
}

function computeExpiryIso(issueIso: string, months: number): string {
  const base = /^\d{4}-\d{2}-\d{2}$/.test(issueIso)
    ? new Date(`${issueIso}T00:00:00`)
    : new Date();
  const next = new Date(base);
  next.setMonth(next.getMonth() + months);
  next.setDate(next.getDate() - 1);
  const y = next.getFullYear();
  const m = String(next.getMonth() + 1).padStart(2, '0');
  const day = String(next.getDate()).padStart(2, '0');
  return `${y}-${m}-${day}`;
}

const LICENSE_DETAIL_FIELDS: FieldInputConfig[] = [
  {
    key: 'blNo',
    label: 'B.L. NO',
    placeholder: 'BL56027452026-2700002745',
    mono: true,
  },
  {
    key: 'issuingOffice',
    label: 'Issuing Office',
    placeholder: 'Andika jina la ofisi / halmashauri...',
    kind: 'select',
    options: ISSUING_OFFICE_OPTIONS,
  },
  {
    key: 'taxId',
    label: 'Tax Identification No',
    placeholder: '855-588-555',
    mono: true,
  },
  {
    key: 'licensee',
    label: 'License Issued To',
    placeholder: 'Business or Owner Name',
  },
  {
    key: 'businessOf',
    label: 'For the Business of',
    placeholder: 'Chagua au andika biashara...',
    kind: 'select',
    options: BUSINESS_ACTIVITY_OPTIONS,
  },
  {
    key: 'licensingType',
    label: 'Business Licensing',
    placeholder: 'NEW LICENSE',
    kind: 'select',
    options: LICENSING_TYPE_OPTIONS,
  },
  {
    key: 'dateOfIssue',
    label: 'Date of Issue',
    placeholder: 'YYYY-MM-DD',
    mono: true,
    kind: 'date',
  },
  {
    key: 'expiringDate',
    label: 'Expiring Date',
    placeholder: 'YYYY-MM-DD',
    mono: true,
    kind: 'date',
  },
  {
    key: 'principalBranch',
    label: 'Principal / Branch',
    placeholder: 'BRANCH',
    kind: 'select',
    options: PRINCIPAL_BRANCH_OPTIONS,
  },
];

const LOCATION_FIELDS: FieldInputConfig[] = [
  { key: 'region', label: 'Region', placeholder: 'e.g. Mwanza' },
  { key: 'ward', label: 'Ward', placeholder: 'e.g. Magu' },
  { key: 'street', label: 'Street', placeholder: 'e.g. Kisesa' },
];

export const LicenseFormSidebar: React.FC<LicenseFormSidebarProps> = ({
  data,
  profile,
  isAdmin,
  coinCosts,
  activeField,
  maskMode,
  qrMode,
  editingLicenseId,
  isSavingRecord,
  isExporting,
  onChangeField,
  onFocusField,
  onChangeMaskMode,
  onRequestQrMode,
  onSaveToCloud,
  onDownload,
  onResetDefaults,
  onClearFields,
  registerInputRef,
}) => {
  const [customFields, setCustomFields] = useState<
    Partial<Record<LicenseFieldKey, boolean>>
  >({});

  const canEdit = isAdmin || Boolean(profile.services?.editor);
  const canSaveRecords = isAdmin || Boolean(profile.services?.saveRecords);
  const canDownloadPdf =
    isAdmin ||
    Boolean(profile.services?.printPdf) ||
    Boolean(profile.services?.exportPng);
  const downloadCost = profile.services?.printPdf
    ? coinCosts.printPdf
    : coinCosts.exportPng;

  const renderSelectField = (field: FieldInputConfig) => {
    const isFocused = activeField === field.key;
    const options = field.options || [];
    const currentValue = data[field.key] ?? '';
    const matchesPreset = options.some((opt) => opt.value === currentValue);
    const isCustomMode =
      Boolean(customFields[field.key]) ||
      (currentValue !== '' && !matchesPreset);
    const selectValue = isCustomMode ? '__custom__' : currentValue;

    return (
      <div key={field.key} className="space-y-1.5">
        <label
          htmlFor={`field-${field.key}`}
          className="block text-xs font-medium text-slate-600"
        >
          {field.label}
        </label>
        <select
          id={`field-${field.key}`}
          ref={(el) => registerInputRef(field.key, el)}
          disabled={!canEdit}
          value={selectValue}
          onFocus={() => onFocusField(field.key)}
          onBlur={() => onFocusField(null)}
          onChange={(e) => {
            const val = e.target.value;
            if (val === '__custom__') {
              setCustomFields((prev) => ({ ...prev, [field.key]: true }));
            } else {
              setCustomFields((prev) => ({ ...prev, [field.key]: false }));
              onChangeField(field.key, val);
            }
          }}
          className={`w-full rounded-md border px-3 py-2 text-sm text-slate-900 transition-colors focus:outline-none disabled:bg-slate-100 disabled:text-slate-500 disabled:cursor-not-allowed ${
            field.mono ? 'font-mono-tabular' : ''
          } ${
            isFocused
              ? 'border-[#0f4c75] ring-2 ring-[#0f4c75]/15 bg-white'
              : 'border-slate-200 bg-slate-50/50 hover:border-slate-300 focus:border-[#0f4c75] focus:bg-white'
          }`}
        >
          <option value="">-- Chagua {field.label} --</option>
          {options.map((opt) => (
            <option key={opt.value} value={opt.value}>
              {opt.label}
            </option>
          ))}
          <option value="__custom__">Nyingine (Andika mwenyewe...)</option>
        </select>

        {isCustomMode && (
          <input
            type="text"
            disabled={!canEdit}
            value={currentValue}
            placeholder={field.placeholder}
            onFocus={() => onFocusField(field.key)}
            onBlur={() => onFocusField(null)}
            onChange={(e) => onChangeField(field.key, e.target.value)}
            className={`w-full rounded-md border border-slate-200 bg-white px-3 py-2 text-sm text-slate-900 placeholder:text-slate-400 focus:border-[#0f4c75] focus:outline-none disabled:bg-slate-100 disabled:text-slate-500 ${
              field.mono ? 'font-mono-tabular' : ''
            }`}
          />
        )}
      </div>
    );
  };

  const renderDateField = (field: FieldInputConfig) => {
    const isFocused = activeField === field.key;
    const currentValue = data[field.key] ?? '';
    const isIsoDate = /^\d{4}-\d{2}-\d{2}$/.test(currentValue);

    return (
      <div key={field.key} className="space-y-1.5">
        <div className="flex items-center justify-between gap-2">
          <label
            htmlFor={`field-${field.key}`}
            className="block text-xs font-medium text-slate-600"
          >
            {field.label}
          </label>
          {field.key === 'dateOfIssue' && (
            <button
              type="button"
              disabled={!canEdit}
              onClick={() => onChangeField('dateOfIssue', getTodayIso())}
              className="text-[11px] font-medium text-[#0f4c75] hover:underline disabled:opacity-40"
            >
              Chagua Leo
            </button>
          )}
          {field.key === 'expiringDate' && (
            <div className="flex items-center gap-2">
              <button
                type="button"
                disabled={!canEdit}
                onClick={() =>
                  onChangeField(
                    'expiringDate',
                    computeExpiryIso(data.dateOfIssue, 6)
                  )
                }
                className="text-[11px] font-medium text-slate-600 hover:text-[#0f4c75] hover:underline disabled:opacity-40"
              >
                +6 Miezi
              </button>
              <button
                type="button"
                disabled={!canEdit}
                onClick={() =>
                  onChangeField(
                    'expiringDate',
                    computeExpiryIso(data.dateOfIssue, 12)
                  )
                }
                className="text-[11px] font-medium text-[#0f4c75] hover:underline disabled:opacity-40"
              >
                +1 Mwaka
              </button>
            </div>
          )}
        </div>
        <input
          id={`field-${field.key}`}
          ref={(el) => registerInputRef(field.key, el)}
          type="date"
          disabled={!canEdit}
          value={isIsoDate ? currentValue : ''}
          onFocus={() => onFocusField(field.key)}
          onBlur={() => onFocusField(null)}
          onChange={(e) => onChangeField(field.key, e.target.value)}
          className={`w-full rounded-md border px-3 py-2 text-sm font-mono-tabular text-slate-900 transition-colors focus:outline-none disabled:bg-slate-100 disabled:text-slate-500 disabled:cursor-not-allowed ${
            isFocused
              ? 'border-[#0f4c75] ring-2 ring-[#0f4c75]/15 bg-white'
              : 'border-slate-200 bg-slate-50/50 hover:border-slate-300 focus:border-[#0f4c75] focus:bg-white'
          }`}
        />
      </div>
    );
  };

  const renderInput = (field: FieldInputConfig) => {
    if (field.kind === 'select') {
      return renderSelectField(field);
    }
    if (field.kind === 'date') {
      return renderDateField(field);
    }

    const isFocused = activeField === field.key;
    return (
      <div key={field.key} className="space-y-1.5">
        <label
          htmlFor={`field-${field.key}`}
          className="block text-xs font-medium text-slate-600"
        >
          {field.label}
          {field.key === 'taxId' && (
            <span className="ml-1.5 text-[11px] font-normal text-slate-400">
              (XXX-XXX-XXX)
            </span>
          )}
        </label>
        <input
          id={`field-${field.key}`}
          ref={(el) => registerInputRef(field.key, el)}
          type="text"
          inputMode={field.key === 'taxId' ? 'numeric' : undefined}
          disabled={!canEdit}
          value={data[field.key]}
          placeholder={field.placeholder}
          onFocus={() => onFocusField(field.key)}
          onBlur={() => onFocusField(null)}
          onChange={(e) => onChangeField(field.key, e.target.value)}
          className={`w-full rounded-md border px-3 py-2 text-sm text-slate-900 placeholder:text-slate-400 transition-colors focus:outline-none disabled:bg-slate-100 disabled:text-slate-500 disabled:cursor-not-allowed ${
            field.mono ? 'font-mono-tabular' : ''
          } ${field.key === 'licensee' ? 'uppercase' : ''} ${
            isFocused
              ? 'border-[#0f4c75] ring-2 ring-[#0f4c75]/15 bg-white'
              : 'border-slate-200 bg-slate-50/50 hover:border-slate-300 focus:border-[#0f4c75] focus:bg-white'
          }`}
        />
      </div>
    );
  };

  return (
    <aside className="no-print w-full lg:w-[380px] lg:shrink-0 bg-white border-b lg:border-b-0 lg:border-r border-slate-200 flex flex-col lg:h-full">
      <div className="flex-1 overflow-y-auto px-6 py-5 space-y-6">
        {!canEdit && (
          <div className="rounded-lg border border-amber-200 bg-amber-50 px-3.5 py-2.5 text-xs text-amber-800 flex items-start gap-2">
            <Lock className="w-4 h-4 shrink-0 mt-0.5" aria-hidden="true" />
            <span>
              Huduma ya kuhariri leseni (Editor) haijawashwa bado. Wasiliana na
              Admin kuwasha huduma hii kwa akaunti yako.
            </span>
          </div>
        )}

        {/* Section 1: License Details */}
        <section aria-labelledby="section-license-details">
          <div className="flex items-baseline justify-between mb-3.5">
            <h2
              id="section-license-details"
              className="text-sm font-semibold text-slate-900"
            >
              License Details
            </h2>
            <span className="text-xs text-slate-400 tabular-nums">9 fields</span>
          </div>
          <div className="space-y-3">
            {LICENSE_DETAIL_FIELDS.map(renderInput)}
          </div>
        </section>

        <hr className="border-slate-200" />

        {/* Section 2: Business Location */}
        <section aria-labelledby="section-business-location">
          <div className="flex items-baseline justify-between mb-3.5">
            <h2
              id="section-business-location"
              className="text-sm font-semibold text-slate-900"
            >
              Business Location
            </h2>
            <span className="text-xs text-slate-400 tabular-nums">3 fields</span>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-3 lg:grid-cols-1 gap-3">
            {LOCATION_FIELDS.map(renderInput)}
          </div>
        </section>

        <hr className="border-slate-200" />

        {/* Section 3: Payment & Document Options */}
        <section aria-labelledby="section-payment-options" className="space-y-4">
          <h2
            id="section-payment-options"
            className="text-sm font-semibold text-slate-900"
          >
            Payment &amp; Formatting
          </h2>

          {renderSelectField({
            key: 'feePaid',
            label: 'Amount of Fee Paid (TZS)',
            placeholder: '80,000.00',
            mono: true,
            kind: 'select',
            options: FEE_PAID_OPTIONS,
          })}

          <div className="space-y-1.5">
            <span className="block text-xs font-medium text-slate-600">
              Background Overlay
            </span>
            <div
              className="grid grid-cols-2 gap-1 p-1 bg-slate-100 rounded-lg"
              role="group"
              aria-label="Background overlay mode"
            >
              <button
                type="button"
                onClick={() => onChangeMaskMode('seamless')}
                className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap ${
                  maskMode === 'seamless'
                    ? 'bg-white text-slate-900 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Seamless Blend
              </button>
              <button
                type="button"
                onClick={() => onChangeMaskMode('opaque')}
                className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap ${
                  maskMode === 'opaque'
                    ? 'bg-white text-slate-900 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Opaque Mask
              </button>
            </div>
          </div>

          <div className="space-y-1.5">
            <div className="flex items-center justify-between">
              <span className="block text-xs font-medium text-slate-600">
                QR Verification Code
              </span>
              <span className="text-[11px] font-medium text-emerald-700">
                Inasoma Moja kwa Moja
              </span>
            </div>
            <div
              className="grid grid-cols-2 gap-1 p-1 bg-slate-100 rounded-lg"
              role="group"
              aria-label="QR code mode"
            >
              <button
                type="button"
                onClick={() => onRequestQrMode('live')}
                className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap ${
                  qrMode === 'live'
                    ? 'bg-white text-slate-900 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Taarifa za Leseni (Auto)
              </button>
              <button
                type="button"
                onClick={() => onRequestQrMode('template')}
                className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap ${
                  qrMode === 'template'
                    ? 'bg-white text-slate-900 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Original QR
              </button>
            </div>
            <p className="text-[11px] text-slate-500 leading-snug">
              Taarifa zote unazojaza zinaingizwa moja kwa moja kwenye QR code hii ili mtu akiscan zisomeke papo hapo.
            </p>
          </div>

          {/* Download PDF via Chrome & Save License to Cloud */}
          <div className="pt-1 space-y-2.5">
            <button
              type="button"
              disabled={isExporting}
              onClick={onDownload}
              className={`w-full inline-flex items-center justify-center gap-2 px-4 py-2.5 text-xs font-medium rounded-lg transition-colors ${
                canDownloadPdf
                  ? 'text-white bg-[#0f4c75] hover:bg-[#0b3a5b] disabled:opacity-60'
                  : 'text-white bg-slate-400 hover:bg-slate-500'
              }`}
            >
              {!canDownloadPdf ? (
                <Lock className="w-3.5 h-3.5" aria-hidden="true" />
              ) : (
                <Download className="w-3.5 h-3.5" aria-hidden="true" />
              )}
              {isExporting ? 'Inapakua PDF...' : 'Download PDF'}
              {!isAdmin && canDownloadPdf && (
                <span className="font-mono-tabular text-white/80">
                  ({downloadCost} Coins)
                </span>
              )}
            </button>
            {!isAdmin && (
              <p className="text-[11px] text-slate-500 leading-snug">
                Kila document unayopakua (PDF) hukata Coin {downloadCost} na utapokea taarifa ya salio.
              </p>
            )}

            <button
              type="button"
              disabled={isSavingRecord}
              onClick={onSaveToCloud}
              className={`w-full inline-flex items-center justify-center gap-2 px-4 py-2.5 text-xs font-medium rounded-lg border transition-colors ${
                canSaveRecords
                  ? 'border-[#0f4c75] text-[#0f4c75] bg-[#0f4c75]/5 hover:bg-[#0f4c75]/10'
                  : 'border-slate-200 text-slate-500 bg-slate-50'
              }`}
            >
              {!canSaveRecords ? (
                <Lock className="w-3.5 h-3.5" aria-hidden="true" />
              ) : (
                <CloudUpload className="w-3.5 h-3.5" aria-hidden="true" />
              )}
              {isSavingRecord
                ? 'Inahifadhi...'
                : editingLicenseId
                  ? 'Sasisha Kumbukumbu'
                  : 'Hifadhi Kumbukumbu'}
              {!isAdmin && canSaveRecords && !editingLicenseId && (
                <span className="font-mono-tabular text-slate-500">
                  ({coinCosts.saveRecord} Coins)
                </span>
              )}
            </button>
          </div>
        </section>
      </div>

      {/* Bottom Utility Bar */}
      <div className="px-6 py-3.5 border-t border-slate-200 bg-slate-50/70 flex items-center justify-between gap-3">
        <button
          type="button"
          disabled={!canEdit}
          onClick={() => {
            setCustomFields({});
            onResetDefaults();
          }}
          className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-medium text-slate-700 hover:text-slate-900 hover:bg-slate-200/60 disabled:opacity-40 rounded-md transition-colors whitespace-nowrap shrink-0"
        >
          <RotateCcw className="w-3.5 h-3.5" aria-hidden="true" />
          Reset Sample
        </button>
        <button
          type="button"
          disabled={!canEdit}
          onClick={() => {
            setCustomFields({});
            onClearFields();
          }}
          className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-medium text-slate-600 hover:text-slate-900 hover:bg-slate-200/60 disabled:opacity-40 rounded-md transition-colors whitespace-nowrap shrink-0"
        >
          <Eraser className="w-3.5 h-3.5" aria-hidden="true" />
          Clear All
        </button>
      </div>
    </aside>
  );
};
