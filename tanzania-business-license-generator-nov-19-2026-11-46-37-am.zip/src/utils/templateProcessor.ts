import { jsPDF } from 'jspdf';
import {
  FIELD_OVERLAYS,
  LicenseData,
  MaskMode,
  QR_BOX,
  QrMode,
  TEMPLATE_HEIGHT,
  TEMPLATE_WIDTH,
} from '../types/license';
import {
  TIN_FIELD_OVERLAYS,
  TIN_QR_BOX,
  TIN_TEMPLATE_HEIGHT,
  TIN_TEMPLATE_WIDTH,
  TinData,
} from '../types/tin';

export interface EraseBoxSpec {
  eraseX: number;
  eraseY: number;
  eraseW: number;
  eraseH: number;
  eraseKind: 'dark' | 'teal';
}

function loadImage(src: string): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => resolve(img);
    img.onerror = (err) => reject(err);
    img.src = src;
  });
}

const SYSTEM_DOWNLOAD_PREFIX = 'digital document potal';

function sanitizeFilenamePart(value: string, fallback: string): string {
  const cleaned = (value || '')
    .replace(/[\\/:*?"<>|]+/g, '-')
    .replace(/\s+/g, ' ')
    .trim();
  return cleaned || fallback;
}

export function buildChromeDocumentBaseName(params: {
  personName: string;
  documentNumber: string;
  fallbackPerson: string;
  fallbackNumber: string;
}): string {
  const upperName = sanitizeFilenamePart(
    params.personName,
    params.fallbackPerson
  ).toUpperCase();
  const upperNumber = sanitizeFilenamePart(
    params.documentNumber,
    params.fallbackNumber
  ).toUpperCase();
  return `${SYSTEM_DOWNLOAD_PREFIX} - ${upperName} - ${upperNumber}`;
}

export function triggerChromeBlobDownload(blob: Blob, filename: string): void {
  const href = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.download = filename;
  link.href = href;
  link.rel = 'noopener';
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  window.setTimeout(() => URL.revokeObjectURL(href), 20000);
}

async function triggerChromeCanvasPngDownload(
  canvas: HTMLCanvasElement,
  filename: string
): Promise<void> {
  const blob = await new Promise<Blob | null>((resolve) =>
    canvas.toBlob((b) => resolve(b), 'image/png')
  );
  if (blob) {
    triggerChromeBlobDownload(blob, filename);
    return;
  }
  const link = document.createElement('a');
  link.download = filename;
  link.href = canvas.toDataURL('image/png');
  link.rel = 'noopener';
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}

function canvasToA4PdfBlob(canvas: HTMLCanvasElement, docTitle: string): Blob {
  const pdf = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: 'a4',
    compress: true,
  });
  pdf.setProperties({
    title: docTitle,
    creator: 'DIGITAL DOCUMENT POTAL',
  });

  const pageW = pdf.internal.pageSize.getWidth();
  const pageH = pdf.internal.pageSize.getHeight();
  const imgAspect = canvas.width / canvas.height;
  const pageAspect = pageW / pageH;

  let drawW = pageW;
  let drawH = pageH;
  let offsetX = 0;
  let offsetY = 0;

  if (imgAspect > pageAspect) {
    drawW = pageW;
    drawH = pageW / imgAspect;
    offsetY = (pageH - drawH) / 2;
  } else {
    drawH = pageH;
    drawW = pageH * imgAspect;
    offsetX = (pageW - drawW) / 2;
  }

  const imgDataUrl = canvas.toDataURL('image/png');
  pdf.addImage(imgDataUrl, 'PNG', offsetX, offsetY, drawW, drawH, undefined, 'FAST');
  return pdf.output('blob');
}

/**
 * Creates a watermark-preserving blank template by removing only the original
 * sample text pixels inside each known field box and interpolating smoothly
 * across the surrounding watermark and background pattern.
 */
export async function createCleanedTemplateDataUrl(
  imagePath: string,
  targetWidth: number = TEMPLATE_WIDTH,
  targetHeight: number = TEMPLATE_HEIGHT,
  boxes: EraseBoxSpec[] = FIELD_OVERLAYS
): Promise<string> {
  const img = await loadImage(imagePath);
  const canvas = document.createElement('canvas');
  canvas.width = targetWidth;
  canvas.height = targetHeight;

  const ctx = canvas.getContext('2d');
  if (!ctx) {
    throw new Error('Could not initialize 2D canvas context');
  }

  ctx.drawImage(img, 0, 0, targetWidth, targetHeight);
  const imageData = ctx.getImageData(0, 0, targetWidth, targetHeight);
  const { data, width, height } = imageData;

  for (const box of boxes) {
    const x0 = Math.max(0, box.eraseX);
    const y0 = Math.max(0, box.eraseY);
    const x1 = Math.min(width - 1, box.eraseX + box.eraseW);
    const y1 = Math.min(height - 1, box.eraseY + box.eraseH);
    const bw = x1 - x0 + 1;
    const bh = y1 - y0 + 1;

    const isText = new Uint8Array(bw * bh);

    for (let dy = 0; dy < bh; dy++) {
      const y = y0 + dy;
      for (let dx = 0; dx < bw; dx++) {
        const x = x0 + dx;
        const idx = (y * width + x) * 4;
        const r = data[idx];
        const g = data[idx + 1];
        const b = data[idx + 2];
        const luma = 0.299 * r + 0.587 * g + 0.114 * b;

        if (box.eraseKind === 'teal') {
          const isTealText = (b - r > 18 && r < 185) || luma < 205;
          if (isTealText) {
            isText[dy * bw + dx] = 1;
          }
        } else {
          if (luma < 205) {
            isText[dy * bw + dx] = 1;
          }
        }
      }
    }

    const dilated = new Uint8Array(bw * bh);
    for (let dy = 0; dy < bh; dy++) {
      for (let dx = 0; dx < bw; dx++) {
        if (!isText[dy * bw + dx]) continue;
        for (let oy = -2; oy <= 2; oy++) {
          for (let ox = -2; ox <= 2; ox++) {
            const ny = dy + oy;
            const nx = dx + ox;
            if (ny >= 0 && ny < bh && nx >= 0 && nx < bw) {
              dilated[ny * bw + nx] = 1;
            }
          }
        }
      }
    }

    for (let dx = 0; dx < bw; dx++) {
      const x = x0 + dx;
      for (let dy = 0; dy < bh; dy++) {
        if (!dilated[dy * bw + dx]) continue;

        let topY = dy - 1;
        while (topY >= 0 && dilated[topY * bw + dx]) {
          topY--;
        }
        const sampleTopY = topY >= 0 ? y0 + topY : Math.max(0, y0 - 2);

        let botY = dy + 1;
        while (botY < bh && dilated[botY * bw + dx]) {
          botY++;
        }
        const sampleBotY = botY < bh ? y0 + botY : Math.min(height - 1, y1 + 2);

        const topIdx = (sampleTopY * width + x) * 4;
        const botIdx = (sampleBotY * width + x) * 4;

        const span = Math.max(1, sampleBotY - sampleTopY);
        const t = (y0 + dy - sampleTopY) / span;

        const outIdx = ((y0 + dy) * width + x) * 4;
        data[outIdx] = Math.round(data[topIdx] * (1 - t) + data[botIdx] * t);
        data[outIdx + 1] = Math.round(
          data[topIdx + 1] * (1 - t) + data[botIdx + 1] * t
        );
        data[outIdx + 2] = Math.round(
          data[topIdx + 2] * (1 - t) + data[botIdx + 2] * t
        );
      }
    }
  }

  ctx.putImageData(imageData, 0, 0);
  return canvas.toDataURL('image/png');
}

async function renderLicenseCanvas(params: {
  templateUrl: string;
  data: LicenseData;
  maskMode: MaskMode;
  qrMode: QrMode;
  qrDataUrl: string | null;
}): Promise<HTMLCanvasElement> {
  const { templateUrl, data, maskMode, qrMode, qrDataUrl } = params;
  const scale = 2;

  const canvas = document.createElement('canvas');
  canvas.width = TEMPLATE_WIDTH * scale;
  canvas.height = TEMPLATE_HEIGHT * scale;

  const ctx = canvas.getContext('2d');
  if (!ctx) {
    throw new Error('Could not initialize export canvas');
  }

  ctx.scale(scale, scale);
  const bgImg = await loadImage(templateUrl);
  ctx.drawImage(bgImg, 0, 0, TEMPLATE_WIDTH, TEMPLATE_HEIGHT);

  for (const field of FIELD_OVERLAYS) {
    if (maskMode === 'opaque') {
      ctx.fillStyle = '#f5fcfd';
      ctx.fillRect(field.eraseX, field.eraseY, field.eraseW, field.eraseH);
    }

    const rawValue = data[field.key] ?? '';
    const displayText =
      field.key === 'blNo' ? `B.L. NO : ${rawValue}` : rawValue;

    ctx.fillStyle = field.color;
    ctx.font = `${field.fontWeight} ${field.fontSizePx}px "DM Sans", Arial, Helvetica, sans-serif`;
    ctx.textBaseline = 'middle';

    const centerY = field.y + field.h / 2 + 0.5;
    if (field.align === 'center') {
      ctx.textAlign = 'center';
      ctx.fillText(displayText, field.x + field.w / 2, centerY, field.w);
    } else {
      ctx.textAlign = 'left';
      ctx.fillText(displayText, field.x, centerY, field.w);
    }
  }

  if (qrMode === 'live' && qrDataUrl) {
    const qrImg = await loadImage(qrDataUrl);
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(QR_BOX.x, QR_BOX.y, QR_BOX.w, QR_BOX.h);
    const pad = 4;
    const size = Math.min(QR_BOX.w, QR_BOX.h) - pad * 2;
    const drawX = QR_BOX.x + (QR_BOX.w - size) / 2;
    const drawY = QR_BOX.y + (QR_BOX.h - size) / 2;
    ctx.drawImage(qrImg, drawX, drawY, size, size);
  }

  return canvas;
}

async function renderTinCanvas(params: {
  templateUrl: string;
  data: TinData;
  maskMode: MaskMode;
  qrMode: QrMode;
  qrDataUrl: string | null;
}): Promise<HTMLCanvasElement> {
  const { templateUrl, data, maskMode, qrMode, qrDataUrl } = params;
  const scale = 2;

  const canvas = document.createElement('canvas');
  canvas.width = TIN_TEMPLATE_WIDTH * scale;
  canvas.height = TIN_TEMPLATE_HEIGHT * scale;

  const ctx = canvas.getContext('2d');
  if (!ctx) {
    throw new Error('Could not initialize export canvas');
  }

  ctx.scale(scale, scale);
  const bgImg = await loadImage(templateUrl);
  ctx.drawImage(bgImg, 0, 0, TIN_TEMPLATE_WIDTH, TIN_TEMPLATE_HEIGHT);

  for (const field of TIN_FIELD_OVERLAYS) {
    if (maskMode === 'opaque') {
      ctx.fillStyle = '#fdfdfd';
      ctx.fillRect(field.eraseX, field.eraseY, field.eraseW, field.eraseH);
    }

    const displayText = data[field.key] ?? '';

    ctx.fillStyle = field.color;
    ctx.font = `${field.fontWeight} ${field.fontSizePx}px "DM Sans", Arial, Helvetica, sans-serif`;
    ctx.textBaseline = 'middle';

    const centerY = field.y + field.h / 2 + 0.5;
    if (field.align === 'center') {
      ctx.textAlign = 'center';
      ctx.fillText(displayText, field.x + field.w / 2, centerY, field.w);
    } else {
      ctx.textAlign = 'left';
      ctx.fillText(displayText, field.x, centerY, field.w);
    }
  }

  if (qrMode === 'live' && qrDataUrl) {
    const qrImg = await loadImage(qrDataUrl);
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(TIN_QR_BOX.x, TIN_QR_BOX.y, TIN_QR_BOX.w, TIN_QR_BOX.h);
    const pad = 2;
    const size = Math.min(TIN_QR_BOX.w, TIN_QR_BOX.h) - pad * 2;
    const drawX = TIN_QR_BOX.x + (TIN_QR_BOX.w - size) / 2;
    const drawY = TIN_QR_BOX.y + (TIN_QR_BOX.h - size) / 2;
    ctx.drawImage(qrImg, drawX, drawY, size, size);
  }

  return canvas;
}

/**
 * Exports a crisp 2x (1440x2024) PNG of the edited business license.
 */
export async function exportLicensePng(params: {
  templateUrl: string;
  data: LicenseData;
  maskMode: MaskMode;
  qrMode: QrMode;
  qrDataUrl: string | null;
}): Promise<string> {
  const canvas = await renderLicenseCanvas(params);
  const filename = `${buildChromeDocumentBaseName({
    personName: params.data.licensee,
    documentNumber: params.data.blNo,
    fallbackPerson: 'LICENSEE',
    fallbackNumber: 'LICENSE',
  })}.png`;

  await triggerChromeCanvasPngDownload(canvas, filename);
  return filename;
}

/**
 * Exports a crisp 2x (1440x2004) PNG of the edited Tanzania TIN Certificate.
 */
export async function exportTinPng(params: {
  templateUrl: string;
  data: TinData;
  maskMode: MaskMode;
  qrMode: QrMode;
  qrDataUrl: string | null;
}): Promise<string> {
  const canvas = await renderTinCanvas(params);
  const filename = `${buildChromeDocumentBaseName({
    personName: params.data.taxpayerName,
    documentNumber: params.data.tinNumber,
    fallbackPerson: 'TAXPAYER',
    fallbackNumber: 'TIN',
  })}.png`;

  await triggerChromeCanvasPngDownload(canvas, filename);
  return filename;
}

/**
 * Builds an A4 PDF Blob and Chrome-formatted filename for the Business License.
 */
export async function buildLicensePdf(params: {
  templateUrl: string;
  data: LicenseData;
  maskMode: MaskMode;
  qrMode: QrMode;
  qrDataUrl: string | null;
}): Promise<{ blob: Blob; filename: string }> {
  const canvas = await renderLicenseCanvas(params);
  const baseName = buildChromeDocumentBaseName({
    personName: params.data.licensee,
    documentNumber: params.data.blNo,
    fallbackPerson: 'LICENSEE',
    fallbackNumber: 'LICENSE',
  });
  const blob = canvasToA4PdfBlob(canvas, baseName);
  return { blob, filename: `${baseName}.pdf` };
}

/**
 * Builds an A4 PDF Blob and Chrome-formatted filename for the Tanzania TIN Certificate.
 */
export async function buildTinPdf(params: {
  templateUrl: string;
  data: TinData;
  maskMode: MaskMode;
  qrMode: QrMode;
  qrDataUrl: string | null;
}): Promise<{ blob: Blob; filename: string }> {
  const canvas = await renderTinCanvas(params);
  const baseName = buildChromeDocumentBaseName({
    personName: params.data.taxpayerName,
    documentNumber: params.data.tinNumber,
    fallbackPerson: 'TAXPAYER',
    fallbackNumber: 'TIN',
  });
  const blob = canvasToA4PdfBlob(canvas, baseName);
  return { blob, filename: `${baseName}.pdf` };
}
