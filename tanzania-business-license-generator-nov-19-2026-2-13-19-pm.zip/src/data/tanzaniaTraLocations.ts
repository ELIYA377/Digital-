export interface TinSelectOption {
  value: string;
  label: string;
}

export interface TinSelectGroup {
  group: string;
  options: TinSelectOption[];
}

const makeOptions = (items: string[]): TinSelectOption[] =>
  items.map((item) => ({ value: item, label: item }));

const MONTHS_EN = [
  'January',
  'February',
  'March',
  'April',
  'May',
  'June',
  'July',
  'August',
  'September',
  'October',
  'November',
  'December',
];

function getOrdinalSuffix(day: number): string {
  const mod100 = day % 100;
  if (mod100 >= 11 && mod100 <= 13) return 'th';
  switch (day % 10) {
    case 1:
      return 'st';
    case 2:
      return 'nd';
    case 3:
      return 'rd';
    default:
      return 'th';
  }
}

export function isoToOrdinalDate(iso: string): string {
  const match = /^(\d{4})-(\d{2})-(\d{2})$/.exec(iso.trim());
  if (!match) return iso;
  const year = Number(match[1]);
  const monthIdx = Number(match[2]) - 1;
  const day = Number(match[3]);
  const monthName = MONTHS_EN[monthIdx];
  if (!monthName || day < 1 || day > 31) return iso;
  return `${day}${getOrdinalSuffix(day)} ${monthName} ${year}`;
}

export function ordinalToIsoDate(val: string): string {
  const trimmed = val.trim();
  if (/^\d{4}-\d{2}-\d{2}$/.test(trimmed)) return trimmed;
  const match = /^(\d{1,2})(?:st|nd|rd|th)?\s+([A-Za-z]+)\s+(\d{4})$/.exec(
    trimmed
  );
  if (!match) return '';
  const day = Number(match[1]);
  const monthIdx = MONTHS_EN.findIndex(
    (m) => m.toLowerCase() === match[2].toLowerCase()
  );
  const year = Number(match[3]);
  if (monthIdx === -1 || day < 1 || day > 31 || year < 1900) return '';
  return `${year}-${String(monthIdx + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
}

export function getTodayOrdinalDate(): string {
  const now = new Date();
  const iso = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')}`;
  return isoToOrdinalDate(iso);
}

export const TRA_LOCATION_GROUPS: TinSelectGroup[] = [
  {
    group: 'Dar es Salaam Tax Regions',
    options: makeOptions([
      'DAR ES SALAAM',
      'ILALA',
      'KARIAKOO',
      'KIGAMBONI',
      'KINONDONI',
      'TEGETA',
      'TEMEKE',
      'UBUNGO',
    ]),
  },
  {
    group: 'Mikoa Mingine (Tanzania Bara & Zanzibar)',
    options: makeOptions([
      'GEITA',
      'ARUSHA',
      'DODOMA',
      'IRINGA',
      'KAGERA',
      'KATAVI',
      'KIGOMA',
      'KILIMANJARO',
      'LINDI',
      'MANYARA',
      'MARA',
      'MBEYA',
      'MOROGORO',
      'MTWARA',
      'MWANZA',
      'NJOMBE',
      'PWANI',
      'RUKWA',
      'RUVUMA',
      'SHINYANGA',
      'SIMIYU',
      'SINGIDA',
      'SONGWE',
      'TABORA',
      'TANGA',
      'ZANZIBAR',
      'MJINI MAGHARIBI',
      'PEMBA',
    ]),
  },
];

export const ALL_TRA_LOCATIONS: TinSelectOption[] =
  TRA_LOCATION_GROUPS.flatMap((g) => g.options);

const seenTaxOffices = new Set<string>();
const makeUniqueTaxOfficeGroup = (
  group: string,
  names: string[]
): TinSelectGroup => {
  const options: TinSelectOption[] = [];
  for (const raw of names) {
    const clean = raw.trim().toUpperCase();
    if (!clean || seenTaxOffices.has(clean)) continue;
    seenTaxOffices.add(clean);
    options.push({ value: clean, label: clean });
  }
  return { group, options };
};

export const TAX_OFFICE_GROUPS: TinSelectGroup[] = [
  makeUniqueTaxOfficeGroup('Idara ya Walipa Kodi Wakubwa (Taifa)', [
    'LARGE TAXPAYERS DEPARTMENT',
  ]),
  makeUniqueTaxOfficeGroup('Mkoa wa Dar es Salaam (Ofisi & Vituo Vyote)', [
    'DAR ES SALAAM TAX REGION',
    'ILALA TAX REGION',
    'KARIAKOO TAX REGION',
    'KINONDONI TAX REGION',
    'TEMEKE TAX REGION',
    'TEGETA TAX REGION',
    'KARIAKOO SERVICE CENTRE',
    'SAMORA TAX SERVICE CENTRE',
    'SHAURI MOYO SERVICE CENTRE',
    'BUGURUNI TAX CENTRE',
    'TABATA TAX SERVICE CENTRE',
    'SEGEREA TAX SERVICE CENTRE',
    'MASAKI SERVICE CENTRE',
    'MWENGE TAX CENTRE',
    'MIKOCHENI TAX SERVICE CENTRE',
    'KAWE TAX SERVICE CENTRE',
    'WAZO TAX CENTRE',
    'MBEZI BEACH TAX CENTRE',
    'BUNJU TAX SERVICE CENTRE',
    'UBUNGO TAX SERVICE CENTRE',
    'KIMARA TAX SERVICE CENTRE',
    'MANZESE TAX SERVICE CENTRE',
    'MBEZI LUIS TAX SERVICE CENTRE',
    "CHANG'OMBE TAX CENTRE",
    'MBAGALA TAX CENTRE',
    'KURASINI TAX SERVICE CENTRE',
    'KIGAMBONI TAX SERVICE CENTRE',
  ]),
  makeUniqueTaxOfficeGroup('Mkoa wa Geita (Wilaya Zote)', [
    'GEITA TAX REGION',
    'GEITA TAX CENTRE',
    'RUZENWE TAX CENTRE',
    'RUNZEWE TAX SERVICE CENTRE',
    'KATORO TAX CENTRE',
    'BUSERESERE TAX SERVICE CENTRE',
    'BUKOMBE TAX CENTRE',
    'USHIROMBO TAX SERVICE CENTRE',
    'CHATO TAX CENTRE',
    'MBOGWE TAX CENTRE',
    "NYANG'HWALE TAX SERVICE CENTRE",
  ]),
  makeUniqueTaxOfficeGroup('Mkoa wa Arusha (Wilaya Zote)', [
    'ARUSHA TAX REGION',
    'ARUSHA TAX CENTRE',
    'ARUMERU TAX CENTRE',
    'MERU TAX SERVICE CENTRE',
    'KARATU TAX CENTRE',
    'LONGIDO TAX CENTRE',
    'MONDULI TAX CENTRE',
    'NGORONGORO TAX CENTRE',
  ]),
  makeUniqueTaxOfficeGroup('Mkoa wa Dodoma (Wilaya Zote)', [
    'DODOMA TAX REGION',
    'DODOMA TAX CENTRE',
    'BAHI TAX CENTRE',
    'CHAMWINO TAX CENTRE',
    'CHEMBA TAX CENTRE',
    'KONDOA TAX CENTRE',
    'KONGWA TAX CENTRE',
    'MPWAPWA TAX CENTRE',
  ]),
  makeUniqueTaxOfficeGroup('Mkoa wa Iringa (Wilaya Zote)', [
    'IRINGA TAX REGION',
    'IRINGA TAX CENTRE',
    'KILOLO TAX CENTRE',
    'MUFINDI TAX CENTRE',
    'MAFINGA TAX CENTRE',
  ]),
  makeUniqueTaxOfficeGroup('Mkoa wa Kagera (Wilaya Zote)', [
    'KAGERA TAX REGION',
    'BUKOBA TAX REGION',
    'BUKOBA TAX CENTRE',
    'BIHARAMULO TAX CENTRE',
    'KARAGWE TAX CENTRE',
    'KYERWA TAX CENTRE',
    'MISSENYI TAX CENTRE',
    'MULEBA TAX CENTRE',
    'NGARA TAX CENTRE',
  ]),
  makeUniqueTaxOfficeGroup('Mkoa wa Katavi (Wilaya Zote)', [
    'KATAVI TAX REGION',
    'MPANDA TAX REGION',
    'MPANDA TAX CENTRE',
    'MLELE TAX CENTRE',
    'MPIMBWE TAX CENTRE',
    'NSIMBO TAX CENTRE',
    'TANGANYIKA TAX CENTRE',
  ]),
  makeUniqueTaxOfficeGroup('Mkoa wa Kigoma (Wilaya Zote)', [
    'KIGOMA TAX REGION',
    'KIGOMA UJIJI TAX CENTRE',
    'KIGOMA TAX CENTRE',
    'BUHIGWE TAX CENTRE',
    'KAKONKO TAX CENTRE',
    'KASULU TAX CENTRE',
    'KIBONDO TAX CENTRE',
    'UVINZA TAX CENTRE',
  ]),
  makeUniqueTaxOfficeGroup('Mkoa wa Kilimanjaro (Wilaya Zote)', [
    'KILIMANJARO TAX REGION',
    'MOSHI TAX REGION',
    'MOSHI TAX CENTRE',
    'HAI TAX CENTRE',
    'MWANGA TAX CENTRE',
    'ROMBO TAX CENTRE',
    'SAME TAX CENTRE',
    'SIHA TAX CENTRE',
  ]),
  makeUniqueTaxOfficeGroup('Mkoa wa Lindi (Wilaya Zote)', [
    'LINDI TAX REGION',
    'LINDI TAX CENTRE',
    'KILWA TAX CENTRE',
    'LIWALE TAX CENTRE',
    'MTAMA TAX CENTRE',
    'NACHINGWEA TAX CENTRE',
    'RUANGWA TAX CENTRE',
  ]),
  makeUniqueTaxOfficeGroup('Mkoa wa Manyara (Wilaya Zote)', [
    'MANYARA TAX REGION',
    'BABATI TAX REGION',
    'BABATI TAX CENTRE',
    'HANANG TAX CENTRE',
    'KATESH TAX SERVICE CENTRE',
    'KITETO TAX CENTRE',
    'MBULU TAX CENTRE',
    'SIMANJIRO TAX CENTRE',
    'MERERANI TAX SERVICE CENTRE',
  ]),
  makeUniqueTaxOfficeGroup('Mkoa wa Mara (Wilaya Zote)', [
    'MARA TAX REGION',
    'MUSOMA TAX REGION',
    'MUSOMA TAX CENTRE',
    'BUNDA TAX CENTRE',
    'BUTIAMA TAX CENTRE',
    'RORYA TAX CENTRE',
    'SERENGETI TAX CENTRE',
    'TARIME TAX CENTRE',
    'SIRARI TAX SERVICE CENTRE',
  ]),
  makeUniqueTaxOfficeGroup('Mkoa wa Mbeya (Wilaya Zote)', [
    'MBEYA TAX REGION',
    'MBEYA TAX CENTRE',
    'BUSOKELO TAX CENTRE',
    'CHUNYA TAX CENTRE',
    'KYELA TAX CENTRE',
    'KASUMULU TAX SERVICE CENTRE',
    'MBARALI TAX CENTRE',
    'RUNGWE TAX CENTRE',
    'TUKUYU TAX SERVICE CENTRE',
  ]),
  makeUniqueTaxOfficeGroup('Mkoa wa Morogoro (Wilaya Zote)', [
    'MOROGORO TAX REGION',
    'MOROGORO TAX CENTRE',
    'GAIRO TAX CENTRE',
    'IFAKARA TAX CENTRE',
    'KILOMBERO TAX CENTRE',
    'KILOSA TAX CENTRE',
    'MALINYI TAX CENTRE',
    'MLIMBA TAX CENTRE',
    'MVOMERO TAX CENTRE',
    'ULANGA TAX CENTRE',
  ]),
  makeUniqueTaxOfficeGroup('Mkoa wa Mtwara (Wilaya Zote)', [
    'MTWARA TAX REGION',
    'MTWARA TAX CENTRE',
    'MASASI TAX CENTRE',
    'NANYAMBA TAX CENTRE',
    'NANYUMBU TAX CENTRE',
    'NEWALA TAX CENTRE',
    'TANDAHIMBA TAX CENTRE',
  ]),
  makeUniqueTaxOfficeGroup('Mkoa wa Mwanza (Wilaya Zote)', [
    'MWANZA TAX REGION',
    'NYAMAGANA TAX CENTRE',
    'ILEMELA TAX CENTRE',
    'BUCHOSA TAX CENTRE',
    'KWIMBA TAX CENTRE',
    'MAGU TAX SERVICE CENTRE',
    'KISESA TAX SERVICE CENTRE',
    'MISUNGWI TAX CENTRE',
    'SENGEREMA TAX CENTRE',
    'UKEREWE TAX CENTRE',
  ]),
  makeUniqueTaxOfficeGroup('Mkoa wa Njombe (Wilaya Zote)', [
    'NJOMBE TAX REGION',
    'NJOMBE TAX CENTRE',
    'LUDEWA TAX CENTRE',
    'MAKAMBAKO TAX CENTRE',
    'MAKETE TAX CENTRE',
    "WANGING'OMBE TAX CENTRE",
  ]),
  makeUniqueTaxOfficeGroup('Mkoa wa Pwani (Wilaya Zote)', [
    'PWANI TAX REGION',
    'KIBAHA TAX REGION',
    'KIBAHA TAX CENTRE',
    'BAGAMOYO TAX CENTRE',
    'CHALINZE TAX CENTRE',
    'KIBITI TAX CENTRE',
    'KISARAWE TAX CENTRE',
    'MAFIA TAX CENTRE',
    'MKURANGA TAX CENTRE',
    'RUFIJI TAX CENTRE',
  ]),
  makeUniqueTaxOfficeGroup('Mkoa wa Rukwa (Wilaya Zote)', [
    'RUKWA TAX REGION',
    'SUMBAWANGA TAX REGION',
    'SUMBAWANGA TAX CENTRE',
    'KALAMBO TAX CENTRE',
    'NKASI TAX CENTRE',
  ]),
  makeUniqueTaxOfficeGroup('Mkoa wa Ruvuma (Wilaya Zote)', [
    'RUVUMA TAX REGION',
    'SONGEA TAX REGION',
    'SONGEA TAX CENTRE',
    'MADABA TAX CENTRE',
    'MBINGA TAX CENTRE',
    'NAMTUMBO TAX CENTRE',
    'NYASA TAX CENTRE',
    'TUNDURU TAX CENTRE',
  ]),
  makeUniqueTaxOfficeGroup('Mkoa wa Shinyanga (Wilaya Zote)', [
    'SHINYANGA TAX REGION',
    'SHINYANGA TAX CENTRE',
    'KAHAMA TAX REGION',
    'KAHAMA TAX CENTRE',
    'KISHAPU TAX CENTRE',
    'MSALALA TAX CENTRE',
    'USHETU TAX CENTRE',
  ]),
  makeUniqueTaxOfficeGroup('Mkoa wa Simiyu (Wilaya Zote)', [
    'SIMIYU TAX REGION',
    'BARIADI TAX REGION',
    'BARIADI TAX CENTRE',
    'BUSEGA TAX CENTRE',
    'LAMADI TAX SERVICE CENTRE',
    'ITILIMA TAX CENTRE',
    'MASWA TAX CENTRE',
    'MEATU TAX CENTRE',
  ]),
  makeUniqueTaxOfficeGroup('Mkoa wa Singida (Wilaya Zote)', [
    'SINGIDA TAX REGION',
    'SINGIDA TAX CENTRE',
    'IKUNGI TAX CENTRE',
    'IRAMBA TAX CENTRE',
    'ITIGI TAX CENTRE',
    'MANYONI TAX CENTRE',
    'MKALAMA TAX CENTRE',
  ]),
  makeUniqueTaxOfficeGroup('Mkoa wa Songwe (Wilaya Zote)', [
    'SONGWE TAX REGION',
    'SONGWE TAX CENTRE',
    'TUNDUMA TAX CENTRE',
    'VWAWA TAX SERVICE CENTRE',
    'ILEJE TAX CENTRE',
    'MBOZI TAX CENTRE',
    'MOMBA TAX CENTRE',
  ]),
  makeUniqueTaxOfficeGroup('Mkoa wa Tabora (Wilaya Zote)', [
    'TABORA TAX REGION',
    'TABORA TAX CENTRE',
    'IGUNGA TAX CENTRE',
    'KALIUA TAX CENTRE',
    'NZEGA TAX CENTRE',
    'SIKONGE TAX CENTRE',
    'URAMBO TAX CENTRE',
    'UYUI TAX CENTRE',
  ]),
  makeUniqueTaxOfficeGroup('Mkoa wa Tanga (Wilaya Zote)', [
    'TANGA TAX REGION',
    'TANGA TAX CENTRE',
    'BUMBULI TAX CENTRE',
    'HANDENI TAX CENTRE',
    'KILINDI TAX CENTRE',
    'KOROGWE TAX CENTRE',
    'LUSHOTO TAX CENTRE',
    'MKINGA TAX CENTRE',
    'HOROHORO TAX SERVICE CENTRE',
    'MUHEZA TAX CENTRE',
    'PANGANI TAX CENTRE',
  ]),
  makeUniqueTaxOfficeGroup('Zanzibar (Unguja na Pemba - Wilaya Zote)', [
    'ZANZIBAR TAX REGION',
    'UNGUJA TAX CENTRE',
    'MJINI TAX CENTRE',
    'MAGHARIBI A TAX CENTRE',
    'MAGHARIBI B TAX CENTRE',
    'KASKAZINI A TAX CENTRE',
    'KASKAZINI B TAX CENTRE',
    'KATI TAX CENTRE',
    'KUSINI TAX CENTRE',
    'PEMBA TAX REGION',
    'CHAKE CHAKE TAX CENTRE',
    'WETE TAX CENTRE',
    'MICHEWENI TAX CENTRE',
    'MKOANI TAX CENTRE',
  ]),
].filter((grp) => grp.options.length > 0);

export const ALL_TAX_OFFICES: TinSelectOption[] =
  TAX_OFFICE_GROUPS.flatMap((g) => g.options);

export const PHYSICAL_LOCATION_GROUPS: TinSelectGroup[] = [
  {
    group: 'Geita, Mwanza & Kanda ya Ziwa',
    options: makeOptions([
      'NAMONGE',
      'GEITA MJINI',
      'KATORO',
      'BUKOMBE',
      'USHIROMBO',
      'CHATO',
      'MAGU',
      'KISESA',
      'NYAMAGANA',
      'IGOMA',
      'BUZURUGA',
      'ILEMELA',
      'NYAMHONGOLO',
      'PASIANSI',
      'SENGEREMA',
      'MISUNGWI',
      'NGUDU',
      'NANSIO',
      'KAHAMA MJINI',
      'SHINYANGA MJINI',
      'BARIADI',
      'MASWA',
      'LAMADI',
      'BUKOBA MJINI',
      'MUSOMA MJINI',
      'TARIME',
      'BUNDA',
    ]),
  },
  {
    group: 'Dar es Salaam & Pwani',
    options: makeOptions([
      'KARIAKOO',
      'POSTA / KIVUKONI',
      'ILALA',
      'BUGURUNI',
      'TABATA',
      'KINONDONI',
      'SINZA',
      'MWENGE',
      'MIKOCHENI',
      'MSASANI',
      'KAWE',
      'TEGETA',
      'BUNJU',
      'UBUNGO',
      'KIMARA',
      'MBEZI LUIS',
      'MANZESE',
      'TEMEKE',
      'CHANGOMBE',
      'KURASINI',
      'MBAGALA',
      'KIGAMBONI',
      'KIBAHA',
      'BAGAMOYO',
      'MKURANGA',
    ]),
  },
  {
    group: 'Mikoa Mingine (Tanzania Bara & Zanzibar)',
    options: makeOptions([
      'ARUSHA MJINI',
      'TENGERU',
      'MOSHI MJINI',
      'DODOMA MJINI',
      'MOROGORO MJINI',
      'IFAKARA',
      'TANGA MJINI',
      'MBEYA MJINI',
      'TUNDUMA',
      'IRINGA MJINI',
      'MAFINGA',
      'NJOMBE MJINI',
      'MAKAMBAKO',
      'SONGEA MJINI',
      'TABORA MJINI',
      'NZEGA',
      'KIGOMA UJIJI',
      'KASULU',
      'SINGIDA MJINI',
      'SUMBAWANGA MJINI',
      'MPANDA MJINI',
      'BABATI',
      'MTWARA MJINI',
      'MASASI',
      'LINDI MJINI',
      'MJINI ZANZIBAR',
      'CHAKE CHAKE',
    ]),
  },
];

export const ALL_PHYSICAL_LOCATIONS: TinSelectOption[] =
  PHYSICAL_LOCATION_GROUPS.flatMap((g) => g.options);

export const STREET_AREA_GROUPS: TinSelectGroup[] = [
  {
    group: 'Maeneo / Mitaa Maarufu (Kanda ya Ziwa & Mikoani)',
    options: makeOptions([
      'MUHAMA',
      'KISESA',
      'CENTRE',
      'MJINI KATI',
      'SOKONI',
      'STENDI KUU',
      'MJI MWEMA',
      'BUZURUGA',
      'IGOMA',
      'NYERERE ROAD',
      'KENYATTA ROAD',
      'MAKONGORO ROAD',
      'UHURU STREET',
      'JAMHURI STREET',
      'LUMUMBA STREET',
      'SOKOINE ROAD',
      'KILIMANI',
      'MAJENGO',
      'CHANGOMBE',
      'BOMA ROAD',
    ]),
  },
  {
    group: 'Mitaa / Barabara Kuu (Dar es Salaam & Miji Mikubwa)',
    options: makeOptions([
      'SAMORA AVENUE',
      'MOROGORO ROAD',
      'BAGAMOYO ROAD',
      'ALI HASSAN MWINYI ROAD',
      'MANDELA ROAD',
      'KILWA ROAD',
      'NYERERE ROAD / PUGU',
      'KAWAWA ROAD',
      'MSIMBAZI STREET',
      'UHURU / KARIAKOO',
      'AGGREY STREET',
      'NKURUMAH STREET',
      'BIBI TITI MOHAMED',
      'OHIO STREET',
      'AZIKIWE STREET',
      'SHEKILANGO ROAD',
      'MWAI KIBAKI ROAD',
      'OLD BAGAMOYO ROAD',
      'GOBA',
      'MBEZI BEACH',
    ]),
  },
];

export const ALL_STREET_AREAS: TinSelectOption[] =
  STREET_AREA_GROUPS.flatMap((g) => g.options);
