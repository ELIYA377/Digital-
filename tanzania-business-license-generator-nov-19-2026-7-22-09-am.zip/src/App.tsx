import { useCallback, useEffect, useRef, useState } from 'react';
import QRCode from 'qrcode';
import { Download, Printer } from 'lucide-react';
import {
  DEFAULT_LICENSE_DATA,
  LicenseData,
  LicenseFieldKey,
  MaskMode,
  QrMode,
  TEMPLATE_IMAGE_PATH,
  ZoomMode,
} from './types/license';
import {
  createCleanedTemplateDataUrl,
  exportLicensePng,
} from './utils/templateProcessor';
import { LicenseFormSidebar } from './components/LicenseFormSidebar';
import { LicensePreviewCanvas } from './components/LicensePreviewCanvas';

const ZOOM_OPTIONS: { value: ZoomMode; label: string }[] = [
  { value: 'fit', label: 'Fit' },
  { value: '75', label: '75%' },
  { value: '100', label: '100%' },
  { value: '125', label: '125%' },
];

export default function App() {
  const [data, setData] = useState<LicenseData>(DEFAULT_LICENSE_DATA);
  const [maskMode, setMaskMode] = useState<MaskMode>('seamless');
  const [qrMode, setQrMode] = useState<QrMode>('template');
  const [zoomMode, setZoomMode] = useState<ZoomMode>('fit');
  const [activeField, setActiveField] = useState<LicenseFieldKey | null>(null);

  const [cleanedTemplateUrl, setCleanedTemplateUrl] = useState<string | null>(
    null
  );
  const [qrDataUrl, setQrDataUrl] = useState<string | null>(null);
  const [isExporting, setIsExporting] = useState(false);

  const inputRefs = useRef<
    Partial<Record<LicenseFieldKey, HTMLInputElement | null>>
  >({});

  // Reconstruct watermark-preserving blank template once on mount
  useEffect(() => {
    let active = true;
    createCleanedTemplateDataUrl(TEMPLATE_IMAGE_PATH)
      .then((url) => {
        if (active) setCleanedTemplateUrl(url);
      })
      .catch(() => {
        if (active) setCleanedTemplateUrl(null);
      });
    return () => {
      active = false;
    };
  }, []);

  // Generate scannable QR code when live QR mode is active
  useEffect(() => {
    if (qrMode !== 'live') return;
    let active = true;

    const payload = [
      `B.L. NO: ${data.blNo}`,
      `OFFICE: ${data.issuingOffice}`,
      `TIN: ${data.taxId}`,
      `ISSUED TO: ${data.licensee}`,
      `BUSINESS: ${data.businessOf}`,
      `ISSUE: ${data.dateOfIssue}`,
      `EXPIRY: ${data.expiringDate}`,
      `LOCATION: ${data.region}, ${data.ward}, ${data.street}`,
      `FEE: ${data.feePaid}`,
    ].join('\n');

    QRCode.toDataURL(payload, {
      margin: 1,
      width: 320,
      color: {
        dark: '#111827',
        light: '#ffffff',
      },
      errorCorrectionLevel: 'M',
    })
      .then((url) => {
        if (active) setQrDataUrl(url);
      })
      .catch(() => {
        if (active) setQrDataUrl(null);
      });

    return () => {
      active = false;
    };
  }, [qrMode, data]);

  const handleChangeField = useCallback(
    (key: LicenseFieldKey, value: string) => {
      setData((prev) => ({ ...prev, [key]: value }));
    },
    []
  );

  const handleSelectFieldOnPreview = useCallback((key: LicenseFieldKey) => {
    setActiveField(key);
    const input = inputRefs.current[key];
    if (input) {
      input.focus();
      input.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    }
  }, []);

  const registerInputRef = useCallback(
    (key: LicenseFieldKey, el: HTMLInputElement | null) => {
      inputRefs.current[key] = el;
    },
    []
  );

  const handleResetDefaults = useCallback(() => {
    setData(DEFAULT_LICENSE_DATA);
  }, []);

  const handleClearFields = useCallback(() => {
    setData({
      blNo: '',
      issuingOffice: '',
      taxId: '',
      licensee: '',
      businessOf: '',
      licensingType: '',
      dateOfIssue: '',
      expiringDate: '',
      principalBranch: '',
      region: '',
      ward: '',
      street: '',
      feePaid: '',
    });
  }, []);

  const handlePrint = useCallback(() => {
    window.print();
  }, []);

  const handleExportPng = useCallback(async () => {
    setIsExporting(true);
    try {
      const templateUrl =
        maskMode === 'seamless' && cleanedTemplateUrl
          ? cleanedTemplateUrl
          : TEMPLATE_IMAGE_PATH;
      await exportLicensePng({
        templateUrl,
        data,
        maskMode,
        qrMode,
        qrDataUrl,
      });
    } finally {
      setIsExporting(false);
    }
  }, [maskMode, cleanedTemplateUrl, data, qrMode, qrDataUrl]);

  return (
    <div className="min-h-screen lg:h-screen flex flex-col bg-[#f4f6f8] text-slate-900 lg:overflow-hidden">
      {/* Top Workbench Header */}
      <header className="no-print h-14 px-5 bg-white border-b border-slate-200 flex items-center justify-between gap-4 shrink-0">
        <h1 className="font-display text-base font-semibold tracking-tight text-slate-900 whitespace-nowrap shrink-0">
          Tanzania Business License Generator
        </h1>

        <div className="flex items-center gap-3 shrink-0">
          {/* Zoom Selector */}
          <div
            className="hidden sm:flex items-center gap-0.5 p-1 bg-slate-100 rounded-lg"
            role="group"
            aria-label="Preview zoom level"
          >
            {ZOOM_OPTIONS.map((opt) => (
              <button
                key={opt.value}
                type="button"
                onClick={() => setZoomMode(opt.value)}
                className={`px-2.5 py-1 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 tabular-nums ${
                  zoomMode === opt.value
                    ? 'bg-white text-slate-900 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                {opt.label}
              </button>
            ))}
          </div>

          <button
            type="button"
            onClick={handlePrint}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-medium text-slate-700 bg-white border border-slate-200 hover:bg-slate-50 hover:border-slate-300 rounded-lg transition-colors whitespace-nowrap shrink-0"
          >
            <Printer className="w-3.5 h-3.5" aria-hidden="true" />
            Print / PDF
          </button>

          <button
            type="button"
            onClick={handleExportPng}
            disabled={isExporting}
            className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-medium text-white bg-[#0f4c75] hover:bg-[#0b3a5b] disabled:opacity-60 rounded-lg transition-colors whitespace-nowrap shrink-0"
          >
            <Download className="w-3.5 h-3.5" aria-hidden="true" />
            {isExporting ? 'Exporting...' : 'Export PNG'}
          </button>
        </div>
      </header>

      {/* Main Split Workspace */}
      <div className="flex-1 flex flex-col lg:flex-row min-h-0">
        <LicenseFormSidebar
          data={data}
          activeField={activeField}
          maskMode={maskMode}
          qrMode={qrMode}
          onChangeField={handleChangeField}
          onFocusField={setActiveField}
          onChangeMaskMode={setMaskMode}
          onChangeQrMode={setQrMode}
          onResetDefaults={handleResetDefaults}
          onClearFields={handleClearFields}
          registerInputRef={registerInputRef}
        />

        <LicensePreviewCanvas
          data={data}
          cleanedTemplateUrl={cleanedTemplateUrl}
          maskMode={maskMode}
          qrMode={qrMode}
          qrDataUrl={qrDataUrl}
          zoomMode={zoomMode}
          activeField={activeField}
          onSelectField={handleSelectFieldOnPreview}
        />
      </div>
    </div>
  );
}
