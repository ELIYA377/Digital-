import React, { useEffect, useMemo, useState } from 'react';
import {
  Check,
  CheckCircle2,
  Clock,
  Coins,
  Copy,
  CreditCard,
  RefreshCw,
  Send,
  Smartphone,
  Trash2,
  XCircle,
} from 'lucide-react';
import {
  DEFAULT_PAYMENT_CONFIG,
  PAYMENT_NETWORK_LABELS,
  PaymentConfig,
  PaymentNetwork,
  PaymentPackage,
  PaymentRequestRecord,
  UserProfile,
} from '../types/account';
import {
  cancelPendingPaymentRequest,
  submitPaymentRequest,
} from '../services/firestoreService';

interface PaymentPanelProps {
  profile: UserProfile;
  paymentConfig: PaymentConfig;
  paymentRequests: PaymentRequestRecord[];
}

interface DsnServerConfig {
  configured: boolean;
  hasApiKey: boolean;
  hasUserId: boolean;
}

interface DsnLiveStatus {
  orderId: string;
  status: string;
  paid: boolean;
  failed: boolean;
  message?: string;
  channel?: string;
}

export const PaymentPanel: React.FC<PaymentPanelProps> = ({
  profile,
  paymentConfig,
  paymentRequests,
}) => {
  const packages: PaymentPackage[] =
    paymentConfig.packages && paymentConfig.packages.length > 0
      ? paymentConfig.packages
      : DEFAULT_PAYMENT_CONFIG.packages;

  const availableNetworks = useMemo(() => {
    const entries: {
      id: PaymentNetwork;
      label: string;
      number: string;
    }[] = [
      {
        id: 'mpesa',
        label: PAYMENT_NETWORK_LABELS.mpesa,
        number: paymentConfig.mpesaNumber,
      },
      {
        id: 'airtel',
        label: PAYMENT_NETWORK_LABELS.airtel,
        number: paymentConfig.airtelNumber,
      },
      {
        id: 'tigo',
        label: PAYMENT_NETWORK_LABELS.tigo,
        number: paymentConfig.tigoNumber,
      },
      {
        id: 'halopesa',
        label: PAYMENT_NETWORK_LABELS.halopesa,
        number: paymentConfig.halopesaNumber,
      },
      {
        id: 'lipa_namba',
        label: PAYMENT_NETWORK_LABELS.lipa_namba,
        number: paymentConfig.lipaNamba,
      },
    ];
    const configured = entries.filter((e) => e.number.trim().length > 0);
    return configured.length > 0 ? configured : entries.slice(0, 2);
  }, [paymentConfig]);

  const [paymentMode, setPaymentMode] = useState<'ussd' | 'manual'>('ussd');
  const [dsnConfig, setDsnConfig] = useState<DsnServerConfig | null>(null);
  const [activeDsnOrder, setActiveDsnOrder] = useState<DsnLiveStatus | null>(null);
  const [checkingDsnStatus, setCheckingDsnStatus] = useState(false);

  const [selectedPkgId, setSelectedPkgId] = useState<string>(
    packages[0]?.id || 'pkg_starter'
  );
  const [selectedNetwork, setSelectedNetwork] = useState<PaymentNetwork>(
    availableNetworks[0]?.id || 'mpesa'
  );
  const [payerPhone, setPayerPhone] = useState(profile.phone || '');
  const [payerName, setPayerName] = useState(profile.fullName || '');
  const [transactionRef, setTransactionRef] = useState('');
  const [userNote, setUserNote] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [cancellingId, setCancellingId] = useState<string | null>(null);
  const [copiedKey, setCopiedKey] = useState<string | null>(null);
  const [feedback, setFeedback] = useState<{
    type: 'ok' | 'err';
    text: string;
  } | null>(null);

  useEffect(() => {
    let active = true;
    fetch('/api/payments/dsn/config')
      .then((res) => (res.ok ? res.json() : null))
      .then((data: DsnServerConfig | null) => {
        if (active && data) setDsnConfig(data);
      })
      .catch(() => {
        if (active) setDsnConfig(null);
      });
    return () => {
      active = false;
    };
  }, []);

  // Automatically restore latest pending DSN order if user refreshed the page
  useEffect(() => {
    if (activeDsnOrder) return;
    const latestPendingDsn = paymentRequests.find(
      (r) =>
        r.status === 'pending' &&
        (r.transactionRef.startsWith('DSN_') ||
          r.transactionRef.startsWith('ORD-') ||
          r.userNote.includes('DSN Collect'))
    );
    if (latestPendingDsn) {
      setActiveDsnOrder({
        orderId: latestPendingDsn.transactionRef,
        status: 'pending',
        paid: false,
        failed: false,
      });
    }
  }, [paymentRequests, activeDsnOrder]);

  // Automatically poll DSN Collect status every 4 seconds while order is pending
  useEffect(() => {
    if (!activeDsnOrder || activeDsnOrder.paid || activeDsnOrder.failed) {
      return;
    }
    let cancelled = false;
    const orderId = activeDsnOrder.orderId;

    const pollStatus = async () => {
      try {
        const res = await fetch(
          `/api/payments/dsn/status/${encodeURIComponent(orderId)}`
        );
        if (!res.ok) return;
        const json = (await res.json()) as {
          ok?: boolean;
          status?: string;
          paid?: boolean;
          failed?: boolean;
          channel?: string;
        };
        if (cancelled || !json.ok) return;
        if (json.paid || json.failed || (json.status && json.status !== activeDsnOrder.status)) {
          setActiveDsnOrder({
            orderId,
            status: json.status || 'pending',
            paid: Boolean(json.paid),
            failed: Boolean(json.failed),
            channel: json.channel,
          });
        }
        if (json.paid) {
          setFeedback({
            type: 'ok',
            text: `Malipo ya muamala ${orderId} yamethibitishwa na DSN Collect! Coin zako zinaongezwa kwenye salio lako kiotomatiki.`,
          });
        } else if (json.failed) {
          setFeedback({
            type: 'err',
            text: `Muamala ${orderId} haukukamilika (${json.status || 'failed'}). Tafadhali jaribu tena.`,
          });
        }
      } catch {
        // Ignore transient poll errors
      }
    };

    const timer = window.setInterval(() => {
      void pollStatus();
    }, 4000);

    return () => {
      cancelled = true;
      window.clearInterval(timer);
    };
  }, [activeDsnOrder]);

  const selectedPackage =
    packages.find((p) => p.id === selectedPkgId) || packages[0];

  const activeNetworkInfo =
    availableNetworks.find((n) => n.id === selectedNetwork) ||
    availableNetworks[0];

  const pendingCount = useMemo(
    () => paymentRequests.filter((r) => r.status === 'pending').length,
    [paymentRequests]
  );

  const totalApprovedTzs = useMemo(
    () =>
      paymentRequests
        .filter((r) => r.status === 'approved')
        .reduce((sum, r) => sum + r.amountTzs, 0),
    [paymentRequests]
  );

  const handleCopy = async (value: string, key: string) => {
    if (!value) return;
    try {
      await navigator.clipboard.writeText(value);
      setCopiedKey(key);
      setTimeout(() => setCopiedKey(null), 1800);
    } catch {
      // Clipboard blocked in restricted browser contexts
    }
  };

  const handleUssdCollect = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedPackage) return;
    setFeedback(null);
    setSubmitting(true);

    const orderId = `DSN_${Date.now()}_${profile.uid.slice(0, 6).toUpperCase()}`;

    try {
      const res = await fetch('/api/payments/dsn/collect', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          amount: selectedPackage.priceTzs,
          phone: payerPhone,
          orderId,
          customerName: payerName || profile.fullName,
          customerEmail: profile.email,
          description: `${selectedPackage.label} (${selectedPackage.coins} Coins)`,
        }),
      });
      const json = (await res.json()) as {
        ok?: boolean;
        orderId?: string;
        message?: string;
      };

      if (!res.ok || !json.ok) {
        throw new Error(
          json.message || 'Imeshindikana kutuma ombi la USSD Push.'
        );
      }

      const resolvedOrderId = json.orderId || orderId;
      await submitPaymentRequest({
        profile,
        selectedPackage,
        network: activeNetworkInfo.id,
        payerPhone,
        payerName: payerName || profile.fullName,
        transactionRef: resolvedOrderId,
        userNote: userNote.trim()
          ? `DSN Collect: ${userNote.trim()}`
          : 'DSN Collect USSD Push',
      });

      setActiveDsnOrder({
        orderId: resolvedOrderId,
        status: 'pending',
        paid: false,
        failed: false,
        message: json.message,
      });
      setUserNote('');
      setFeedback({
        type: 'ok',
        text:
          json.message ||
          `USSD Push imetumwa kwenda ${payerPhone}. Weka PIN kwenye simu yako kukamilisha malipo ya ${selectedPackage.priceTzs.toLocaleString()} TZS.`,
      });
    } catch (err) {
      setFeedback({
        type: 'err',
        text:
          err instanceof Error
            ? err.message
            : 'Imeshindikana kuanzisha malipo ya USSD Push.',
      });
    } finally {
      setSubmitting(false);
    }
  };

  const handleCheckDsnOrder = async (orderId: string) => {
    setCheckingDsnStatus(true);
    setFeedback(null);
    try {
      const res = await fetch(
        `/api/payments/dsn/status/${encodeURIComponent(orderId)}`
      );
      const json = (await res.json()) as {
        ok?: boolean;
        status?: string;
        paid?: boolean;
        failed?: boolean;
        channel?: string;
        message?: string;
      };
      if (!res.ok || !json.ok) {
        throw new Error(json.message || 'Imeshindikana kukagua hali ya muamala.');
      }
      setActiveDsnOrder({
        orderId,
        status: json.status || 'pending',
        paid: Boolean(json.paid),
        failed: Boolean(json.failed),
        channel: json.channel,
      });
      if (json.paid) {
        setFeedback({
          type: 'ok',
          text: `Malipo ya muamala ${orderId} yamethibitishwa na DSN Collect! Admin ataidhinisha na kuongeza Coins kwenye akaunti yako mara moja.`,
        });
      } else if (json.failed) {
        setFeedback({
          type: 'err',
          text: `Muamala ${orderId} haukukamilika (${json.status}). Jaribu tena.`,
        });
      } else {
        setFeedback({
          type: 'ok',
          text: `Muamala ${orderId} bado unasubiri uthibitisho wa PIN kwenye simu.`,
        });
      }
    } catch (err) {
      setFeedback({
        type: 'err',
        text:
          err instanceof Error
            ? err.message
            : 'Hitilafu wakati wa kukagua DSN Collect.',
      });
    } finally {
      setCheckingDsnStatus(false);
    }
  };

  const handleManualSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedPackage) return;
    setFeedback(null);
    setSubmitting(true);
    try {
      await submitPaymentRequest({
        profile,
        selectedPackage,
        network: activeNetworkInfo.id,
        payerPhone,
        payerName,
        transactionRef,
        userNote,
      });
      setTransactionRef('');
      setUserNote('');
      setFeedback({
        type: 'ok',
        text: `Uthibitisho wa malipo (${selectedPackage.coins} Coins · ${selectedPackage.priceTzs.toLocaleString()} TZS) umetumwa kwa Admin kwa uhakiki.`,
      });
    } catch (err) {
      setFeedback({
        type: 'err',
        text:
          err instanceof Error
            ? err.message
            : 'Imeshindikana kutuma uthibitisho wa malipo.',
      });
    } finally {
      setSubmitting(false);
    }
  };

  const handleCancel = async (paymentId: string) => {
    setCancellingId(paymentId);
    setFeedback(null);
    try {
      await cancelPendingPaymentRequest(paymentId);
      setFeedback({
        type: 'ok',
        text: 'Ombi la malipo limefutwa.',
      });
    } catch (err) {
      setFeedback({
        type: 'err',
        text:
          err instanceof Error ? err.message : 'Imeshindikana kufuta ombi.',
      });
    } finally {
      setCancellingId(null);
    }
  };

  return (
    <main className="flex-1 overflow-y-auto bg-[#f4f6f8] p-6 lg:p-8">
      <div className="max-w-5xl mx-auto space-y-6">
        {/* Header & Account Balances */}
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 border-b border-slate-200 pb-5">
          <div>
            <h2 className="font-display text-xl font-semibold text-slate-900">
              Mfumo wa Malipo &amp; Kuongeza Coin
            </h2>
            <p className="text-sm text-slate-600 mt-0.5">
              Lipa moja kwa moja kwa USSD Push (DSN Collect) au tuma kumbukumbu
              ya muamala wa simu.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3 self-start sm:self-auto">
            <div className="bg-white border border-slate-200 rounded-lg px-4 py-2 flex items-center gap-2">
              <Coins className="w-4 h-4 text-amber-600" aria-hidden="true" />
              <div>
                <p className="text-[11px] text-slate-500 leading-none">
                  Salio la Sasa
                </p>
                <p className="text-sm font-semibold font-mono-tabular text-slate-900 mt-0.5">
                  {profile.coins.toLocaleString()} Coins
                </p>
              </div>
            </div>
            <div className="bg-white border border-slate-200 rounded-lg px-4 py-2">
              <p className="text-[11px] text-slate-500 leading-none">
                Maombi Yanayosubiri
              </p>
              <p className="text-sm font-semibold font-mono-tabular text-slate-900 mt-0.5">
                {pendingCount}
              </p>
            </div>
            <div className="bg-white border border-slate-200 rounded-lg px-4 py-2">
              <p className="text-[11px] text-slate-500 leading-none">
                Yaliyolipwa
              </p>
              <p className="text-sm font-semibold font-mono-tabular text-emerald-700 mt-0.5">
                {totalApprovedTzs.toLocaleString()} TZS
              </p>
            </div>
          </div>
        </div>

        {feedback && (
          <div
            role="status"
            className={`rounded-lg border px-4 py-3 text-xs font-medium ${
              feedback.type === 'ok'
                ? 'border-emerald-200 bg-emerald-50 text-emerald-800'
                : 'border-red-200 bg-red-50 text-red-700'
            }`}
          >
            {feedback.text}
          </div>
        )}

        {/* Step 1: Coin Packages */}
        <section className="space-y-3" aria-labelledby="pkg-heading">
          <div className="flex items-center justify-between">
            <h3
              id="pkg-heading"
              className="text-sm font-semibold text-slate-800"
            >
              1. Chagua Kifurushi cha Coin
            </h3>
            <span className="text-xs text-slate-500">
              Sarafu: Shilingi ya Tanzania (TZS)
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3.5">
            {packages.map((pkg) => {
              const selected = pkg.id === selectedPackage?.id;
              const tzsPerCoin = Math.round(
                pkg.priceTzs / Math.max(1, pkg.coins)
              );
              return (
                <button
                  key={pkg.id}
                  type="button"
                  onClick={() => setSelectedPkgId(pkg.id)}
                  className={`text-left rounded-xl border p-4 transition-all ${
                    selected
                      ? 'bg-[#0f4c75]/5 border-[#0f4c75] ring-2 ring-[#0f4c75]/15'
                      : 'bg-white border-slate-200 hover:border-slate-300'
                  }`}
                >
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-xs font-medium text-slate-600">
                      {pkg.label}
                    </span>
                    {selected && (
                      <CheckCircle2
                        className="w-4 h-4 text-[#0f4c75] shrink-0"
                        aria-hidden="true"
                      />
                    )}
                  </div>
                  <p className="text-xl font-semibold font-mono-tabular text-slate-900 mt-2">
                    {pkg.coins.toLocaleString()} Coins
                  </p>
                  <div className="mt-2 pt-2 border-t border-slate-100 flex items-baseline justify-between">
                    <span className="text-sm font-semibold font-mono-tabular text-[#0f4c75]">
                      {pkg.priceTzs.toLocaleString()} TZS
                    </span>
                    <span className="text-[11px] font-mono-tabular text-slate-500">
                      ~{tzsPerCoin} TZS/coin
                    </span>
                  </div>
                </button>
              );
            })}
          </div>
        </section>

        {/* Payment Method Switcher */}
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div
            className="inline-flex items-center gap-1 p-1 bg-slate-200/70 rounded-lg"
            role="group"
            aria-label="Njia ya malipo"
          >
            <button
              type="button"
              onClick={() => setPaymentMode('ussd')}
              className={`inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-medium rounded-md transition-colors whitespace-nowrap ${
                paymentMode === 'ussd'
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Smartphone className="w-3.5 h-3.5" aria-hidden="true" />
              USSD Push Moja kwa Moja (DSN Collect)
            </button>
            <button
              type="button"
              onClick={() => setPaymentMode('manual')}
              className={`inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-medium rounded-md transition-colors whitespace-nowrap ${
                paymentMode === 'manual'
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <CreditCard className="w-3.5 h-3.5" aria-hidden="true" />
              Tuma Kumbukumbu (Manual)
            </button>
          </div>

          {dsnConfig && (
            <span
              className={`text-xs font-medium ${
                dsnConfig.configured ? 'text-emerald-700' : 'text-amber-700'
              }`}
            >
              {dsnConfig.configured
                ? 'DSN Collect Gateway Iko Tayari'
                : dsnConfig.hasApiKey && !dsnConfig.hasUserId
                  ? 'DSN API Key imewekwa · Inasubiri DSN_USER_ID (mfano DSN-0036)'
                  : 'DSN Collect Haijakamilika'}
            </span>
          )}
        </div>

        {/* Mode A: Direct USSD Push (DSN Collect) */}
        {paymentMode === 'ussd' ? (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            <form
              onSubmit={handleUssdCollect}
              className="lg:col-span-7 bg-white border border-slate-200 rounded-xl p-5 space-y-4"
            >
              <div className="flex items-center justify-between gap-2">
                <h3 className="text-sm font-semibold text-slate-900">
                  2. Lipa Moja kwa Moja Kupitia Simu (USSD Push)
                </h3>
                {selectedPackage && (
                  <span className="text-xs font-semibold font-mono-tabular text-[#0f4c75]">
                    {selectedPackage.priceTzs.toLocaleString()} TZS
                  </span>
                )}
              </div>

              <p className="text-xs text-slate-600 leading-relaxed">
                Ingiza namba yako ya simu (M-Pesa, Airtel Money, Mixx by Yas, au
                Halopesa). Utapokea ujumbe wa USSD kwenye simu yako kuingiza
                namba ya siri (PIN) bila kutoka kwenye mfumo.
              </p>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <label
                    htmlFor="ussd-phone"
                    className="block text-xs font-medium text-slate-700"
                  >
                    Namba ya Simu ya Malipo
                  </label>
                  <input
                    id="ussd-phone"
                    type="tel"
                    required
                    value={payerPhone}
                    onChange={(e) => setPayerPhone(e.target.value)}
                    placeholder="07XXXXXXXX au 2557XXXXXXXX"
                    className="w-full rounded-lg border border-slate-200 px-3 py-2 text-sm font-mono-tabular text-slate-900 focus:border-[#0f4c75] focus:ring-2 focus:ring-[#0f4c75]/15 focus:outline-none"
                  />
                </div>

                <div className="space-y-1.5">
                  <label
                    htmlFor="ussd-name"
                    className="block text-xs font-medium text-slate-700"
                  >
                    Jina la Mlipaji
                  </label>
                  <input
                    id="ussd-name"
                    type="text"
                    required
                    value={payerName}
                    onChange={(e) => setPayerName(e.target.value)}
                    placeholder="Jina kamili"
                    className="w-full rounded-lg border border-slate-200 px-3 py-2 text-sm text-slate-900 focus:border-[#0f4c75] focus:ring-2 focus:ring-[#0f4c75]/15 focus:outline-none"
                  />
                </div>
              </div>

              <div className="space-y-1.5">
                <label
                  htmlFor="ussd-note"
                  className="block text-xs font-medium text-slate-700"
                >
                  Maelezo (Hiari)
                </label>
                <input
                  id="ussd-note"
                  type="text"
                  value={userNote}
                  onChange={(e) => setUserNote(e.target.value)}
                  placeholder="Mfano: Malipo ya coin za biashara"
                  className="w-full rounded-lg border border-slate-200 px-3 py-2 text-sm text-slate-900 focus:border-[#0f4c75] focus:ring-2 focus:ring-[#0f4c75]/15 focus:outline-none"
                />
              </div>

              <button
                type="submit"
                disabled={submitting || !selectedPackage}
                className="w-full inline-flex items-center justify-center gap-2 px-4 py-2.5 text-sm font-medium text-white bg-[#0f4c75] hover:bg-[#0b3a5b] disabled:opacity-60 rounded-lg transition-colors"
              >
                <Smartphone className="w-4 h-4" aria-hidden="true" />
                {submitting
                  ? 'Inatuma Ombi la USSD...'
                  : `Lipa ${selectedPackage ? selectedPackage.priceTzs.toLocaleString() : '0'} TZS kwa USSD Push`}
              </button>
            </form>

            {/* Right 5 cols: Active USSD Status Tracker */}
            <section className="lg:col-span-5 bg-white border border-slate-200 rounded-xl p-5 space-y-4 self-start">
              <h3 className="text-sm font-semibold text-slate-900">
                Hali ya Muamala wa USSD (DSN Collect)
              </h3>

              {activeDsnOrder ? (
                <div className="space-y-3">
                  <div className="rounded-lg border border-slate-200 bg-slate-50 p-4 space-y-2 text-xs">
                    <div className="flex items-center justify-between gap-2">
                      <span className="text-slate-500">Order ID</span>
                      <span className="font-mono-tabular font-semibold text-slate-900">
                        {activeDsnOrder.orderId}
                      </span>
                    </div>
                    <div className="flex items-center justify-between gap-2">
                      <span className="text-slate-500">Hali</span>
                      <span
                        className={`font-semibold ${
                          activeDsnOrder.paid
                            ? 'text-emerald-700'
                            : activeDsnOrder.failed
                              ? 'text-red-600'
                              : 'text-amber-700'
                        }`}
                      >
                        {activeDsnOrder.paid
                          ? 'Imelipwa (Confirmed)'
                          : activeDsnOrder.failed
                            ? 'Imeshindikana'
                            : 'Inasubiri PIN Kwenye Simu'}
                      </span>
                    </div>
                    {activeDsnOrder.channel && (
                      <div className="flex items-center justify-between gap-2">
                        <span className="text-slate-500">Mtandao</span>
                        <span className="font-medium text-slate-900">
                          {activeDsnOrder.channel}
                        </span>
                      </div>
                    )}
                  </div>

                  <button
                    type="button"
                    disabled={checkingDsnStatus}
                    onClick={() => handleCheckDsnOrder(activeDsnOrder.orderId)}
                    className="w-full inline-flex items-center justify-center gap-2 px-4 py-2 text-xs font-medium text-slate-800 bg-slate-100 hover:bg-slate-200 disabled:opacity-60 rounded-lg transition-colors"
                  >
                    <RefreshCw
                      className={`w-3.5 h-3.5 ${checkingDsnStatus ? 'animate-spin' : ''}`}
                      aria-hidden="true"
                    />
                    {checkingDsnStatus
                      ? 'Inakagua...'
                      : 'Hakiki Hali ya Malipo Sasa'}
                  </button>
                </div>
              ) : (
                <div className="rounded-lg border border-slate-200 bg-slate-50 p-4 text-xs text-slate-600 space-y-2">
                  <p className="font-medium text-slate-800">
                    Mitandao Inayokubalika:
                  </p>
                  <p>M-Pesa (Vodacom) · Airtel Money · Mixx by Yas · Halopesa</p>
                  <p className="text-slate-500 pt-1">
                    Baada ya kubonyeza kitufe cha kulipa, ujumbe wa kuweka PIN
                    utajitokeza kwenye simu yako moja kwa moja.
                  </p>
                </div>
              )}
            </section>
          </div>
        ) : (
          /* Mode B: Manual Mobile Money + Transaction Ref */
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            <section className="lg:col-span-5 bg-white border border-slate-200 rounded-xl p-5 space-y-4 self-start">
              <div className="flex items-center gap-2">
                <CreditCard
                  className="w-4 h-4 text-[#0f4c75]"
                  aria-hidden="true"
                />
                <h3 className="text-sm font-semibold text-slate-900">
                  2. Namba za Kufanya Malipo
                </h3>
              </div>

              <div className="space-y-1.5">
                <p className="text-xs font-medium text-slate-700">
                  Chagua Mtandao wa Malipo
                </p>
                <div className="grid grid-cols-1 gap-2">
                  {availableNetworks.map((net) => {
                    const active = activeNetworkInfo.id === net.id;
                    return (
                      <button
                        key={net.id}
                        type="button"
                        onClick={() => setSelectedNetwork(net.id)}
                        className={`px-3.5 py-2.5 rounded-lg border text-left flex items-center justify-between gap-3 transition-colors ${
                          active
                            ? 'border-[#0f4c75] bg-[#0f4c75]/5 text-slate-900'
                            : 'border-slate-200 hover:bg-slate-50 text-slate-700'
                        }`}
                      >
                        <span className="text-xs font-medium">{net.label}</span>
                        <span className="text-xs font-mono-tabular font-semibold text-[#0f4c75]">
                          {net.number || 'Haijawekwa'}
                        </span>
                      </button>
                    );
                  })}
                </div>
              </div>

              <div className="rounded-lg border border-slate-200 bg-slate-50 p-4 space-y-2.5">
                <div className="flex items-center justify-between gap-2">
                  <div>
                    <p className="text-[11px] text-slate-500">Namba ya Kupokea</p>
                    <p className="text-base font-semibold font-mono-tabular text-slate-900">
                      {activeNetworkInfo.number || 'Wasiliana na Admin'}
                    </p>
                  </div>
                  {activeNetworkInfo.number && (
                    <button
                      type="button"
                      onClick={() =>
                        handleCopy(activeNetworkInfo.number, 'pay-num')
                      }
                      className="inline-flex items-center gap-1 px-2.5 py-1.5 text-xs font-medium text-slate-700 bg-white border border-slate-200 hover:bg-slate-100 rounded-md transition-colors"
                    >
                      {copiedKey === 'pay-num' ? (
                        <>
                          <Check className="w-3.5 h-3.5 text-emerald-600" />
                          <span>Imenakiliwa</span>
                        </>
                      ) : (
                        <>
                          <Copy className="w-3.5 h-3.5" />
                          <span>Nakili</span>
                        </>
                      )}
                    </button>
                  )}
                </div>

                <div className="flex items-center justify-between text-xs pt-1 border-t border-slate-200">
                  <span className="text-slate-500">Jina la Akaunti</span>
                  <span className="font-semibold text-slate-900">
                    {paymentConfig.accountName || 'Digital Sales'}
                  </span>
                </div>
                <div className="flex items-center justify-between text-xs">
                  <span className="text-slate-500">Kiasi cha Kutuma</span>
                  <span className="font-semibold font-mono-tabular text-[#0f4c75]">
                    {selectedPackage
                      ? `${selectedPackage.priceTzs.toLocaleString()} TZS`
                      : '—'}
                  </span>
                </div>
              </div>

              <p className="text-xs text-slate-600 leading-relaxed">
                {paymentConfig.instructions || DEFAULT_PAYMENT_CONFIG.instructions}
              </p>
            </section>

            <form
              onSubmit={handleManualSubmit}
              className="lg:col-span-7 bg-white border border-slate-200 rounded-xl p-5 space-y-4"
            >
              <div className="flex items-center justify-between gap-2">
                <h3 className="text-sm font-semibold text-slate-900">
                  3. Tuma Uthibitisho wa Malipo
                </h3>
                {selectedPackage && (
                  <span className="text-xs font-medium font-mono-tabular text-[#0f4c75]">
                    +{selectedPackage.coins} Coins (
                    {selectedPackage.priceTzs.toLocaleString()} TZS)
                  </span>
                )}
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <label
                    htmlFor="pay-phone"
                    className="block text-xs font-medium text-slate-700"
                  >
                    Namba ya Simu Uliyotumia Kulipia
                  </label>
                  <input
                    id="pay-phone"
                    type="tel"
                    required
                    value={payerPhone}
                    onChange={(e) => setPayerPhone(e.target.value)}
                    placeholder="07XXXXXXXX"
                    className="w-full rounded-lg border border-slate-200 px-3 py-2 text-sm font-mono-tabular text-slate-900 focus:border-[#0f4c75] focus:ring-2 focus:ring-[#0f4c75]/15 focus:outline-none"
                  />
                </div>

                <div className="space-y-1.5">
                  <label
                    htmlFor="pay-name"
                    className="block text-xs font-medium text-slate-700"
                  >
                    Jina Linaloonekana Kwenye Simu
                  </label>
                  <input
                    id="pay-name"
                    type="text"
                    required
                    value={payerName}
                    onChange={(e) => setPayerName(e.target.value)}
                    placeholder="Jina la mtumaji"
                    className="w-full rounded-lg border border-slate-200 px-3 py-2 text-sm text-slate-900 focus:border-[#0f4c75] focus:ring-2 focus:ring-[#0f4c75]/15 focus:outline-none"
                  />
                </div>
              </div>

              <div className="space-y-1.5">
                <label
                  htmlFor="pay-ref"
                  className="block text-xs font-medium text-slate-700"
                >
                  Kumbukumbu ya Muamala (Transaction ID / Receipt Code)
                </label>
                <input
                  id="pay-ref"
                  type="text"
                  required
                  value={transactionRef}
                  onChange={(e) =>
                    setTransactionRef(e.target.value.toUpperCase())
                  }
                  placeholder="Mfano: BI54XK89Q2 au 9482710482"
                  className="w-full rounded-lg border border-slate-200 px-3 py-2 text-sm font-mono-tabular uppercase text-slate-900 focus:border-[#0f4c75] focus:ring-2 focus:ring-[#0f4c75]/15 focus:outline-none"
                />
              </div>

              <div className="space-y-1.5">
                <label
                  htmlFor="pay-note"
                  className="block text-xs font-medium text-slate-700"
                >
                  Maelezo ya Ziada (Hiari)
                </label>
                <input
                  id="pay-note"
                  type="text"
                  value={userNote}
                  onChange={(e) => setUserNote(e.target.value)}
                  placeholder="Mfano: Nimetuma muda huu kupitia M-Pesa"
                  className="w-full rounded-lg border border-slate-200 px-3 py-2 text-sm text-slate-900 focus:border-[#0f4c75] focus:ring-2 focus:ring-[#0f4c75]/15 focus:outline-none"
                />
              </div>

              <button
                type="submit"
                disabled={submitting || !selectedPackage}
                className="w-full inline-flex items-center justify-center gap-2 px-4 py-2.5 text-sm font-medium text-white bg-[#0f4c75] hover:bg-[#0b3a5b] disabled:opacity-60 rounded-lg transition-colors"
              >
                <Send className="w-4 h-4" aria-hidden="true" />
                {submitting
                  ? 'Inatuma Uthibitisho...'
                  : 'Tuma Uthibitisho wa Malipo'}
              </button>
            </form>
          </div>
        )}

        {/* User's Payment Requests History */}
        <section className="bg-white border border-slate-200 rounded-xl overflow-hidden">
          <div className="px-5 py-4 border-b border-slate-200 flex items-center justify-between">
            <h3 className="text-sm font-semibold text-slate-900">
              Historia ya Maombi Yako ya Malipo ({paymentRequests.length})
            </h3>
          </div>

          {paymentRequests.length === 0 ? (
            <div className="p-8 text-center text-sm text-slate-500">
              Bado hujatuma ombi lolote la malipo. Chagua kifurushi hapo juu na
              utume ombi la malipo.
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-xs text-left">
                <thead>
                  <tr className="bg-slate-50 border-b border-slate-200 text-slate-600">
                    <th className="py-2.5 px-4 font-medium">Muamala</th>
                    <th className="py-2.5 px-4 font-medium">Kifurushi</th>
                    <th className="py-2.5 px-4 font-medium">Mtandao &amp; Simu</th>
                    <th className="py-2.5 px-4 font-medium text-right">Kiasi</th>
                    <th className="py-2.5 px-4 font-medium">Hali</th>
                    <th className="py-2.5 px-4 font-medium">Maelezo ya Admin</th>
                    <th className="py-2.5 px-4 font-medium text-right">Hatua</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {paymentRequests.map((req) => (
                    <tr key={req.id} className="hover:bg-slate-50/60">
                      <td className="py-3 px-4 font-mono-tabular font-semibold text-slate-900 whitespace-nowrap">
                        {req.transactionRef}
                      </td>
                      <td className="py-3 px-4">
                        <p className="font-medium text-slate-900">
                          {req.packageLabel}
                        </p>
                        <p className="text-slate-500 font-mono-tabular">
                          +{req.coins} Coins
                        </p>
                      </td>
                      <td className="py-3 px-4 text-slate-600">
                        <p>{PAYMENT_NETWORK_LABELS[req.network]}</p>
                        <p className="font-mono-tabular text-slate-400">
                          {req.payerPhone}
                        </p>
                      </td>
                      <td className="py-3 px-4 text-right font-mono-tabular font-medium text-slate-900 whitespace-nowrap">
                        {req.amountTzs.toLocaleString()} TZS
                      </td>
                      <td className="py-3 px-4 whitespace-nowrap">
                        {req.status === 'approved' ? (
                          <span className="inline-flex items-center gap-1 font-medium text-emerald-700">
                            <CheckCircle2
                              className="w-3.5 h-3.5"
                              aria-hidden="true"
                            />
                            Imekubaliwa
                          </span>
                        ) : req.status === 'rejected' ? (
                          <span className="inline-flex items-center gap-1 font-medium text-red-600">
                            <XCircle
                              className="w-3.5 h-3.5"
                              aria-hidden="true"
                            />
                            Imekataliwa
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1 font-medium text-amber-700">
                            <Clock className="w-3.5 h-3.5" aria-hidden="true" />
                            Inasubiri Uhakiki
                          </span>
                        )}
                      </td>
                      <td className="py-3 px-4 text-slate-600 max-w-[220px]">
                        {req.adminNote || '—'}
                      </td>
                      <td className="py-3 px-4 text-right whitespace-nowrap">
                        <div className="inline-flex items-center gap-2">
                          {req.status === 'pending' &&
                            (req.transactionRef.startsWith('DSN_') ||
                              req.transactionRef.startsWith('ORD-') ||
                              req.userNote.includes('DSN Collect')) && (
                              <button
                                type="button"
                                disabled={checkingDsnStatus}
                                onClick={() =>
                                  handleCheckDsnOrder(req.transactionRef)
                                }
                                className="inline-flex items-center gap-1 px-2.5 py-1 text-xs font-medium text-[#0f4c75] hover:bg-[#0f4c75]/10 rounded-md transition-colors"
                              >
                                <RefreshCw
                                  className="w-3 h-3"
                                  aria-hidden="true"
                                />
                                Hakiki
                              </button>
                            )}
                          {req.status === 'pending' ? (
                            <button
                              type="button"
                              disabled={cancellingId === req.id}
                              onClick={() => handleCancel(req.id)}
                              aria-label={`Futa ombi ${req.transactionRef}`}
                              className="inline-flex items-center gap-1 px-2.5 py-1 text-xs font-medium text-red-600 hover:bg-red-50 rounded-md transition-colors"
                            >
                              <Trash2
                                className="w-3.5 h-3.5"
                                aria-hidden="true"
                              />
                              Futa
                            </button>
                          ) : (
                            <span className="text-slate-400">—</span>
                          )}
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </section>
      </div>
    </main>
  );
};
