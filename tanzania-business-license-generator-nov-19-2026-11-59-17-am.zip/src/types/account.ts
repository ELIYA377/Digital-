import { Timestamp } from 'firebase/firestore';
import { LicenseData, MaskMode, QrMode } from './license';
import { TinData } from './tin';

export type ServiceKey =
  | 'editor'
  | 'exportPng'
  | 'printPdf'
  | 'liveQr'
  | 'saveRecords'
  | 'tinCertificate';

export interface UserServices {
  editor: boolean;
  exportPng: boolean;
  printPdf: boolean;
  liveQr: boolean;
  saveRecords: boolean;
  tinCertificate?: boolean;
}

export interface UserProfile {
  uid: string;
  fullName: string;
  phone: string;
  email: string;
  pinHash: string;
  pinSalt: string;
  role: 'user' | 'admin';
  accountStatus: 'active' | 'suspended';
  coins: number;
  services: UserServices;
  createdAt?: Timestamp;
  updatedAt?: Timestamp;
}

export interface CoinCosts {
  exportPng: number;
  printPdf: number;
  liveQr: number;
  saveRecord: number;
}

export const DEFAULT_COIN_COSTS: CoinCosts = {
  exportPng: 2,
  printPdf: 2,
  liveQr: 5,
  saveRecord: 2,
};

export interface SavedLicenseRecord extends LicenseData {
  id: string;
  ownerId: string;
  maskMode: MaskMode;
  qrMode: QrMode;
  createdAt?: Timestamp;
  updatedAt?: Timestamp;
}

export interface SavedTinRecord extends TinData {
  id: string;
  ownerId: string;
  maskMode: MaskMode;
  qrMode: QrMode;
  createdAt?: Timestamp;
  updatedAt?: Timestamp;
}

export type PaymentNetwork =
  | 'mpesa'
  | 'airtel'
  | 'tigo'
  | 'halopesa'
  | 'lipa_namba';

export type PaymentStatus = 'pending' | 'approved' | 'rejected';

export interface PaymentPackage {
  id: string;
  label: string;
  coins: number;
  priceTzs: number;
}

export interface PaymentConfig {
  accountName: string;
  mpesaNumber: string;
  airtelNumber: string;
  tigoNumber: string;
  halopesaNumber: string;
  lipaNamba: string;
  instructions: string;
  packages: PaymentPackage[];
}

export const DEFAULT_PAYMENT_CONFIG: PaymentConfig = {
  accountName: 'Digital Sales',
  mpesaNumber: '0784615052',
  airtelNumber: '0784615052',
  tigoNumber: '',
  halopesaNumber: '',
  lipaNamba: '',
  instructions:
    'Chagua kifurushi, lipa moja kwa moja kwa USSD Push (coin zinaongezwa kiotomatiki baada ya malipo kuthibitishwa) au tuma TZS kwenye namba ya mtandao husika kisha jaza kumbukumbu ya muamala.',
  packages: [
    { id: 'pkg_13', label: 'Kifurushi cha 13 Coins', coins: 13, priceTzs: 2000 },
    { id: 'pkg_28', label: 'Kifurushi cha 28 Coins', coins: 28, priceTzs: 5000 },
    { id: 'pkg_50', label: 'Kifurushi cha 50 Coins', coins: 50, priceTzs: 5500 },
    { id: 'pkg_100', label: 'Kifurushi cha 100 Coins', coins: 100, priceTzs: 10000 },
    { id: 'pkg_130', label: 'Kifurushi cha 130 Coins', coins: 130, priceTzs: 15000 },
  ],
};

export const PAYMENT_NETWORK_LABELS: Record<PaymentNetwork, string> = {
  mpesa: 'M-Pesa (Vodacom)',
  airtel: 'Airtel Money',
  tigo: 'Mixx by Yas (Tigo Pesa)',
  halopesa: 'Halopesa',
  lipa_namba: 'Lipa Namba',
};

export interface PaymentRequestRecord {
  id: string;
  userId: string;
  userFullName: string;
  userPhone: string;
  packageId: string;
  packageLabel: string;
  coins: number;
  amountTzs: number;
  network: PaymentNetwork;
  payerPhone: string;
  payerName: string;
  transactionRef: string;
  userNote: string;
  status: PaymentStatus;
  adminNote: string;
  reviewedBy: string;
  createdAt?: Timestamp;
  updatedAt?: Timestamp;
}

export interface CoinTransactionRecord {
  id: string;
  userId: string;
  type: 'topup' | 'deduct' | 'spend';
  amount: number;
  balanceAfter: number;
  service:
    | 'admin_adjustment'
    | 'payment_topup'
    | 'exportPng'
    | 'printPdf'
    | 'liveQr'
    | 'saveRecord';
  note: string;
  createdBy: string;
  createdAt?: Timestamp;
}

export type AdminActivityCategory =
  | 'service_toggle'
  | 'account_status'
  | 'coin_adjustment'
  | 'payment_approve'
  | 'payment_reject'
  | 'settings_update'
  | 'dsn_sync'
  | 'document_action';

export const ADMIN_ACTIVITY_CATEGORY_LABELS: Record<AdminActivityCategory, string> = {
  service_toggle: 'Huduma za Mtumiaji',
  account_status: 'Hali ya Akaunti',
  coin_adjustment: 'Marekebisho ya Coin',
  payment_approve: 'Uidhinishaji Malipo',
  payment_reject: 'Kukataa Malipo',
  settings_update: 'Mipangilio & Bei',
  dsn_sync: 'Ukaguzi wa DSN',
  document_action: 'Nyaraka & Zana',
};

export interface AdminActivityLogRecord {
  id: string;
  actorUid: string;
  actorName: string;
  actorEmail: string;
  category: AdminActivityCategory;
  actionTitle: string;
  targetUid: string;
  targetLabel: string;
  documentPath?: string;
  details: string;
  createdAt?: Timestamp;
}

export interface ServiceDefinition {
  key: ServiceKey;
  label: string;
  subtitle: string;
  costKey?: keyof CoinCosts;
}

export const SERVICE_DEFINITIONS: ServiceDefinition[] = [
  {
    key: 'editor',
    label: 'Hariri Leseni (License Editor)',
    subtitle: 'Ruhusa ya kujaza na kubadilisha taarifa kwenye fomu ya leseni.',
  },
  {
    key: 'tinCertificate',
    label: 'Cheti cha TIN (TIN Certificate)',
    subtitle: 'Ruhusa ya kutumia na kuhariri mfumo wa Cheti cha TIN (TRA).',
  },
  {
    key: 'exportPng',
    label: 'Pakua PDF / Nyaraka (Download PDF)',
    subtitle: 'Ruhusa ya kupakua nakala ya PDF yenye ubora wa juu kupitia Chrome.',
    costKey: 'exportPng',
  },
  {
    key: 'printPdf',
    label: 'Chapisha / PDF (Print & Download A4)',
    subtitle: 'Ruhusa ya kupakua au kuchapisha nakala ya A4 PDF.',
    costKey: 'printPdf',
  },
  {
    key: 'liveQr',
    label: 'QR Code Hai (Live Dynamic QR)',
    subtitle: 'Ruhusa ya kuzalisha QR code mpya yenye taarifa za nyaraka.',
    costKey: 'liveQr',
  },
  {
    key: 'saveRecords',
    label: 'Hifadhi Kumbukumbu (Cloud Records)',
    subtitle: 'Ruhusa ya kuhifadhi na kufungua nyaraka kwenye vifaa vingine.',
    costKey: 'saveRecord',
  },
];

export const EMPTY_SERVICES: UserServices = {
  editor: false,
  exportPng: false,
  printPdf: false,
  liveQr: false,
  saveRecords: false,
  tinCertificate: false,
};

export const ALL_ENABLED_SERVICES: UserServices = {
  editor: true,
  exportPng: true,
  printPdf: true,
  liveQr: true,
  saveRecords: true,
  tinCertificate: true,
};
